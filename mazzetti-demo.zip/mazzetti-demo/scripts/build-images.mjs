// Genera le immagini del sito in WebP a più larghezze, con una leggera
// correzione colore per armonizzarle con la palette (avorio, antracite, acciaio).
// Uso: npm run images
import sharp from "sharp";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

const SRC = "assets-src/photos";
const OUT = "public/img";
// Devono coincidere con deviceSizes + imageSizes in next.config.ts
const WIDTHS = [320, 480, 640, 960, 1280, 1920];

// grade: saturazione, luminosità, "lift" dei neri (matte), tinta calda leggera
const IMAGES = {
  // Immagini illustrative generate con GPT Image (20/10/2026)
  implantologia: { saturation: 0.92, lift: 3 },
  chirurgia: { saturation: 0.88, lift: 3 },
  protesi: { saturation: 0.92, lift: 2 },
  prevenzione: { saturation: 0.88, lift: 3 },
  ortodonzia: { saturation: 0.9, lift: 2 },
  "ortodonzia-invisibile": { saturation: 0.9, lift: 2 },
  filosofia: { saturation: 0.88, lift: 3 },
  "ricerca-navigazione": { saturation: 0.92, lift: 0 },
  "tac-3d": { saturation: 0.95, lift: 0 },
  // Immagini illustrative della prima versione (Pexels, licenza libera)
  estetica: { saturation: 0.42, lift: 10 },
  gnatologia: { saturation: 0.45, lift: 10 },
  "ricerca-carte": { saturation: 0.55, lift: 10 },
  luce: { saturation: 0.4, lift: 0 },
  strumenti: { saturation: 0.55, lift: 6 },
  // Ritratto ufficiale del dottore (inviato il 20/10/2026)
  ritratto: { saturation: 1, lift: 0, sharpen: true },
  // Fotografie reali dello studio inviate dal dottore (22/10/2026)
  "studio-sala-chirurgica": { saturation: 0.9, lift: 2 },
  "studio-corridoio": { saturation: 0.9, lift: 2 },
  "studio-vetrata": { saturation: 0.9, lift: 2 },
  // Fotografia reale dello studio (scheda pubblica Lazio Shopping), stesso stile delle nuove
  "studio-operativo": { saturation: 0.82, lift: 6, sharpen: true },
};

await mkdir(OUT, { recursive: true });
const manifest = {};

for (const [name, g] of Object.entries(IMAGES)) {
  const file = path.join(SRC, `${name}.jpg`);
  const meta = await sharp(file).metadata();
  const base = () => {
    let img = sharp(file)
      .rotate()
      .modulate({ saturation: g.saturation, brightness: 1.01 })
      // lift: comprime leggermente i neri per un aspetto più editoriale
      .linear(1 - g.lift / 255, g.lift)
      // tinta calda impercettibile verso l'avorio
      .recomb([
        [1.0, 0.012, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.01, 0.975],
      ]);
    if (g.sharpen) img = img.sharpen({ sigma: 0.6 });
    return img;
  };
  for (const w of WIDTHS) {
    await base()
      .resize({ width: w, withoutEnlargement: true })
      .webp({ quality: 78, effort: 5 })
      .toFile(path.join(OUT, `${name}-${w}.webp`));
  }
  const blur = await base().resize({ width: 16 }).webp({ quality: 40 }).toBuffer();
  manifest[name] = {
    width: meta.width,
    height: meta.height,
    blur: `data:image/webp;base64,${blur.toString("base64")}`,
  };
  console.log("ok", name, meta.width, meta.height);
}

await writeFile("src/content/image-manifest.json", JSON.stringify(manifest, null, 2));
console.log("manifest scritto");
