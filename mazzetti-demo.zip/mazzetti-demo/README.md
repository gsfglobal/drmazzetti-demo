# Studio Dentistico Dott. Vincenzo Mazzetti — concept dimostrativo

Proposta di sito realizzata da **Dental Go** per il Dott. Vincenzo Mazzetti, odontoiatra a Pontecorvo (FR).
È una versione di presentazione: alcuni dati sono da confermare (vedi `DATI-DA-VERIFICARE.md`).

## Stack

- Next.js 16 (App Router) con export statico, TypeScript, Tailwind CSS 4
- Motion per le animazioni, Lucide per le icone
- Three.js (caricato solo quando serve) per due scene procedurali, senza file 3D esterni:
  - hero: un'arcata dentale come nuvola di punti, «acquisita» da uno scanner intraorale
  - focus implantologia: impianto, moncone e corona in 4 fasi guidate dallo scroll, con disegno statico di riserva
- Font Cormorant Garamond + Inter ospitati con il sito (nessuna chiamata a Google dal browser)

## Comandi

```bash
npm install
npm run dev            # sviluppo su http://localhost:3000
npm run build          # genera il sito statico in out/
npm run images         # rigenera le immagini WebP da assets-src/photos
```

Per GitHub Pages: `BASE_PATH=/mazzetti-demo npm run build`, poi pubblicare `out/` (con un file `.nojekyll`) sul ramo `gh-pages`.
Sul dominio definitivo `BASE_PATH` resta vuoto.

## Dove si modificano i contenuti

| Cosa | File |
|---|---|
| Recapiti, orari, dati legali, modalità demo | `src/content/site.ts` |
| Biografia e timeline del dottore | `src/content/doctor.ts` |
| Trattamenti (testi, FAQ, immagini) | `src/content/treatments.ts` |
| Pubblicazioni scientifiche | `src/content/publications.ts` |
| FAQ della home | `src/content/faq.ts` |
| Foto dello studio | `src/content/studio.ts` + `assets-src/photos/` |
| Marchio (ricostruito in vettoriale) | `src/components/layout/mark-path.ts` |

## Passare dalla demo al sito definitivo

1. In `src/content/site.ts` mettere `demo: false`: spariscono l'etichetta «Concept dimostrativo» e i punti «da confermare», il sito diventa indicizzabile e gli orari entrano nei dati strutturati (impostare anche `hoursVerify: false`).
2. Aggiornare `url` con il dominio definitivo.
3. Collegare il modulo contatti a un servizio di invio (oggi in modalità dimostrativa: non invia nulla e lo dichiara).
4. Sostituire il ritratto tipografico con lo scatto ufficiale e le foto dello studio con un servizio professionale.
5. Completare privacy e cookie policy; se si aggiungono statistiche o pixel serve un banner con consenso preventivo.

## Immagini

- Foto dello studio: dalla scheda pubblica su Lazio Shopping, da sostituire.
- Immagini dei trattamenti e della ricerca: Pexels (licenza libera), indicate sul sito come «immagine illustrativa».
- `public/hero-scan.png` e `public/og.jpg` sono generati dal sito stesso.
