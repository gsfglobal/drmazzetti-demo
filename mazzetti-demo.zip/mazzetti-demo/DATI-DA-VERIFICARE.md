# Dati da verificare con il Dott. Mazzetti

Verifica delle fonti al 17 ottobre 2026.

## Recapiti e studio

| Dato | Valore nel sito | Fonte | Stato |
|---|---|---|---|
| Indirizzo | Piazza Giacinto Carbone 1, 03037 Pontecorvo (FR) | MioDottore, Lazio Shopping | Da confermare |
| Telefono | 380 474 0500 | Lazio Shopping, biglietto dello studio | Da confermare |
| Secondo telefono | 331 913 3996 | Biglietto nella scheda Lazio Shopping | Da confermare |
| Email | vincenzomazzetti1992@gmail.com | Indicata nel brief, Lazio Shopping | Da confermare |
| Orari | Lun, mer, sab 8–20 · ven 13:30–18 · mar, gio, dom chiuso | Solo Lazio Shopping | Da confermare (insoliti) |
| Instagram | @studiodentisticomazzetti | Lazio Shopping | Da confermare |
| Sito attuale | mazzettidottvincenzo.it | Lazio Shopping | Non leggibile in automatico |

## Dati obbligatori mancanti (pubblicità sanitaria)

- Direttore sanitario (nel sito: Dott. Vincenzo Mazzetti, da confermare)
- Iscrizione all'Albo degli Odontoiatri: numero e Ordine provinciale
- P. IVA e, se struttura, estremi autorizzativi
- Privacy e cookie policy da completare (bozze presenti)

## Titoli e percorso

| Dato | Fonte | Nel sito |
|---|---|---|
| Laurea con lode in Odontoiatria e Protesi Dentaria, Tor Vergata | MioDottore | Sì |
| Dottorato di ricerca con il massimo dei voti, Tor Vergata | MioDottore + archivio IRIS (tesi 2023, XXXVI ciclo) | Sì |
| Formazione in protesi fissa, Fradeani Education | MioDottore («Master») | Sì, come «percorso formativo» |
| Master II livello Medicina Legale Odontostomatologica, Torino | MioDottore | Sì |
| Attività presso ASL Frosinone | MioDottore («specialista ambulatoriale») | Sì, come «attività ambulatoriale», da confermare |
| Anni di laurea e dei master | Non disponibili | No |

**Non inseriti, da verificare e autorizzare:**
- Brevetto medico-farmaceutico (MioDottore)
- Premio Nobel Biocare 2022 per l'eccellenza implantare (solo Lazio Shopping; nessuna conferma trovata)
- «Specialista in chirurgia orale» (solo Lazio Shopping). Il titolo di specialista si usa solo con la specializzazione universitaria: nel sito le aree sono indicate come «aree di interesse».

## Pubblicazioni

Tutte verificate su PubMed, MDPI, DOAJ o Crossref, tranne «Learning curve of digital intraoral optical scanning» (2022): elenco autori e rivista solo da ResearchGate.
Le sintesi divulgative vanno fatte rileggere al dottore.

## Immagini

- Ritratto del dottore: assente (nel sito una tavola tipografica). Serve uno scatto professionale autorizzato.
- Foto dello studio: dalla scheda pubblica, bassa risoluzione. Consigliato un servizio fotografico.
- Logo: ricostruito in vettoriale dal biglietto pubblico. Serve il file originale.
- Palette del sito: quella del brief (antracite, blu notte, avorio, acciaio, champagne). Il logo originale usa toni petrolio: da allineare con il dottore.

## Trattamenti

Le sei aree sono coerenti con le prestazioni pubbliche (MioDottore: prima visita, implantologia, visita gnatologica, sbiancamento, faccette, estrazioni, frenulectomia, gengivectomia, ablazione, certificazioni). Testi informativi da validare con lo studio.

## Modifiche dal dottore (19-20/10/2026)

Applicate: P. IVA 03120820604, Albo di Frosinone n. 640, PEC vincenzomazzetti@pec.it, email pazienti.studiomazzetti@gmail.com, nuovi orari, master Fradeani di 3 moduli, brevetto medico-farmaceutico (anche nel testo introduttivo), sala chirurgica, TAC e scanner intraorale, titolo «Le aree di cura» (tolto «Sei»), nuovi trattamenti Ortodonzia e Ortodonzia invisibile, ritratto ufficiale.

Immagini: in attesa delle immagini generate con GPT Image (implantologia, chirurgia, protesi, prevenzione, ortodonzia, ortodonzia invisibile, filosofia, tesi di ricerca, TAC 3D). Fino ad allora restano quelle della prima versione; i due nuovi trattamenti usano un'immagine neutra provvisoria.

Da chiarire:
- Brevetto: titolo, numero, data; il secondo ente dopo «Ministero della Salute» è illeggibile.
- Direttore sanitario: confermare che sia il Dott. Mazzetti.
- Codice fiscale: non pubblicato (non obbligatorio sul sito).
