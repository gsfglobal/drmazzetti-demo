import type { NextConfig } from "next";

// BASE_PATH serve solo per GitHub Pages (es. /mazzetti-demo). Sul dominio
// definitivo resta vuoto.
const basePath = process.env.BASE_PATH ?? "";

const nextConfig: NextConfig = {
  output: "export",
  basePath: basePath || undefined,
  trailingSlash: true,
  reactStrictMode: true,
  env: { NEXT_PUBLIC_BASE_PATH: basePath },
  images: {
    loader: "custom",
    loaderFile: "./src/lib/image-loader.ts",
    deviceSizes: [640, 960, 1280, 1920],
    imageSizes: [320, 480],
  },
};

export default nextConfig;
