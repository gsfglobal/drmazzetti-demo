// Loader per next/image con export statico: le immagini sono già generate
// in public/img/<nome>-<larghezza>.webp da scripts/build-images.mjs.
export default function imageLoader({ src, width }: { src: string; width: number; quality?: number }) {
  if (/^(https?:)?\/\//.test(src) || src.startsWith("data:")) return src;
  const base = process.env.NEXT_PUBLIC_BASE_PATH ?? "";
  return `${base}/img/${src}-${width}.webp`;
}
