import type { Metadata } from "next";
import { site } from "@/content/site";

export const pageUrl = (path: string) => `${site.url}${path}`;

/** Metadati per pagina, con canonical e Open Graph coerenti. */
export function pageMeta({ title, description, path }: { title: string; description: string; path: string }): Metadata {
  return {
    title,
    description,
    alternates: { canonical: pageUrl(path) },
    openGraph: {
      title,
      description,
      url: pageUrl(path),
      siteName: site.name,
      locale: "it_IT",
      type: "website",
      images: [{ url: `${site.url}/og.jpg`, width: 1200, height: 630, alt: site.name }],
    },
  };
}

/** Dati strutturati dello studio: solo dati verificati. */
export function dentistJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "Dentist",
    "@id": `${site.url}/#studio`,
    name: site.name,
    url: `${site.url}/`,
    telephone: site.phone.e164,
    email: site.email,
    image: `${site.url}/og.jpg`,
    address: {
      "@type": "PostalAddress",
      streetAddress: site.address.street,
      postalCode: site.address.postalCode,
      addressLocality: site.address.city,
      addressRegion: site.address.province,
      addressCountry: site.address.country,
    },
    geo: { "@type": "GeoCoordinates", latitude: site.geo.lat, longitude: site.geo.lng },
    areaServed: { "@type": "City", name: "Pontecorvo" },
    sameAs: [site.social.instagram],
    // Orari da confermare: inseriti solo quando il dato è verificato
    ...(site.hoursVerify
      ? {}
      : {
          openingHoursSpecification: site.hoursSchema.map((h) => ({
            "@type": "OpeningHoursSpecification",
            dayOfWeek: h.days,
            opens: h.opens,
            closes: h.closes,
          })),
        }),
    employee: { "@id": `${site.url}/il-dottore/#persona` },
  };
}

export function personJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "Person",
    "@id": `${site.url}/il-dottore/#persona`,
    name: site.doctorName,
    honorificPrefix: "Dott.",
    jobTitle: "Odontoiatra",
    worksFor: { "@id": `${site.url}/#studio` },
    alumniOf: [
      { "@type": "CollegeOrUniversity", name: "Università degli Studi di Roma Tor Vergata" },
      { "@type": "CollegeOrUniversity", name: "Università degli Studi di Torino" },
    ],
    sameAs: ["https://www.researchgate.net/profile/Vincenzo-Mazzetti", "https://art.torvergata.it/cris/rp/rp44826"],
  };
}

export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [{ name: "Home", path: "/" }, ...items].map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: pageUrl(it.path),
    })),
  };
}

export function faqJsonLd(items: { q: string; a: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((i) => ({
      "@type": "Question",
      name: i.q,
      acceptedAnswer: { "@type": "Answer", text: i.a },
    })),
  };
}

export function JsonLd({ data }: { data: object }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}
