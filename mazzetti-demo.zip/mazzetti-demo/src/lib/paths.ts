// Percorso di un file in /public tenendo conto del basePath (GitHub Pages).
export const asset = (p: string) => `${process.env.NEXT_PUBLIC_BASE_PATH ?? ""}${p}`;
