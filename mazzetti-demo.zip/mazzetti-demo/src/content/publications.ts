// Pubblicazioni verificate (PubMed, MDPI, DOAJ, Crossref, archivio IRIS
// Tor Vergata) al 17 ottobre 2026. Le sintesi sono parafrasi divulgative
// scritte per i pazienti: non sostituiscono la lettura degli articoli.

export type Publication = {
  id: string;
  year: number;
  type: string;
  title: string;
  authors: string;
  venue: string;
  details?: string;
  summary: string;
  links: { label: string; href: string }[];
  theme: ThemeId;
  featured?: boolean;
};

export type ThemeId = "digitale" | "rigenerazione" | "chirurgia" | "parodontologia";

export const themes: { id: ThemeId; title: string; intro: string }[] = [
  {
    id: "digitale",
    title: "Implantologia e flusso digitale",
    intro:
      "Impronte digitali, chirurgia guidata e riabilitazioni su impianti: come rendere più precisi i passaggi che portano dal progetto alla protesi.",
  },
  {
    id: "rigenerazione",
    title: "Rigenerazione ossea",
    intro: "Materiali e tecniche per ricostruire l'osso quando non è sufficiente a sostenere un impianto.",
  },
  {
    id: "chirurgia",
    title: "Chirurgia orale",
    intro: "Gestione del dolore, guarigione dei tessuti e approcci guidati in chirurgia odontostomatologica.",
  },
  {
    id: "parodontologia",
    title: "Parodontologia e microbiologia",
    intro: "Batteri del cavo orale, terapie di supporto e possibili legami con la salute generale.",
  },
];

export const thesis: Publication = {
  id: "tesi-2023",
  year: 2023,
  type: "Tesi di dottorato",
  title:
    "Evaluation of guided dynamic surgery for single implants in the cosmetic dentistry sector, programmed by means of a digitally-guided prosthetic workflow: follow-up after 1 year",
  authors: "Vincenzo Mazzetti",
  venue: "Università degli Studi di Roma «Tor Vergata»",
  details: "Dottorato in Materials for Sustainable Development, XXXVI ciclo · A.A. 2022/2023",
  summary:
    "Valuta l'inserimento di impianti singoli nei settori estetici con la chirurgia dinamicamente guidata: un sistema di navigazione che segue in tempo reale gli strumenti rispetto a un progetto definito prima dell'intervento con un flusso di lavoro protesico digitale. Lo studio include un controllo a un anno.",
  links: [{ label: "Archivio IRIS Tor Vergata", href: "https://hdl.handle.net/2108/427246" }],
  theme: "digitale",
  featured: true,
};

export const publications: Publication[] = [
  {
    id: "scanbody-2022",
    year: 2022,
    type: "Studio in vitro randomizzato",
    title:
      "Influence of Implant Scanbody Wear on the Accuracy of Digital Impression for Complete-Arch: A Randomized In Vitro Trial",
    authors: "Arcuri L, Lio F, Campana V, Mazzetti V, Federici FR, Nardi A, Galli M",
    venue: "Materials",
    details: "2022; 15(3): 927 · DOI 10.3390/ma15030927 · PMID 35160873",
    summary:
      "Per registrare la posizione degli impianti, lo scanner intraorale «legge» piccoli cilindri chiamati scanbody. Lo studio misura in laboratorio quanto la loro usura influisca sulla precisione dell'impronta digitale di un'intera arcata: secondo gli autori, l'usura ne riduce l'accuratezza.",
    links: [
      { label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/35160873/" },
      { label: "Articolo", href: "https://doi.org/10.3390/ma15030927" },
    ],
    theme: "digitale",
    featured: true,
  },
  {
    id: "impronte-edentule-2023",
    year: 2023,
    type: "Revisione narrativa",
    title:
      "Techniques to Improve the Accuracy of Intraoral Digital Impression in Complete Edentulous Arches: A Narrative Review",
    authors: "Leggeri A, Carosi P, Mazzetti V, Arcuri C, Lorenzi C",
    venue: "Applied Sciences",
    details: "2023; 13(12): 7068 · DOI 10.3390/app13127068",
    summary:
      "Nelle arcate senza denti lo scanner intraorale ha pochi punti di riferimento. La revisione raccoglie le tecniche proposte per rendere l'impronta digitale più precisa: i risultati, tutti di laboratorio, sono incoraggianti e per gli autori servono ora studi clinici.",
    links: [{ label: "Articolo", href: "https://doi.org/10.3390/app13127068" }],
    theme: "digitale",
    featured: true,
  },
  {
    id: "impianti-ridotti-2022",
    year: 2022,
    type: "Studio clinico retrospettivo",
    title:
      "Clinical Reliability of Complete-Arch Fixed Prostheses Supported by Narrow-Diameter Implants to Support Complete-Arch Restorations",
    authors: "Lorenzi C, Lio F, Papi P, Mazzetti V, Laureti A, Arcuri C",
    venue: "Applied Sciences",
    details: "2023; 13(1): 538 · DOI 10.3390/app13010538",
    summary:
      "Analizza a distanza di tempo protesi fisse dell'intera arcata sostenute da quattro impianti a diametro ridotto. Gli autori ne descrivono un comportamento affidabile nel medio-lungo periodo, indicando i limiti di uno studio retrospettivo condotto in un solo centro.",
    links: [{ label: "Articolo", href: "https://doi.org/10.3390/app13010538" }],
    theme: "digitale",
  },
  {
    id: "learning-curve-2022",
    year: 2022,
    type: "Studio in vitro",
    title: "Learning curve of digital intraoral optical scanning for complete arch: an in vitro study",
    authors: "Lio F, Carosi P, Arcuri C, Mazzetti V e altri (elenco completo nella fonte)",
    venue: "Journal of Biological Regulators and Homeostatic Agents",
    details: "2022",
    summary:
      "Studia quanto conti l'esperienza dell'operatore nella scansione intraorale di un'intera arcata, cioè come cambia la qualità dell'impronta con la pratica.",
    links: [{ label: "ResearchGate", href: "https://www.researchgate.net/profile/Vincenzo-Mazzetti" }],
    theme: "digitale",
  },
  {
    id: "case-report-2019",
    year: 2019,
    type: "Caso clinico",
    title:
      "Immediate restoration of a single upper central integrating digital workflow and a novel dental implant: a case report",
    authors: "Arcuri C, Barlattani A Jr, Mazzetti V, Carosi P, Ferrigno N, Ferrigno N",
    venue: "Journal of Biological Regulators and Homeostatic Agents",
    details: "2019 · PMID 32338471",
    summary:
      "Descrive la sostituzione di un incisivo centrale superiore con un impianto e un restauro provvisorio immediato, pianificati con un flusso di lavoro digitale.",
    links: [{ label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/32338471/" }],
    theme: "digitale",
  },
  {
    id: "acido-ialuronico-2024",
    year: 2024,
    type: "Revisione sistematica e meta-analisi",
    title: "Hyaluronic Acid in Bone Regeneration: Systematic Review and Meta-Analysis",
    authors: "Lorenzi C, Leggeri A, Cammarota I, Carosi P, Mazzetti V, Arcuri C",
    venue: "Dentistry Journal",
    details: "2024; 12(8): 263 · DOI 10.3390/dj12080263 · PMID 39195107",
    summary:
      "Confronta gli studi in cui l'acido ialuronico viene aggiunto ai materiali da innesto osseo. Nei tre studi randomizzati inclusi non emerge una differenza significativa nella formazione di nuovo osso: gli autori indicano la necessità di ulteriori ricerche.",
    links: [
      { label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/39195107/" },
      { label: "Articolo", href: "https://doi.org/10.3390/dj12080263" },
    ],
    theme: "rigenerazione",
    featured: true,
  },
  {
    id: "lamina-corticale-2025",
    year: 2025,
    type: "Revisione",
    title: "Cortical Laminar Bone Membrane in Implant Dentistry: Biological Basis, Clinical Protocols, and Outcomes",
    authors: "Pinto A, Mazzetti V, Carosi P, Lorenzi C",
    venue: "Applied Sciences",
    details: "2025 · DOI 10.3390/app152212243",
    summary:
      "Fa il punto sulle membrane di osso corticale usate nella rigenerazione ossea in implantologia: basi biologiche, modalità d'impiego descritte in letteratura ed esiti riportati.",
    links: [{ label: "Articolo", href: "https://doi.org/10.3390/app152212243" }],
    theme: "rigenerazione",
  },
  {
    id: "cianoacrilati-2026",
    year: 2026,
    type: "Revisione narrativa",
    title: "Cyanoacrylate Tissue Adhesives in Oral and Maxillofacial Surgery: A Narrative Review of Clinical Outcomes",
    authors: "Pinto A, Mazzetti V, Giordano F, Carosi P, Lorenzi C",
    venue: "Journal of Oral and Maxillofacial Surgery",
    details: "2026 · DOI 10.1016/j.joms.2026.06.004 · PMID 42361852",
    summary:
      "Esamina gli adesivi tissutali a base di cianoacrilato, usati in alternativa o in aggiunta ai punti di sutura, e i risultati clinici riportati in chirurgia orale e maxillo-facciale.",
    links: [
      { label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/42361852/" },
      { label: "Articolo", href: "https://doi.org/10.1016/j.joms.2026.06.004" },
    ],
    theme: "chirurgia",
  },
  {
    id: "ibuprofene-2025",
    year: 2025,
    type: "Scoping review",
    title: "The Use of Ibuprofen Arginate in Pain Management Following Third Molar Surgery—A Scoping Review",
    authors: "Lorenzi C, Cammarota I, Mazzetti V, Arcuri C, Carosi P, Pujia A",
    venue: "Applied Sciences",
    details: "2025; 15(2): 662 · DOI 10.3390/app15020662",
    summary:
      "Raccoglie gli studi sulla gestione del dolore dopo l'estrazione dei denti del giudizio con un particolare antinfiammatorio. È una sintesi della letteratura, non un'indicazione terapeutica: la terapia è sempre prescritta dal medico.",
    links: [{ label: "Articolo", href: "https://doi.org/10.3390/app15020662" }],
    theme: "chirurgia",
  },
  {
    id: "microchirurgia-2021",
    year: 2021,
    type: "Revisione",
    title: "Guided endodontic microsurgery in apicoectomy: a review",
    authors: "Lio F, Mampieri G, Mazzetti V, Leggeri A, Arcuri L",
    venue: "Journal of Biological Regulators and Homeostatic Agents",
    details: "2021 · DOI 10.23812/21-3supp1-7 · PMID 34289664",
    summary:
      "Descrive l'impiego di guide chirurgiche progettate al computer negli interventi di apicectomia, per raggiungere la punta della radice in modo più mirato.",
    links: [{ label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/34289664/" }],
    theme: "chirurgia",
  },
  {
    id: "metronidazolo-2024",
    year: 2024,
    type: "Studio in vitro",
    title:
      "Synergistic Effect of Metronidazole and Chlorhexidine against Porphyromonas gingivalis Growth: An In Vitro Study",
    authors: "Lorenzi C, Lio F, Mazzetti V, Carosi P, Lamelza S, Pistoia ES, Pica F, Gaziano R",
    venue: "Dentistry Journal",
    details: "2024; 12(10): 307 · DOI 10.3390/dj12100307 · PMID 39452435",
    summary:
      "Studio di laboratorio sull'azione combinata di due sostanze antibatteriche contro uno dei batteri associati alla malattia parodontale.",
    links: [
      { label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/39452435/" },
      { label: "Articolo", href: "https://doi.org/10.3390/dj12100307" },
    ],
    theme: "parodontologia",
  },
  {
    id: "alzheimer-2021",
    year: 2021,
    type: "Revisione",
    title:
      "The role of periodontal bacteria, Porphyromonas Gingivalis, in Alzheimer's disease pathogenesis and aggravation: a review",
    authors: "Lorenzi C, Bianchi N, Pinto A, Mazzetti V, Arcuri C",
    venue: "Journal of Biological Regulators and Homeostatic Agents",
    details: "2021 · DOI 10.23812/21-3supp1-6 · PMID 34289663",
    summary:
      "Riassume le ricerche che indagano un possibile legame tra un batterio della malattia parodontale e la malattia di Alzheimer: un campo di studio ancora aperto.",
    links: [{ label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/34289663/" }],
    theme: "parodontologia",
  },
  {
    id: "ozono-2020",
    year: 2020,
    type: "Revisione",
    title:
      "The effectiveness of subgingival irrigant ozone-based as adjuvant for non-surgical periodontal therapy in the treatment of chronic periodontitis: a review",
    authors: "Lio F, Ottria L, Mazzetti V, Leggeri A, Casella S, Arcuri L",
    venue: "Journal of Biological Regulators and Homeostatic Agents",
    details: "2020 · PMID 32618158",
    summary:
      "Analizza gli studi sull'uso di irriganti a base di ozono come supporto alla terapia parodontale non chirurgica.",
    links: [{ label: "PubMed", href: "https://pubmed.ncbi.nlm.nih.gov/32618158/" }],
    theme: "parodontologia",
  },
];

export const featuredPublications = [thesis, ...publications.filter((p) => p.featured)];

export const researchProfiles = [
  { label: "ResearchGate", href: "https://www.researchgate.net/profile/Vincenzo-Mazzetti" },
  { label: "Archivio IRIS Tor Vergata", href: "https://art.torvergata.it/cris/rp/rp44826" },
];
