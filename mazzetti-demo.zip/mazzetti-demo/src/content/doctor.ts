// Percorso professionale: solo dati pubblicamente documentati
// (profilo MioDottore, archivio IRIS di Tor Vergata, PubMed, ResearchGate).
// Brevetto e riconoscimenti citati da alcune fonti NON sono riportati:
// vanno verificati e autorizzati dal dottore prima di inserirli.

export const doctorIntro = {
  lead:
    "Odontoiatra a Pontecorvo, si è formato all'Università di Roma Tor Vergata, dove ha conseguito la laurea con lode e il dottorato di ricerca. Alla pratica clinica affianca da anni l'attività scientifica.",
  body: [
    "Il Dott. Vincenzo Mazzetti si è laureato con lode in Odontoiatria e Protesi Dentaria all'Università degli Studi di Roma «Tor Vergata». Nello stesso ateneo ha conseguito il dottorato di ricerca con il massimo dei voti, con una tesi sulla chirurgia implantare dinamicamente guidata e sul flusso di lavoro protesico digitale.",
    "Ha approfondito la protesi fissa con il percorso formativo di Fradeani Education e ha conseguito il Master universitario di secondo livello in Medicina Legale Odontostomatologica all'Università degli Studi di Torino.",
    "È coautore di pubblicazioni su riviste scientifiche internazionali dedicate a implantologia, impronte digitali, rigenerazione ossea e chirurgia orale. Svolge attività clinica nel suo studio di Pontecorvo e attività ambulatoriale presso l'ASL di Frosinone.",
  ],
  interests: ["Chirurgia orale", "Implantologia", "Riabilitazione delle arcate complete", "Protesi fissa"],
};

export type TimelineItem = {
  id: string;
  phase: string;
  period?: string;
  title: string;
  entries: { title: string; detail: string; verify?: boolean }[];
};

export const timeline: TimelineItem[] = [
  {
    id: "universita",
    phase: "Percorso universitario",
    title: "La formazione a Tor Vergata",
    entries: [
      {
        title: "Laurea con lode in Odontoiatria e Protesi Dentaria",
        detail: "Università degli Studi di Roma «Tor Vergata».",
      },
    ],
  },
  {
    id: "post-laurea",
    phase: "Formazione post-laurea",
    title: "Protesi e medicina legale",
    entries: [
      {
        title: "Formazione in protesi fissa",
        detail: "Percorso formativo di Fradeani Education.",
      },
      {
        title: "Master universitario di II livello in Medicina Legale Odontostomatologica",
        detail: "Università degli Studi di Torino.",
      },
    ],
  },
  {
    id: "ricerca",
    phase: "Attività di ricerca",
    period: "2019 — oggi",
    title: "Il dottorato e le pubblicazioni",
    entries: [
      {
        title: "Dottorato di ricerca, con il massimo dei voti",
        detail:
          "Università di Roma «Tor Vergata», dottorato in Materials for Sustainable Development, XXXVI ciclo. Tesi discussa nel 2023 sulla chirurgia implantare dinamicamente guidata per impianti singoli nei settori estetici, con controllo a un anno.",
      },
      {
        title: "Pubblicazioni scientifiche",
        detail:
          "Dal 2019 coautore di articoli su riviste indicizzate: impronte digitali e implantologia, rigenerazione ossea, chirurgia orale e microbiologia del cavo orale.",
      },
    ],
  },
  {
    id: "clinica",
    phase: "Approccio clinico",
    title: "Dalla ricerca alla poltrona",
    entries: [
      {
        title: "Studio dentistico a Pontecorvo",
        detail:
          "Attività clinica con particolare attenzione a chirurgia orale, implantologia e riabilitazione delle arcate complete.",
      },
      {
        title: "Attività ambulatoriale presso l'ASL di Frosinone",
        detail: "Come riportato dal profilo professionale pubblico.",
        verify: true,
      },
    ],
  },
];
