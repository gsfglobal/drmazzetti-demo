// Fotografie reali dello studio, tratte dalla scheda pubblica su Lazio Shopping.
// Nella versione definitiva vanno sostituite con un servizio fotografico
// professionale autorizzato dallo studio.
export const studioPhotos = [
  { src: "studio-accoglienza", alt: "L'accoglienza dello studio, con il bancone luminoso e il logo", caption: "L'accoglienza" },
  { src: "studio-operativo", alt: "Un ambulatorio dello studio con riunito odontoiatrico", caption: "Ambulatorio" },
  { src: "studio-sala", alt: "Un ambulatorio dello studio illuminato dalla luce naturale", caption: "Ambulatorio" },
  { src: "studio-radiologia", alt: "Un ambiente dello studio dedicato agli esami", caption: "Uno degli ambienti dello studio" },
  { src: "studio-sala-2", alt: "Un altro ambulatorio dello studio con finestra", caption: "Ambulatorio" },
];

export const studioPhotoNote =
  "Fotografie dello studio tratte da una scheda pubblica. Nella versione definitiva saranno sostituite da un servizio fotografico professionale.";

export const illustrativeNote =
  "Le immagini dei trattamenti sono illustrative: non ritraggono lo studio né i suoi pazienti.";

// Dotazioni indicate dal dottore (19/10/2026): sala chirurgica, TAC e scanner intraorale.
export const studioFeatures = [
  {
    title: "Sala chirurgica",
    text: "All'interno dello studio è presente una sala chirurgica, dove si svolgono gli interventi di chirurgia orale e implantare.",
  },
  {
    title: "Scanner intraorale",
    text: "Le impronte digitali si acquisiscono con uno scanner intraorale: niente materiali da impronta, e un modello tridimensionale utile per pianificare e per la protesi.",
  },
  {
    title: "TAC 3D",
    text: "Lo studio dispone di una TAC per gli esami radiologici tridimensionali, utili a valutare l'osso e a pianificare gli interventi.",
  },
] as const;
