// Fotografie reali dello studio. Le prime tre sono state inviate dal dottore
// (22/10/2026); «studio-operativo» viene dalla scheda pubblica ed è l'unica
// delle vecchie foto tenuta perché ha lo stesso stile degli ambienti nuovi.
export type StudioPhoto = { src: string; alt: string; caption: string; position?: string };

export const studioPhotos = {
  salaChirurgica: {
    src: "studio-sala-chirurgica",
    alt: "La sala chirurgica dello studio, con pareti in vetro satinato e il logo Mazzetti",
    caption: "Sala chirurgica",
    position: "center 45%",
  },
  ambulatorio: {
    src: "studio-operativo",
    alt: "Un ambulatorio dello studio con riunito odontoiatrico e parete in vetro",
    caption: "Ambulatorio",
  },
  vetrata: {
    src: "studio-vetrata",
    alt: "Parete in vetro satinato con il logo dello studio e uno schermo di proiezione",
    caption: "Uno degli ambienti dello studio",
    position: "center 80%",
  },
  corridoio: {
    src: "studio-corridoio",
    alt: "Il corridoio dello studio, con la sala chirurgica in vetro e luci lineari a soffitto",
    caption: "Il corridoio",
    position: "center 45%",
  },
} satisfies Record<string, StudioPhoto>;

export const illustrativeNote =
  "Le immagini dei trattamenti sono illustrative: non ritraggono lo studio né i suoi pazienti.";

// Dotazioni indicate dal dottore (19/10/2026): sala chirurgica, TAC e scanner intraorale.
export const studioFeatures = [
  {
    title: "Sala chirurgica",
    text: "All'interno dello studio è presente una sala chirurgica, dove si svolgono gli interventi di chirurgia orale e implantare.",
  },
  {
    title: "Scanner intraorale",
    text: "Le impronte digitali si acquisiscono con uno scanner intraorale: niente materiali da impronta, e un modello tridimensionale utile per pianificare e per la protesi.",
  },
  {
    title: "TAC 3D",
    text: "Lo studio dispone di una TAC per gli esami radiologici tridimensionali, utili a valutare l'osso e a pianificare gli interventi.",
  },
] as const;
