import { site, fullAddress } from "./site";

// Risposte prudenti e informative: non sostituiscono una valutazione clinica.
export const homeFaq = [
  {
    q: "Come si svolge la prima visita?",
    a: "Si inizia dalla storia clinica e da ciò che ti ha portato in studio. Segue l'esame della bocca e, se servono, gli esami radiografici. Alla fine il dottore ti spiega cosa ha osservato e, se necessario, ti propone un piano di trattamento con le possibili alternative.",
  },
  {
    q: "Come si capisce se un impianto è la soluzione giusta?",
    a: "Con una valutazione dell'osso, delle gengive e delle condizioni generali di salute. In alcuni casi l'impianto non è indicato o richiede passaggi preliminari; in altri sono possibili alternative come un ponte o una protesi. Lo si decide insieme, dopo la visita.",
  },
  {
    q: "Che differenza c'è tra una protesi fissa e una mobile?",
    a: "La protesi fissa, come una corona o un ponte, resta stabilmente in bocca. Quella mobile si rimuove per la pulizia. Esistono anche protesi mobili ancorate a impianti. Ognuna ha indicazioni, vantaggi e limiti che vengono illustrati durante la visita.",
  },
  {
    q: "Quanto dura un trattamento?",
    a: "Dipende dal tipo di cura e dalla situazione di partenza: una seduta di igiene richiede un appuntamento, un percorso implantare può richiedere alcuni mesi per i tempi di guarigione. I tempi indicativi sono sempre riportati nel piano di trattamento.",
  },
  {
    q: "Come posso contattare lo studio?",
    a: `Puoi chiamare lo studio al ${site.phone.display} oppure scrivere a ${site.email}. Lo studio riceve su appuntamento: ti verranno proposti giorno e orario in base alle disponibilità.`,
  },
  {
    q: "Dove si trova lo studio e come si raggiunge?",
    a: `Lo studio si trova in ${fullAddress}. Dalla pagina Contatti puoi aprire l'indirizzo direttamente in Google Maps per calcolare il percorso.`,
  },
];
