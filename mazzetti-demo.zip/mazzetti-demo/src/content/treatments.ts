// Aree di trattamento coerenti con le prestazioni pubblicamente riportate
// (profilo MioDottore e scheda Lazio Shopping); ortodonzia e ortodonzia
// invisibile aggiunte su richiesta del dottore (20/10/2026). I testi sono informativi:
// non attribuiscono allo studio apparecchiature o protocolli non verificati
// e non promettono risultati o tempi (L. 145/2018, art. 1 c. 525).

export type Treatment = {
  slug: string;
  title: string;
  short: string;
  image: string;
  imageAlt: string;
  /** Inquadratura dell'immagine (object-position), se diversa dal centro. */
  imagePosition?: string;
  lead: string;
  seoDescription: string;
  sections: { heading: string; paragraphs: string[] }[];
  checklist?: { heading: string; items: string[] };
  faq: { q: string; a: string }[];
};

export const treatments: Treatment[] = [
  {
    slug: "implantologia",
    title: "Implantologia dentale",
    short:
      "Sostituire uno o più denti mancanti con radici artificiali in titanio, dopo uno studio attento dell'osso e della salute della bocca.",
    image: "implantologia",
    imageAlt: "Impianto dentale in titanio con moncone, appoggiato su una lastra di pietra chiara",
    imagePosition: "center 55%",
    lead:
      "Un impianto è una piccola radice artificiale, in genere in titanio, che viene inserita nell'osso per sostenere una corona, un ponte o una protesi dell'intera arcata. Prima di proporlo serve capire se è la soluzione adatta a quella persona.",
    seoDescription:
      "Implantologia dentale a Pontecorvo: come funziona un impianto, come si valuta l'osso e quali sono le fasi del percorso. Informazioni dallo studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "Di cosa si tratta",
        paragraphs: [
          "L'impianto sostituisce la radice del dente. Una volta integrato nell'osso, sostiene un elemento protesico — una corona singola, un ponte o una protesi fissa dell'intera arcata — che ripristina masticazione ed estetica.",
          "Non esiste un impianto «standard»: diametro, lunghezza, posizione e tempi di carico si decidono caso per caso, sulla base della quantità e della qualità dell'osso, della salute delle gengive e delle condizioni generali del paziente.",
        ],
      },
      {
        heading: "Quando se ne parla",
        paragraphs: [
          "Se ne parla quando manca un dente, quando ne mancano diversi o quando una protesi mobile non è più confortevole. In alcuni casi l'impianto non è indicato, oppure richiede prima un intervento per ricostruire l'osso: lo si può stabilire solo dopo una visita e gli esami necessari.",
        ],
      },
      {
        heading: "Perché la pianificazione è decisiva",
        paragraphs: [
          "La posizione dell'impianto condiziona la forma e la durata della protesi che sosterrà. Per questo il progetto parte dal risultato protesico desiderato e solo dopo arriva alla chirurgia. È anche il tema della ricerca del Dott. Mazzetti, dedicata alla precisione delle impronte digitali e alla chirurgia implantare guidata.",
        ],
      },
    ],
    checklist: {
      heading: "Un possibile percorso, a titolo informativo",
      items: [
        "Visita, raccolta della storia clinica ed esami radiografici quando necessari",
        "Studio del caso e piano di trattamento scritto, con alternative e tempi indicativi",
        "Intervento di inserimento dell'impianto",
        "Periodo di guarigione e realizzazione della protesi",
        "Controlli periodici e igiene professionale nel tempo",
      ],
    },
    faq: [
      {
        q: "Chiunque può fare un impianto?",
        a: "No. Alcune condizioni generali o locali possono sconsigliarlo o richiedere passaggi preliminari. L'indicazione si valuta solo dopo una visita, la storia clinica e gli esami necessari.",
      },
      {
        q: "Quanto dura un impianto?",
        a: "La durata nel tempo dipende da molti fattori: salute delle gengive, igiene domiciliare, controlli periodici, abitudini come il fumo e carichi masticatori. Nessun professionista serio può garantire una durata prestabilita.",
      },
      {
        q: "Quanto tempo richiede il percorso?",
        a: "Dipende dal caso: dalla necessità di estrazioni o di ricostruzioni ossee, dai tempi di guarigione e dal tipo di protesi. I tempi indicativi vengono spiegati nel piano di trattamento.",
      },
    ],
  },
  {
    slug: "chirurgia-orale",
    title: "Chirurgia orale",
    short:
      "Estrazioni, denti del giudizio inclusi e interventi sui tessuti della bocca, pianificati e spiegati in ogni passaggio.",
    image: "chirurgia",
    imageAlt: "Kit chirurgico sterile in buste sigillate su un vassoio in acciaio, in una sala chirurgica luminosa",
    imagePosition: "center 70%",
    lead:
      "La chirurgia orale comprende gli interventi sui denti, sull'osso e sui tessuti molli della bocca: dalle estrazioni più complesse alla correzione di un frenulo. Ogni intervento parte da una diagnosi e da un'informazione chiara sui passaggi e sul decorso.",
    seoDescription:
      "Chirurgia orale a Pontecorvo: estrazioni, denti del giudizio inclusi, frenulectomia e interventi sui tessuti molli. Informazioni dallo studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "Di cosa si tratta",
        paragraphs: [
          "Rientrano nella chirurgia orale le estrazioni dentarie, comprese quelle dei denti del giudizio parzialmente o totalmente inclusi nell'osso, la frenulectomia, la gengivectomia e altri interventi sui tessuti molli.",
          "Molti di questi interventi si eseguono in anestesia locale, nello studio. La scelta della tecnica e i tempi di recupero dipendono dalla posizione del dente, dall'anatomia e dalle condizioni del paziente.",
        ],
      },
      {
        heading: "Prima dell'intervento",
        paragraphs: [
          "Si raccolgono la storia clinica e l'elenco dei farmaci assunti, si eseguono gli esami radiografici necessari e si spiega cosa aspettarsi nei giorni successivi. Il paziente riceve indicazioni scritte per la preparazione e per il decorso post-operatorio.",
        ],
      },
      {
        heading: "Dopo l'intervento",
        paragraphs: [
          "Gonfiore e fastidio nei giorni successivi sono possibili e variano da persona a persona. Le indicazioni su alimentazione, igiene e terapia vengono date dal professionista, che resta il riferimento per qualsiasi dubbio durante la guarigione.",
        ],
      },
    ],
    faq: [
      {
        q: "I denti del giudizio vanno sempre tolti?",
        a: "No. Si valuta l'estrazione quando creano problemi o rischiano di crearne, per esempio infezioni ricorrenti o danni ai denti vicini. La decisione si prende dopo la visita e gli esami radiografici.",
      },
      {
        q: "Che cos'è la frenulectomia?",
        a: "È un intervento che modifica un frenulo, la piega di tessuto che unisce labbro o lingua alla gengiva, quando la sua forma o posizione crea problemi funzionali o parodontali.",
      },
      {
        q: "Posso guidare dopo un'estrazione?",
        a: "Dipende dal tipo di intervento e da come ci si sente al termine. Le indicazioni precise vengono date prima dell'appuntamento.",
      },
    ],
  },
  {
    slug: "protesi-e-riabilitazione",
    title: "Protesi e riabilitazione dentale",
    short:
      "Corone, ponti e protesi su denti naturali o su impianti, fino alla riabilitazione dell'intera arcata, progettate partendo dalla funzione.",
    image: "protesi",
    imageAlt: "Una corona e una faccetta in ceramica su un piano di marmo chiaro",
    imagePosition: "center 50%",
    lead:
      "La protesi dentale ripristina i denti compromessi o mancanti. Può essere fissa o mobile, appoggiarsi su denti naturali o su impianti, interessare un solo elemento o l'intera arcata. La scelta dipende dalla situazione della bocca e dalle esigenze della persona.",
    seoDescription:
      "Protesi dentale e riabilitazione delle arcate a Pontecorvo: corone, ponti, protesi su impianti. Informazioni dallo studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "Fissa o mobile",
        paragraphs: [
          "Le protesi fisse — corone e ponti — sono cementate o avvitate e non si rimuovono a casa. Le protesi mobili si tolgono per la pulizia. Esistono anche soluzioni intermedie, sostenute da impianti, che migliorano la stabilità di una protesi mobile.",
        ],
      },
      {
        heading: "Riabilitazione delle arcate complete",
        paragraphs: [
          "Quando mancano molti denti o tutti i denti di un'arcata, si può valutare una protesi fissa sostenuta da impianti. È un percorso che richiede uno studio accurato della funzione masticatoria, dell'estetica del viso e dell'osso disponibile.",
          "La precisione delle impronte, tradizionali o digitali, incide sull'adattamento della protesi: un tema al centro di diverse pubblicazioni del Dott. Mazzetti.",
        ],
      },
      {
        heading: "Materiali",
        paragraphs: [
          "I materiali si scelgono in base alla posizione del dente, ai carichi masticatori e all'estetica. Le opzioni disponibili vengono illustrate durante la visita, con i loro vantaggi e i loro limiti.",
        ],
      },
    ],
    faq: [
      {
        q: "Meglio un ponte o un impianto?",
        a: "Dipende dallo stato dei denti vicini, dall'osso disponibile, dalla salute generale e dalle preferenze del paziente. Sono soluzioni diverse con indicazioni diverse: si valutano insieme durante la visita.",
      },
      {
        q: "Una protesi si può riparare?",
        a: "In molti casi sì. Per questo i controlli periodici sono importanti: permettono di intervenire presto su usura o piccole fratture.",
      },
      {
        q: "Come si pulisce una protesi fissa?",
        a: "Con spazzolino, filo o scovolini indicati dal professionista e con sedute di igiene professionale periodiche. Le istruzioni vengono personalizzate.",
      },
    ],
  },
  {
    slug: "estetica-dentale",
    title: "Estetica dentale",
    short:
      "Sbiancamento e faccette per intervenire su colore e forma dei denti, nel rispetto della salute dei tessuti e dell'armonia del viso.",
    image: "estetica",
    imageAlt: "Dettaglio di un sorriso, immagine illustrativa",
    lead:
      "L'estetica dentale riguarda il colore, la forma e la proporzione dei denti. Ogni intervento parte dalla salute della bocca: denti e gengive sani sono la base di qualsiasi miglioramento estetico.",
    seoDescription:
      "Estetica dentale a Pontecorvo: sbiancamento professionale e faccette. Informazioni dallo studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "Sbiancamento professionale",
        paragraphs: [
          "Lo sbiancamento schiarisce il colore dei denti naturali con prodotti a uso professionale. L'esito varia da persona a persona e non agisce su otturazioni, corone o faccette già presenti. Prima del trattamento si verifica che non ci siano carie o sensibilità da trattare.",
        ],
      },
      {
        heading: "Faccette",
        paragraphs: [
          "Le faccette sono sottili lamine applicate sulla superficie visibile dei denti per correggerne forma, colore o piccole irregolarità. Si valutano dopo uno studio del sorriso e un confronto sulle aspettative.",
        ],
      },
      {
        heading: "Un approccio misurato",
        paragraphs: [
          "Il criterio è conservare il più possibile i tessuti sani e cercare un risultato coerente con il viso della persona, non un modello uguale per tutti.",
        ],
      },
    ],
    faq: [
      {
        q: "Lo sbiancamento rovina lo smalto?",
        a: "Se indicato e seguito da un professionista, lo sbiancamento è considerato un trattamento sicuro. Può dare una sensibilità temporanea, che va segnalata.",
      },
      {
        q: "Quanto dura l'effetto?",
        a: "Dipende dalle abitudini, per esempio caffè, tè e fumo, e dall'igiene. Non è possibile stabilire una durata uguale per tutti.",
      },
      {
        q: "Le faccette sono adatte a tutti?",
        a: "No. Bruxismo, malattia parodontale o carie vanno valutati e trattati prima. L'indicazione si decide dopo la visita.",
      },
    ],
  },
  {
    slug: "ortodonzia",
    title: "Ortodonzia",
    short:
      "Correggere la posizione dei denti e il modo in cui le arcate si chiudono, con apparecchi studiati sulla bocca di ciascuno.",
    image: "ortodonzia",
    imageAlt: "Modello di un'arcata dentale con attacchi ortodontici in ceramica color dente",
    lead:
      "L'ortodonzia si occupa della posizione dei denti e del rapporto tra le arcate. Denti allineati e una chiusura corretta aiutano la masticazione, facilitano l'igiene e contribuiscono all'armonia del sorriso.",
    seoDescription:
      "Ortodonzia a Pontecorvo per bambini, ragazzi e adulti: come si valuta il caso e quali apparecchi esistono. Informazioni dallo studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "Di cosa si tratta",
        paragraphs: [
          "Con forze leggere e controllate, un apparecchio guida i denti verso una posizione più corretta. Si interviene su affollamenti, spazi tra i denti, morsi profondi o inversi e su altre alterazioni della chiusura.",
          "Esistono apparecchi fissi, con piccoli attacchi incollati sui denti, e apparecchi rimovibili. La scelta dipende dal tipo di problema, dall'età e dalle esigenze della persona.",
        ],
      },
      {
        heading: "A che età",
        paragraphs: [
          "Nei bambini una prima valutazione permette di intercettare per tempo alcune alterazioni della crescita delle arcate. Negli adulti il trattamento è possibile a qualsiasi età, se denti e gengive sono in salute.",
        ],
      },
      {
        heading: "Come si valuta il caso",
        paragraphs: [
          "Si parte da una visita, da fotografie, impronte (anche digitali, con scanner intraorale) e dagli esami radiografici necessari. Su questa base si definisce un piano con il tipo di apparecchio e una durata indicativa.",
        ],
      },
    ],
    faq: [
      {
        q: "Quanto dura un trattamento ortodontico?",
        a: "Dipende dal caso, dall'età e dalla collaborazione della persona. La durata indicativa viene spiegata nel piano di trattamento e può cambiare nel corso delle cure.",
      },
      {
        q: "L'apparecchio fa male?",
        a: "Nei giorni successivi all'applicazione o ai controlli si può avvertire un fastidio leggero e passeggero. Eventuali disturbi vanno sempre segnalati allo studio.",
      },
      {
        q: "Dopo il trattamento i denti restano fermi?",
        a: "Per mantenere il risultato si usano in genere dispositivi di contenzione e controlli periodici, secondo le indicazioni ricevute.",
      },
    ],
  },
  {
    slug: "ortodonzia-invisibile",
    title: "Ortodonzia invisibile",
    short:
      "Allineatori trasparenti e rimovibili per spostare gradualmente i denti, quando il caso lo consente.",
    image: "ortodonzia-invisibile",
    imageAlt: "Allineatore dentale trasparente accanto alla sua custodia, su una lastra di pietra chiara",
    imagePosition: "35% center",
    lead:
      "L'ortodonzia invisibile usa una serie di mascherine trasparenti, gli allineatori, realizzate su misura. Ogni mascherina sposta i denti di poco, seguendo un progetto digitale definito all'inizio del trattamento.",
    seoDescription:
      "Ortodonzia invisibile con allineatori trasparenti a Pontecorvo: come funziona, per chi è indicata e cosa richiede. Informazioni dallo studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "Come funziona",
        paragraphs: [
          "Si parte da una scansione digitale delle arcate con lo scanner intraorale, senza materiali da impronta. Sul modello tridimensionale si progettano i movimenti dei denti e si realizza la sequenza di allineatori.",
          "Gli allineatori sono trasparenti e poco visibili. Si tolgono per mangiare e per lavare i denti e vanno indossati per il numero di ore al giorno indicato dal dottore.",
        ],
      },
      {
        heading: "Per chi è indicata",
        paragraphs: [
          "È una possibilità per molti adulti e ragazzi, ma non per tutti i casi: alcune situazioni richiedono un apparecchio fisso o un approccio combinato. Lo si stabilisce solo dopo la visita e lo studio del caso.",
        ],
      },
      {
        heading: "La collaborazione conta",
        paragraphs: [
          "Il risultato dipende anche da quanto e come si indossano gli allineatori. Durante il percorso sono previsti controlli periodici per verificare che i denti si muovano come previsto.",
        ],
      },
    ],
    faq: [
      {
        q: "Gli allineatori si vedono?",
        a: "Sono trasparenti e poco visibili da vicino. In alcuni casi si applicano sui denti piccoli attacchi del colore del dente, che aiutano i movimenti.",
      },
      {
        q: "Quante ore al giorno vanno indossati?",
        a: "In genere per la maggior parte della giornata, notte compresa. Il numero di ore esatto viene indicato all'inizio del trattamento.",
      },
      {
        q: "È meglio dell'apparecchio fisso?",
        a: "Non esiste una soluzione migliore in assoluto: dipende dal caso. Dopo la visita il dottore spiega quali opzioni sono possibili, con vantaggi e limiti di ciascuna.",
      },
    ],
  },
  {
    slug: "prevenzione-e-igiene",
    title: "Prevenzione e igiene",
    short:
      "Igiene professionale, controlli periodici e consigli per la cura a casa: il modo più semplice per mantenere sani denti e gengive.",
    image: "prevenzione",
    imageAlt: "Spazzolino, scovolino e filo interdentale accanto a un bicchiere d'acqua su un piano in pietra",
    imagePosition: "35% center",
    lead:
      "La prevenzione è il trattamento più importante e il meno invasivo. Controlli regolari e sedute di igiene professionale aiutano a riconoscere presto carie e problemi gengivali, quando sono più semplici da gestire.",
    seoDescription:
      "Prevenzione e igiene dentale a Pontecorvo: igiene professionale, controlli periodici, cura domiciliare. Informazioni dallo studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "Igiene professionale",
        paragraphs: [
          "Durante la seduta si rimuovono placca e tartaro dalle superfici dei denti e sotto il margine gengivale, dove lo spazzolino non arriva. È anche l'occasione per controllare lo stato delle gengive.",
        ],
      },
      {
        heading: "Controlli periodici",
        paragraphs: [
          "La frequenza dei controlli si stabilisce in base al rischio individuale: non c'è un intervallo uguale per tutti. Chi ha impianti o protesi ha bisogno di un programma di mantenimento dedicato.",
        ],
      },
      {
        heading: "La cura a casa",
        paragraphs: [
          "Spazzolino, filo interdentale o scovolini: gli strumenti e la tecnica vengono scelti e mostrati in base alla bocca di ciascuno, perché ciò che funziona per una persona non è detto funzioni per un'altra.",
        ],
      },
    ],
    faq: [
      {
        q: "Ogni quanto fare l'igiene professionale?",
        a: "Dipende dalla salute delle gengive, dall'accumulo di tartaro e dalla presenza di impianti o protesi. L'intervallo viene indicato dopo la visita.",
      },
      {
        q: "Sanguinare durante lo spazzolamento è normale?",
        a: "Il sanguinamento delle gengive è un segnale da non trascurare e merita una visita di controllo.",
      },
      {
        q: "I bambini possono essere visitati?",
        a: "Sì, lo studio segue pazienti di ogni età. Per i più piccoli la prima visita è anche un modo per familiarizzare con l'ambiente.",
      },
    ],
  },
  {
    slug: "valutazioni-gnatologiche",
    title: "Valutazioni gnatologiche e odontoiatriche",
    short:
      "La prima visita, lo studio dell'occlusione e dell'articolazione della mandibola, e le valutazioni che precedono ogni piano di cura.",
    image: "gnatologia",
    imageAlt: "Modelli in gesso delle arcate dentali in occlusione",
    lead:
      "Ogni percorso inizia da una valutazione: la storia clinica, l'esame della bocca e, quando serve, lo studio di come combaciano i denti e di come lavora l'articolazione della mandibola.",
    seoDescription:
      "Prima visita odontoiatrica e visita gnatologica a Pontecorvo: occlusione, articolazione temporo-mandibolare, valutazione iniziale. Studio del Dott. Vincenzo Mazzetti.",
    sections: [
      {
        heading: "La prima visita",
        paragraphs: [
          "È il momento in cui si raccolgono le informazioni sulla salute generale e orale, si ascoltano le richieste del paziente e si esamina la bocca. Se servono esami radiografici, vengono indicati e spiegati.",
          "Al termine il paziente riceve una spiegazione di ciò che è emerso e, se necessario, un piano di trattamento con le possibili alternative.",
        ],
      },
      {
        heading: "La visita gnatologica",
        paragraphs: [
          "La gnatologia studia il rapporto tra denti, muscoli masticatori e articolazione temporo-mandibolare. Se ne parla, per esempio, in presenza di dolori o rumori all'apertura della bocca, di usura dei denti o prima di riabilitazioni estese.",
        ],
      },
      {
        heading: "Valutazioni e certificazioni",
        paragraphs: [
          "Lo studio rilascia le certificazioni odontoiatriche richieste dal paziente. Il Dott. Mazzetti ha conseguito il Master universitario di secondo livello in Medicina Legale Odontostomatologica, l'ambito che si occupa della valutazione e della documentazione in odontoiatria.",
        ],
      },
    ],
    faq: [
      {
        q: "Cosa portare alla prima visita?",
        a: "Eventuali radiografie recenti, l'elenco dei farmaci assunti e la documentazione di trattamenti precedenti, se disponibile.",
      },
      {
        q: "Il dolore alla mandibola dipende dai denti?",
        a: "Può dipendere da cause diverse, non solo dentali. Una valutazione aiuta a capire se l'origine è nell'articolazione, nei muscoli o nell'occlusione, e quando è utile il confronto con altri specialisti.",
      },
      {
        q: "Quanto dura la prima visita?",
        a: "Dipende dalla complessità del caso. Al momento della prenotazione lo studio indica il tempo da riservare.",
      },
    ],
  },
];

export const getTreatment = (slug: string) => treatments.find((t) => t.slug === slug);
