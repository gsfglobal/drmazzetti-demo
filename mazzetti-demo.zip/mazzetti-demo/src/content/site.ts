// Dati dello studio. Tutto ciò che il cliente può voler cambiare (orari,
// telefono, email, dati legali) si modifica qui, senza toccare i componenti.
//
// `demo: true` mostra l'etichetta «Concept dimostrativo», i segni «da confermare»
// e imposta il sito come non indicizzabile. Va messo a `false` dopo l'approvazione.

export const site = {
  demo: true,

  name: "Studio Dentistico Dott. Vincenzo Mazzetti",
  shortName: "Studio Mazzetti",
  doctor: "Dott. Vincenzo Mazzetti",
  doctorName: "Vincenzo Mazzetti",
  role: "Odontoiatra",
  tagline: "Odontoiatria a Pontecorvo",

  url: "https://gsfglobal.github.io/mazzetti-demo",

  address: {
    street: "Piazza Giacinto Carbone 1",
    postalCode: "03037",
    city: "Pontecorvo",
    province: "FR",
    region: "Lazio",
    country: "IT",
  },
  geo: { lat: 41.458313, lng: 13.6680136 },
  mapsUrl:
    "https://www.google.com/maps/search/?api=1&query=Piazza+Giacinto+Carbone+1+03037+Pontecorvo+FR",

  phone: { display: "380 474 0500", href: "tel:+393804740500", e164: "+393804740500" },
  // Secondo numero riportato sul biglietto dello studio nella scheda pubblica
  phoneAlt: { display: "331 913 3996", href: "tel:+393319133996", verify: true },
  email: "vincenzomazzetti1992@gmail.com",

  appointmentNote: "Lo studio riceve su appuntamento.",
  // Orari indicati in una directory pubblica: da confermare con lo studio
  hoursVerify: true,
  hours: [
    { day: "Lunedì", time: "8:00 – 20:00" },
    { day: "Martedì", time: "Chiuso" },
    { day: "Mercoledì", time: "8:00 – 20:00" },
    { day: "Giovedì", time: "Chiuso" },
    { day: "Venerdì", time: "13:30 – 18:00" },
    { day: "Sabato", time: "8:00 – 20:00" },
    { day: "Domenica", time: "Chiuso" },
  ],
  hoursSchema: [
    { days: ["Monday", "Wednesday", "Saturday"], opens: "08:00", closes: "20:00" },
    { days: ["Friday"], opens: "13:30", closes: "18:00" },
  ],

  social: {
    instagram: "https://www.instagram.com/studiodentisticomazzetti/",
  },

  // Dati obbligatori per la comunicazione sanitaria: da completare prima della
  // pubblicazione definitiva.
  legal: {
    owner: "Dott. Vincenzo Mazzetti",
    director: "Dott. Vincenzo Mazzetti",
    register: "Iscrizione all'Albo degli Odontoiatri: n. e Ordine da completare",
    vat: "P. IVA da completare",
  },

  agency: { name: "Dental Go", url: "https://dentalgo.it" },
} as const;

export const nav = [
  { href: "/il-dottore/", label: "Il dottore" },
  { href: "/trattamenti/", label: "Trattamenti" },
  { href: "/ricerca/", label: "Ricerca" },
  { href: "/lo-studio/", label: "Lo studio" },
  { href: "/contatti/", label: "Contatti" },
] as const;

export const fullAddress = `${site.address.street}, ${site.address.postalCode} ${site.address.city} (${site.address.province})`;
