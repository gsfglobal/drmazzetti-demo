import { PageIntro } from "@/components/layout/PageIntro";
import { TreatmentsGrid } from "@/components/home/TreatmentsGrid";
import { ContactSection } from "@/components/home/ContactSection";
import { illustrativeNote } from "@/content/studio";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Trattamenti",
  description:
    "Trattamenti odontoiatrici a Pontecorvo: implantologia, chirurgia orale, protesi e riabilitazione, estetica dentale, prevenzione e igiene, valutazioni gnatologiche. Studio del Dott. Vincenzo Mazzetti.",
  path: "/trattamenti/",
});

export default function TreatmentsPage() {
  return (
    <>
      <PageIntro
        crumbs={[{ name: "Trattamenti", path: "/trattamenti/" }]}
        title={["Le aree di cura,", "un unico metodo."]}
        lead="Ogni percorso parte da una valutazione: cosa serve davvero, quali sono le alternative, con quali tempi. Qui trovi informazioni per orientarti prima della visita."
        aside={<p className="mt-4 text-[0.8rem] text-steel-ink">{illustrativeNote}</p>}
      />
      <TreatmentsGrid withHeader={false} />
      <ContactSection />
    </>
  );
}
