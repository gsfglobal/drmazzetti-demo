import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight, Phone } from "lucide-react";
import { PageIntro } from "@/components/layout/PageIntro";
import { Photo } from "@/components/ui/Photo";
import { FadeIn, RevealText } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { Accordion } from "@/components/ui/Accordion";
import { TreatmentCard } from "@/components/home/TreatmentCard";
import { treatments, getTreatment } from "@/content/treatments";
import { site } from "@/content/site";
import { JsonLd, faqJsonLd, pageMeta, pageUrl } from "@/lib/seo";

export function generateStaticParams() {
  return treatments.map((t) => ({ slug: t.slug }));
}

export const dynamicParams = false;

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const t = getTreatment(slug);
  if (!t) return {};
  return pageMeta({ title: `${t.title} a Pontecorvo`, description: t.seoDescription, path: `/trattamenti/${t.slug}/` });
}

export default async function TreatmentPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const t = getTreatment(slug);
  if (!t) notFound();
  const others = treatments.filter((o) => o.slug !== t.slug).slice(0, 3);
  const idx = treatments.findIndex((o) => o.slug === t.slug);
  const next = treatments[(idx + 1) % treatments.length];

  // Titolo spezzato su due righe per l'animazione
  const words = t.title.split(" ");
  const half = Math.ceil(words.length / 2);
  const titleLines = words.length > 2 ? [words.slice(0, half).join(" "), words.slice(half).join(" ")] : [t.title];

  return (
    <>
      <PageIntro
        crumbs={[
          { name: "Trattamenti", path: "/trattamenti/" },
          { name: t.title, path: `/trattamenti/${t.slug}/` },
        ]}
        title={titleLines}
        lead={t.short}
      />

      <div className="wrap">
        <Photo
          src={t.image}
          alt={t.imageAlt}
          priority
          reveal={false}
          sizes="100vw"
          className="aspect-[4/3] w-full sm:aspect-[16/9] lg:aspect-[21/9]"
          tag="Immagine illustrativa"
          position={t.imagePosition}
        />
      </div>

      <article className="section">
        <div className="wrap grid gap-y-14 lg:grid-cols-12 lg:gap-x-10">
          <aside className="order-2 lg:order-1 lg:col-span-4">
            <div className="space-y-6 lg:sticky lg:top-28">
              <div className="rounded-[1.25rem] border border-[var(--line)] bg-paper p-7">
                <p className="font-serif text-[1.6rem] leading-tight">Hai domande su questo trattamento?</p>
                <p className="mt-3 text-[0.95rem] text-steel-ink">
                  La valutazione si fa in studio. Chiama per fissare una visita o lascia i tuoi recapiti.
                </p>
                <div className="mt-6 flex flex-col gap-3">
                  <ButtonLink href={site.phone.href} icon={<Phone size={16} strokeWidth={1.6} aria-hidden="true" />}>
                    Chiama lo studio
                  </ButtonLink>
                  <ButtonLink href="/contatti/#richiesta" variant="outline">
                    Richiedi informazioni
                  </ButtonLink>
                </div>
              </div>
              <nav aria-label="Altri trattamenti" className="hidden lg:block">
                <p className="label mb-3">Altri trattamenti</p>
                <ul className="space-y-2">
                  {treatments
                    .filter((o) => o.slug !== t.slug)
                    .map((o) => (
                      <li key={o.slug}>
                        <Link href={`/trattamenti/${o.slug}/`} className="link-draw text-[0.95rem]">
                          {o.title}
                        </Link>
                      </li>
                    ))}
                </ul>
              </nav>
            </div>
          </aside>

          <div className="order-1 lg:order-2 lg:col-span-7 lg:col-start-6">
            <FadeIn>
              <p className="font-serif text-[1.65rem] leading-snug sm:text-[2rem]">{t.lead}</p>
            </FadeIn>

            {t.sections.map((s) => (
              <FadeIn key={s.heading} className="mt-14">
                <h2 className="display-sm">{s.heading}</h2>
                <div className="prose-body mt-4 text-[1.04rem] leading-[1.75] text-ink/90">
                  {s.paragraphs.map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              </FadeIn>
            ))}

            {t.checklist && (
              <FadeIn className="mt-14 rounded-[1.25rem] bg-paper p-7 sm:p-9">
                <h2 className="display-sm">{t.checklist.heading}</h2>
                <ol className="mt-6 space-y-4">
                  {t.checklist.items.map((it, i) => (
                    <li key={it} className="grid grid-cols-[2rem_1fr] gap-3 border-t border-[var(--line)] pt-4">
                      <span className="font-serif text-[1.2rem] tabular-nums text-steel-ink">{i + 1}</span>
                      <span>{it}</span>
                    </li>
                  ))}
                </ol>
                <p className="mt-6 text-[0.82rem] text-steel-ink">
                  Passaggi e tempi si definiscono per ogni paziente dopo la visita.
                </p>
              </FadeIn>
            )}

            <div className="mt-16">
              <h2 className="display-sm mb-4">Domande frequenti</h2>
              <Accordion items={t.faq} />
              <p className="mt-6 text-[0.85rem] text-steel-ink">
                Le risposte sono informative e non sostituiscono la valutazione clinica.
              </p>
            </div>
          </div>
        </div>
      </article>

      <section aria-labelledby="altri-title" className="section border-t border-[var(--line)] bg-paper">
        <div className="wrap">
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
            <RevealText as="h2" id="altri-title" lines={["Altre aree", "di cura"]} className="display-md" />
            <ButtonLink href={`/trattamenti/${next.slug}/`} variant="outline" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
              {next.title}
            </ButtonLink>
          </div>
          <div className="mt-12 grid gap-x-8 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
            {others.map((o) => (
              <TreatmentCard key={o.slug} t={o} />
            ))}
          </div>
        </div>
      </section>

      <JsonLd data={faqJsonLd(t.faq)} />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "MedicalWebPage",
          name: t.title,
          url: pageUrl(`/trattamenti/${t.slug}/`),
          about: { "@type": "MedicalProcedure", name: t.title },
          inLanguage: "it",
          isPartOf: { "@id": `${site.url}/#studio` },
        }}
      />
    </>
  );
}
