import { Hero } from "@/components/home/Hero";
import { Philosophy } from "@/components/home/Philosophy";
import { DoctorPreview } from "@/components/home/DoctorPreview";
import { TreatmentsGrid } from "@/components/home/TreatmentsGrid";
import { ImplantFocus } from "@/components/home/ImplantFocus";
import { ResearchSection } from "@/components/home/ResearchSection";
import { StudioSection } from "@/components/home/StudioSection";
import { PatientPath } from "@/components/home/PatientPath";
import { FaqSection } from "@/components/home/FaqSection";
import { ContactSection } from "@/components/home/ContactSection";
import { homeFaq } from "@/content/faq";
import { JsonLd, faqJsonLd, personJsonLd, pageMeta } from "@/lib/seo";

export const metadata = {
  ...pageMeta({
    title: "Dott. Vincenzo Mazzetti — Odontoiatra a Pontecorvo",
    description:
      "Dentista a Pontecorvo (FR). Il Dott. Vincenzo Mazzetti, odontoiatra e dottore di ricerca all'Università di Roma Tor Vergata: implantologia, chirurgia orale, protesi e prevenzione.",
    path: "/",
  }),
  title: { absolute: "Dott. Vincenzo Mazzetti — Odontoiatra a Pontecorvo" },
};

export default function Home() {
  return (
    <>
      <Hero />
      <Philosophy />
      <DoctorPreview />
      <TreatmentsGrid />
      <ImplantFocus />
      <ResearchSection />
      <StudioSection />
      <PatientPath />
      <FaqSection items={homeFaq} />
      <ContactSection />
      <JsonLd data={faqJsonLd(homeFaq)} />
      <JsonLd data={personJsonLd()} />
    </>
  );
}
