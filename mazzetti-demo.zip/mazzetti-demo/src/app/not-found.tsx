import { ButtonLink } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <section className="wrap flex min-h-[80svh] flex-col items-start justify-center pt-[var(--header-h)]">
      <p className="label">Errore 404</p>
      <h1 className="display-xl mt-4">Pagina non trovata.</h1>
      <p className="lead mt-6 max-w-[30rem]">L&apos;indirizzo potrebbe essere cambiato. Torna alla home o contatta lo studio.</p>
      <div className="mt-10 flex flex-wrap gap-3">
        <ButtonLink href="/">Torna alla home</ButtonLink>
        <ButtonLink href="/contatti/" variant="outline">
          Contatti
        </ButtonLink>
      </div>
    </section>
  );
}
