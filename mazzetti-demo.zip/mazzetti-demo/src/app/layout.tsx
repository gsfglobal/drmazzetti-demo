import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import { MotionConfig } from "motion/react";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { StickyActions } from "@/components/layout/StickyActions";
import { site } from "@/content/site";
import { JsonLd, dentistJsonLd } from "@/lib/seo";

const serif = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["500", "600"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});
const sans = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(site.url + "/"),
  title: {
    default: "Dott. Vincenzo Mazzetti — Odontoiatra a Pontecorvo",
    template: "%s — Dott. Vincenzo Mazzetti, odontoiatra a Pontecorvo",
  },
  description:
    "Studio dentistico del Dott. Vincenzo Mazzetti a Pontecorvo (FR): implantologia, chirurgia orale, protesi, estetica, prevenzione. Formazione e ricerca all'Università di Roma Tor Vergata.",
  applicationName: site.name,
  // La versione dimostrativa non va indicizzata
  robots: site.demo ? { index: false, follow: false } : { index: true, follow: true },
  icons: { icon: [{ url: `${process.env.NEXT_PUBLIC_BASE_PATH ?? ""}/favicon.svg`, type: "image/svg+xml" }] },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#f7f5f0",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it" className={`${serif.variable} ${sans.variable}`}>
      <body>
        <MotionConfig reducedMotion="user">
          <Header />
          <main id="contenuto">{children}</main>
          <Footer />
          <StickyActions />
        </MotionConfig>
        <JsonLd data={dentistJsonLd()} />
      </body>
    </html>
  );
}
