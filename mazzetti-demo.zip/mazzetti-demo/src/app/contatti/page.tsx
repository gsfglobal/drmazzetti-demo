import { ContactSection } from "@/components/home/ContactSection";
import { FaqSection } from "@/components/home/FaqSection";
import { homeFaq } from "@/content/faq";
import { JsonLd, breadcrumbJsonLd, pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Contatti",
  description:
    "Contatta lo studio dentistico del Dott. Vincenzo Mazzetti a Pontecorvo: telefono, email, indirizzo e richiesta di informazioni per fissare una visita.",
  path: "/contatti/",
});

export default function ContactPage() {
  return (
    <>
      <div className="h-[var(--header-h)] bg-ivory" aria-hidden="true" />
      <ContactSection headingLevel="h1" />
      <FaqSection items={homeFaq.slice(0, 5)} title={["Prima di", "chiamare"]} />
      <JsonLd data={breadcrumbJsonLd([{ name: "Contatti", path: "/contatti/" }])} />
    </>
  );
}
