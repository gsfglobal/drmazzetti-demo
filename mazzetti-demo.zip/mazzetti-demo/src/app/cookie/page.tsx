import { LegalPage } from "@/components/layout/LegalPage";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Cookie policy",
  description: "Informazioni sull'uso dei cookie nel sito dello Studio Dentistico Dott. Vincenzo Mazzetti.",
  path: "/cookie/",
});

export default function CookiePage() {
  return (
    <LegalPage
      title="Cookie policy"
      path="/cookie/"
      sections={[
        {
          heading: "Cookie utilizzati",
          body: [
            "Questo sito non installa cookie di profilazione né cookie di terze parti. I caratteri tipografici sono ospitati sullo stesso server del sito e la mappa si apre su Google Maps solo se scegli di farlo.",
            "Per questo motivo il sito non mostra un banner per il consenso. [Da aggiornare se verranno aggiunti strumenti di statistica, pixel pubblicitari o contenuti incorporati: in quel caso servirà un banner con consenso preventivo.]",
          ],
        },
        {
          heading: "Collegamenti esterni",
          body: [
            "Alcuni link portano a siti esterni, per esempio le riviste scientifiche, PubMed, ResearchGate, Instagram e Google Maps. Questi siti hanno proprie politiche sui cookie, che ti invitiamo a consultare.",
          ],
        },
        {
          heading: "Come gestire i cookie",
          body: ["Puoi in ogni momento cancellare o bloccare i cookie dalle impostazioni del tuo browser."],
        },
      ]}
    />
  );
}
