/**
 * Transizione tra le pagine: dissolvenza breve in CSS, rilanciata a ogni
 * cambio di pagina (il template si rimonta). Non blocca il primo paint.
 */
export default function Template({ children }: { children: React.ReactNode }) {
  return <div className="page-enter">{children}</div>;
}
