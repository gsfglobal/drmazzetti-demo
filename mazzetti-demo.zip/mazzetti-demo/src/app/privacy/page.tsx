import { LegalPage } from "@/components/layout/LegalPage";
import { site, fullAddress } from "@/content/site";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Informativa privacy",
  description: "Informativa sul trattamento dei dati personali dello Studio Dentistico Dott. Vincenzo Mazzetti.",
  path: "/privacy/",
});

export default function PrivacyPage() {
  return (
    <LegalPage
      title="Informativa privacy"
      path="/privacy/"
      sections={[
        {
          heading: "Titolare del trattamento",
          body: [
            `Il titolare del trattamento è ${site.legal.owner}, ${site.name}, con sede in ${fullAddress}. Email: ${site.email}. [P. IVA e PEC da completare]`,
          ],
        },
        {
          heading: "Dati trattati tramite il sito",
          body: [
            "Tramite il modulo di contatto vengono raccolti nome e cognome, numero di telefono, eventuale indirizzo email, la fascia oraria preferita e un messaggio facoltativo. Il modulo non chiede informazioni sulla salute: ti invitiamo a non inserirle.",
            "Il sito non utilizza cookie di profilazione né strumenti di statistica. [Da aggiornare se verranno attivati servizi di analisi, mappe incorporate o altri servizi di terze parti.]",
          ],
        },
        {
          heading: "Finalità e base giuridica",
          body: [
            "I dati sono usati esclusivamente per rispondere alla tua richiesta e ricontattarti per fissare un appuntamento. La base giuridica è l'esecuzione di misure precontrattuali adottate su tua richiesta (art. 6, par. 1, lett. b GDPR).",
            "I dati non vengono usati per finalità di marketing e non vengono comunicati a terzi, salvo i fornitori tecnici che gestiscono il sito e la posta elettronica, nominati responsabili del trattamento. [Elenco dei fornitori da completare]",
          ],
        },
        {
          heading: "Conservazione",
          body: ["I dati sono conservati per il tempo necessario a gestire la richiesta. [Periodo di conservazione da definire]"],
        },
        {
          heading: "I tuoi diritti",
          body: [
            `Puoi chiedere l'accesso ai tuoi dati, la rettifica, la cancellazione, la limitazione o l'opposizione al trattamento scrivendo a ${site.email}. Hai inoltre il diritto di proporre reclamo al Garante per la protezione dei dati personali (www.garanteprivacy.it).`,
          ],
        },
      ]}
    />
  );
}
