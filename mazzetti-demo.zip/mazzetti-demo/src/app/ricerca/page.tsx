import { PageIntro } from "@/components/layout/PageIntro";
import { FadeIn, RevealText } from "@/components/ui/Reveal";
import { Photo } from "@/components/ui/Photo";
import { PublicationEntry } from "@/components/home/PublicationEntry";
import { publications, themes, thesis, researchProfiles } from "@/content/publications";
import { JsonLd, pageMeta, pageUrl } from "@/lib/seo";
import { site } from "@/content/site";

export const metadata = pageMeta({
  title: "Ricerca e pubblicazioni",
  description:
    "Il dottorato di ricerca e le pubblicazioni scientifiche del Dott. Vincenzo Mazzetti: impronte digitali e implantologia, rigenerazione ossea, chirurgia orale, parodontologia. Sintesi per i pazienti e link alle fonti.",
  path: "/ricerca/",
});

export default function ResearchPage() {
  const sorted = [...publications].sort((a, b) => b.year - a.year);
  return (
    <>
      <PageIntro
        crumbs={[{ name: "Ricerca e pubblicazioni", path: "/ricerca/" }]}
        title={["Oltre la pratica clinica.", "Il valore della ricerca."]}
        lead="Il dottorato a Tor Vergata e gli articoli scritti con il gruppo di ricerca universitario, raccontati in modo comprensibile, con il collegamento alle fonti originali."
      />

      {/* Il dottorato */}
      <section aria-labelledby="tesi-title" className="on-dark grain relative overflow-hidden bg-ink text-ivory">
        <div className="wrap section relative grid gap-y-12 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-5">
            <Photo
              src="microscopio"
              alt="Microscopio da laboratorio in bianco e nero"
              sizes="(min-width: 1024px) 38vw, 100vw"
              className="aspect-[4/5] w-full"
              tag="Immagine illustrativa"
              position="center 35%"
            />
          </div>
          <div className="lg:col-span-6 lg:col-start-7 lg:self-center">
            <p className="label">Tesi di dottorato · {thesis.year}</p>
            <h2 id="tesi-title" className="mt-4 font-serif text-[1.9rem] leading-snug italic sm:text-[2.4rem]" lang="en">
              {thesis.title}
            </h2>
            <p className="mt-5 text-[0.9rem] text-[rgb(247_245_240/0.62)]">
              {thesis.venue} · {thesis.details}
            </p>
            <p className="mt-6 text-[rgb(247_245_240/0.85)]">{thesis.summary}</p>
            <p className="mt-6 text-[0.95rem] text-[rgb(247_245_240/0.72)]">
              In parole semplici: la ricerca riguarda come trasferire con precisione un progetto digitale nella bocca del
              paziente, in una zona — quella dei denti anteriori — dove anche piccoli scostamenti contano per l&apos;estetica.
            </p>
            <a
              href={thesis.links[0].href}
              target="_blank"
              rel="noopener noreferrer"
              className="link-line mt-8 inline-block text-[0.95rem]"
            >
              Scheda nell&apos;archivio istituzionale IRIS<span className="sr-only"> (si apre in una nuova scheda)</span>
            </a>
          </div>
        </div>
      </section>

      {/* Per area tematica */}
      {themes.map((th) => {
        const list = sorted.filter((p) => p.theme === th.id);
        if (!list.length) return null;
        return (
          <section key={th.id} aria-labelledby={`tema-${th.id}`} className="section border-t border-[var(--line)] first-of-type:border-0">
            <div className="wrap grid gap-y-8 lg:grid-cols-12 lg:gap-x-10">
              <div className="lg:col-span-4">
                <div className="lg:sticky lg:top-28">
                  <RevealText as="h2" id={`tema-${th.id}`} lines={[th.title]} className="display-md" />
                  <FadeIn>
                    <p className="mt-4 max-w-[22rem] text-steel-ink">{th.intro}</p>
                    <p className="label mt-6 tabular-nums">
                      {list.length} {list.length === 1 ? "pubblicazione" : "pubblicazioni"}
                    </p>
                  </FadeIn>
                </div>
              </div>
              <div className="lg:col-span-8">
                {list.map((p) => (
                  <FadeIn key={p.id}>
                    <PublicationEntry p={p} />
                  </FadeIn>
                ))}
              </div>
            </div>
          </section>
        );
      })}

      <section className="border-t border-[var(--line)] bg-paper py-16">
        <div className="wrap grid gap-8 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-7">
            <h2 className="display-sm">Come leggere questa pagina</h2>
            <p className="mt-4 text-steel-ink">
              Gli articoli sono firmati da più autori, come avviene di norma nella ricerca universitaria. Le sintesi sono
              parafrasi divulgative e non sostituiscono la lettura dei testi originali né una valutazione clinica: i
              risultati di uno studio non si traducono automaticamente nel singolo caso. Elenco aggiornato a ottobre 2026.
            </p>
          </div>
          <div className="lg:col-span-4 lg:col-start-9">
            <p className="label">Profili di ricerca</p>
            <ul className="mt-3 space-y-2">
              {researchProfiles.map((r) => (
                <li key={r.href}>
                  <a href={r.href} target="_blank" rel="noopener noreferrer" className="link-line">
                    {r.label}
                    <span className="sr-only"> (si apre in una nuova scheda)</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Ricerca e pubblicazioni",
          url: pageUrl("/ricerca/"),
          about: { "@id": `${site.url}/il-dottore/#persona` },
          hasPart: [thesis, ...publications].map((p) => ({
            "@type": "ScholarlyArticle",
            headline: p.title,
            datePublished: String(p.year),
            isPartOf: p.venue,
            url: p.links[0]?.href,
          })),
        }}
      />
    </>
  );
}
