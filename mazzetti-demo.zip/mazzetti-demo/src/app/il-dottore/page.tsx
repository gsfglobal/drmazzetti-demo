import { ArrowRight } from "lucide-react";
import { PageIntro } from "@/components/layout/PageIntro";
import { Portrait } from "@/components/home/Portrait";
import { Timeline } from "@/components/home/Timeline";
import { FadeIn, RevealText } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { PublicationEntry } from "@/components/home/PublicationEntry";
import { doctorIntro } from "@/content/doctor";
import { publications } from "@/content/publications";
import { JsonLd, pageMeta, personJsonLd } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Il dottore",
  description:
    "Il Dott. Vincenzo Mazzetti, odontoiatra a Pontecorvo: laurea con lode e dottorato di ricerca all'Università di Roma Tor Vergata, formazione in protesi fissa e Master in Medicina Legale Odontostomatologica.",
  path: "/il-dottore/",
});

export default function DoctorPage() {
  const latest = [...publications].sort((a, b) => b.year - a.year).slice(0, 2);
  return (
    <>
      <PageIntro
        crumbs={[{ name: "Il dottore", path: "/il-dottore/" }]}
        title={["Vincenzo Mazzetti.", "La conoscenza al", "servizio della cura."]}
        lead={doctorIntro.lead}
      />

      <section aria-label="Biografia" className="pb-[var(--section-y)]">
        <div className="wrap grid gap-y-14 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <Portrait className="aspect-[4/5] w-full" />
            </div>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <div className="prose-body space-y-5 text-[1.08rem] leading-[1.75]">
              {doctorIntro.body.map((p, i) => (
                <FadeIn as="p" key={i} delay={i * 0.05}>
                  {p}
                </FadeIn>
              ))}
            </div>

            <FadeIn className="mt-12 border-t border-[var(--line)] pt-8">
              <h2 className="label">Aree di interesse clinico</h2>
              <ul className="mt-4 flex flex-wrap gap-2">
                {doctorIntro.interests.map((t) => (
                  <li key={t} className="rounded-full border border-[var(--line-strong)] px-4 py-2 text-[0.92rem]">
                    {t}
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-[0.82rem] text-steel-ink">
                Aree di attività prevalente. Non indicano titoli di specializzazione.
              </p>
            </FadeIn>
          </div>
        </div>
      </section>

      <section aria-labelledby="percorso-prof" className="section border-t border-[var(--line)] bg-paper">
        <div className="wrap grid gap-y-12 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-5">
            <RevealText as="h2" id="percorso-prof" lines={["Il percorso", "professionale"]} className="display-lg" />
            <FadeIn>
              <p className="mt-6 max-w-[24rem] text-steel-ink">
                Riportiamo solo titoli ed esperienze documentati pubblicamente. Apri ogni tappa per i dettagli.
              </p>
            </FadeIn>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <Timeline initial={2} />
          </div>
        </div>
      </section>

      <section aria-labelledby="ultime-pub" className="section border-t border-[var(--line)]">
        <div className="wrap">
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
            <RevealText as="h2" id="ultime-pub" lines={["Le pubblicazioni", "più recenti"]} className="display-md" />
            <ButtonLink href="/ricerca/" variant="outline" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
              Tutte le pubblicazioni
            </ButtonLink>
          </div>
          <div className="mt-10">
            {latest.map((p) => (
              <PublicationEntry key={p.id} p={p} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-[var(--line)] py-20">
        <div className="wrap flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
          <p className="display-md max-w-[28ch]">Per una prima visita puoi chiamare lo studio o lasciare i tuoi recapiti.</p>
          <ButtonLink href="/contatti/#prenota" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
            Prenota una visita
          </ButtonLink>
        </div>
      </section>
      <JsonLd data={personJsonLd()} />
    </>
  );
}
