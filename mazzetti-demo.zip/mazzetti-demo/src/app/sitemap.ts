import type { MetadataRoute } from "next";
import { site } from "@/content/site";
import { treatments } from "@/content/treatments";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const paths = ["/", "/il-dottore/", "/trattamenti/", ...treatments.map((t) => `/trattamenti/${t.slug}/`), "/ricerca/", "/lo-studio/", "/contatti/", "/privacy/", "/cookie/"];
  return paths.map((p) => ({
    url: `${site.url}${p}`,
    lastModified: new Date("2026-10-17"),
    changeFrequency: "monthly",
    priority: p === "/" ? 1 : 0.7,
  }));
}
