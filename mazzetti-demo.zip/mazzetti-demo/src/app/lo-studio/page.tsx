import { ArrowRight, MapPin } from "lucide-react";
import { PageIntro } from "@/components/layout/PageIntro";
import { Photo } from "@/components/ui/Photo";
import { AutoVideo } from "@/components/ui/AutoVideo";
import { FadeIn, RevealText } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { studioPhotos, studioPhotoNote, studioFeatures } from "@/content/studio";
import { site, fullAddress } from "@/content/site";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Lo studio",
  description: `Lo studio dentistico del Dott. Vincenzo Mazzetti in ${fullAddress}. Orari, come raggiungerci e contatti.`,
  path: "/lo-studio/",
});

export default function StudioPage() {
  const [a, b, c, d, e] = studioPhotos;
  return (
    <>
      <PageIntro
        crumbs={[{ name: "Lo studio", path: "/lo-studio/" }]}
        title={["Uno spazio dedicato", "alla tua salute orale."]}
        lead={`In ${fullAddress}. Lo studio riceve su appuntamento.`}
      />

      <section aria-label="Fotografie dello studio" className="pb-[var(--section-y)]">
        <div className="wrap grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-12">
          <Photo src={a.src} alt={a.alt} priority sizes="100vw" className="col-span-2 aspect-[4/3] lg:col-span-12 lg:aspect-[21/9]" position="center 55%" />
          <figure className="col-span-2 lg:col-span-7">
            <Photo src={b.src} alt={b.alt} sizes="(min-width: 1024px) 58vw, 100vw" className="aspect-[4/3]" />
            <figcaption className="label mt-3">{b.caption}</figcaption>
          </figure>
          <figure className="col-span-1 lg:col-span-5 lg:mt-32">
            <Photo src={d.src} alt={d.alt} sizes="(min-width: 1024px) 40vw, 50vw" className="aspect-[3/4]" />
            <figcaption className="label mt-3">{d.caption}</figcaption>
          </figure>
          <figure className="col-span-1 lg:col-span-5 lg:col-start-2">
            <Photo src={c.src} alt={c.alt} sizes="(min-width: 1024px) 40vw, 50vw" className="aspect-[3/4] lg:aspect-[4/3]" />
            <figcaption className="label mt-3">{c.caption}</figcaption>
          </figure>
          <figure className="col-span-2 lg:col-span-5 lg:col-start-8 lg:mt-24">
            <Photo src={e.src} alt={e.alt} sizes="(min-width: 1024px) 40vw, 100vw" className="aspect-[4/3]" />
            <figcaption className="label mt-3">{e.caption}</figcaption>
          </figure>
          <p className="col-span-2 mt-4 max-w-[40rem] text-[0.82rem] text-steel-ink lg:col-span-8">{studioPhotoNote}</p>
        </div>
      </section>

      <section aria-labelledby="dotazioni-title" className="section border-t border-[var(--line)]">
        <div className="wrap grid gap-y-12 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-5">
            <RevealText as="h2" id="dotazioni-title" lines={["Ambienti e tecnologie"]} className="display-lg" />
            <div className="mt-10">
              {studioFeatures.map((f, i) => (
                <FadeIn key={f.title} delay={i * 0.08} className="border-t border-[var(--line)] py-6">
                  <h3 className="font-serif text-[1.6rem] leading-tight">{f.title}</h3>
                  <p className="mt-2 text-steel-ink">{f.text}</p>
                </FadeIn>
              ))}
            </div>
          </div>
          <FadeIn className="lg:col-span-6 lg:col-start-7 lg:self-center">
            <AutoVideo
              src="/video/sala-chirurgica"
              poster="/video/sala-chirurgica-poster.jpg"
              label="Video della sala chirurgica dello studio: la porta in vetro con la scritta Sala chirurgica e il riunito all'interno"
              className="mx-auto w-full max-w-[23rem] lg:max-w-[24rem]"
              caption="La sala chirurgica dello studio"
            />
          </FadeIn>
        </div>
      </section>

      <section aria-labelledby="dove-title" className="section border-t border-[var(--line)] bg-paper">
        <div className="wrap grid gap-y-12 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-6">
            <RevealText as="h2" id="dove-title" lines={["Dove siamo"]} className="display-lg" />
            <FadeIn>
              <p className="mt-6 flex items-start gap-3 text-[1.1rem]">
                <MapPin size={20} strokeWidth={1.4} className="mt-1 shrink-0 text-steel-ink" aria-hidden="true" />
                <span>{fullAddress}</span>
              </p>
              <p className="mt-4 max-w-[30rem] text-steel-ink">
                Apri l&apos;indirizzo in Google Maps per calcolare il percorso dal punto in cui ti trovi. Per informazioni su
                accessibilità e parcheggio puoi chiedere direttamente allo studio.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <ButtonLink href={site.mapsUrl} external icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
                  Apri in Google Maps
                </ButtonLink>
                <ButtonLink href={site.phone.href} variant="outline">
                  Chiama lo studio
                </ButtonLink>
              </div>
            </FadeIn>
          </div>
          <FadeIn className="lg:col-span-5 lg:col-start-8">
            <h3 className="label">
              Orari
            </h3>
            <table className="mt-4 w-full text-[1rem]">
              <caption className="sr-only">Orari di apertura dello studio</caption>
              <tbody>
                {site.hours.map((h) => (
                  <tr key={h.day} className="border-b border-[var(--line)]">
                    <th scope="row" className="py-3 text-left font-normal text-steel-ink">
                      {h.day}
                    </th>
                    <td className={`py-3 text-right tabular-nums ${h.time === "Chiuso" ? "text-steel-ink" : ""}`}>{h.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-4 text-[0.9rem] text-steel-ink">{site.appointmentNote}</p>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
