import { Phone, Mail, MapPin } from "lucide-react";
import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { Verify } from "@/components/ui/Verify";
import { ContactForm } from "./ContactForm";
import { site, fullAddress } from "@/content/site";

export function ContactSection({ headingLevel = "h2" }: { headingLevel?: "h1" | "h2" }) {
  const Sub = headingLevel === "h1" ? "h2" : "h3";
  return (
    <section id="prenota" aria-labelledby="contatti-title" className="on-dark relative scroll-mt-0 bg-midnight text-ivory">
      <div className="wrap section grid gap-y-14 lg:grid-cols-12 lg:gap-x-10">
        <div className="lg:col-span-5">
          <p className="label">Contatti</p>
          <RevealText
            as={headingLevel}
            id="contatti-title"
            lines={["Il tuo percorso", "inizia da una", "conversazione."]}
            className="display-lg mt-4"
          />
          <FadeIn>
            <p className="lead mt-6 max-w-[26rem]">
              Chiama lo studio per fissare una visita o lascia i tuoi recapiti: verrai ricontattato per trovare insieme
              giorno e orario.
            </p>
          </FadeIn>

          <FadeIn className="mt-10 flex flex-wrap gap-3">
            <ButtonLink href={site.phone.href} variant="light" icon={<Phone size={16} strokeWidth={1.6} aria-hidden="true" />}>
              Chiama lo studio
            </ButtonLink>
            <ButtonLink href="#richiesta" variant="outline-light">
              Richiedi informazioni
            </ButtonLink>
          </FadeIn>

          <FadeIn>
            <dl className="mt-12 space-y-6 border-t border-[var(--line-dark)] pt-8 text-[0.98rem]">
              <div className="flex gap-4">
                <dt>
                  <Phone size={18} strokeWidth={1.4} className="mt-1 text-champagne" aria-hidden="true" />
                  <span className="sr-only">Telefono</span>
                </dt>
                <dd>
                  <a href={site.phone.href} className="font-serif text-[1.7rem] leading-none">
                    {site.phone.display}
                  </a>
                  <p className="mt-1 text-[0.85rem] text-[rgb(247_245_240/0.62)]">
                    Anche{" "}
                    <Verify>
                      <a href={site.phoneAlt.href} className="link-line">
                        {site.phoneAlt.display}
                      </a>
                    </Verify>
                  </p>
                </dd>
              </div>
              <div className="flex gap-4">
                <dt>
                  <Mail size={18} strokeWidth={1.4} className="mt-1 text-champagne" aria-hidden="true" />
                  <span className="sr-only">Email</span>
                </dt>
                <dd>
                  <a href={`mailto:${site.email}`} className="link-line break-all">
                    {site.email}
                  </a>
                </dd>
              </div>
              <div className="flex gap-4">
                <dt>
                  <MapPin size={18} strokeWidth={1.4} className="mt-1 text-champagne" aria-hidden="true" />
                  <span className="sr-only">Indirizzo</span>
                </dt>
                <dd>
                  <address className="not-italic">{fullAddress}</address>
                  <a href={site.mapsUrl} target="_blank" rel="noopener noreferrer" className="link-line mt-1 inline-block text-[0.88rem]">
                    Apri in Google Maps<span className="sr-only"> (si apre in una nuova scheda)</span>
                  </a>
                </dd>
              </div>
            </dl>
          </FadeIn>

          <FadeIn>
            <div className="mt-10 border-t border-[var(--line-dark)] pt-8">
              <Sub className="label">
                Orari
              </Sub>
              <table className="mt-4 w-full max-w-[22rem] text-[0.92rem]">
                <caption className="sr-only">Orari di apertura dello studio</caption>
                <tbody>
                  {site.hours.map((h) => (
                    <tr key={h.day} className="border-b border-[var(--line-dark)] last:border-0">
                      <th scope="row" className="py-2 text-left font-normal text-[rgb(247_245_240/0.7)]">
                        {h.day}
                      </th>
                      <td className={`py-2 text-right tabular-nums ${h.time === "Chiuso" ? "text-[rgb(247_245_240/0.45)]" : ""}`}>{h.time}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="mt-4 text-[0.85rem] text-[rgb(247_245_240/0.62)]">{site.appointmentNote}</p>
            </div>
          </FadeIn>
        </div>

        <div id="richiesta" className="scroll-mt-28 lg:col-span-6 lg:col-start-7">
          <div className="on-light rounded-[1.25rem] bg-ivory p-6 text-ink sm:p-10 lg:sticky lg:top-28">
            <Sub className="font-serif text-[2rem] leading-tight font-medium">Richiedi informazioni</Sub>
            <p className="mt-2 mb-8 text-[0.95rem] text-steel-ink">Lascia nome e telefono: lo studio ti richiamerà.</p>
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
}
