"use client";

import { AnimatePresence, motion } from "motion/react";
import { useId, useState } from "react";
import { timeline } from "@/content/doctor";
import { Verify } from "@/components/ui/Verify";

/** Timeline del percorso professionale: una tappa aperta alla volta. */
export function Timeline({ initial = 0 }: { initial?: number }) {
  const [active, setActive] = useState(initial);
  const base = useId();

  return (
    <ol className="relative">
      <span className="absolute bottom-3 left-[0.6875rem] top-3 w-px bg-[var(--line)]" aria-hidden="true" />
      {timeline.map((item, i) => {
        const open = active === i;
        const panel = `${base}-${item.id}`;
        return (
          <li key={item.id} className="relative pl-12">
            <span
              aria-hidden="true"
              className={`absolute left-0 top-[1.35rem] grid h-[1.4rem] w-[1.4rem] place-items-center rounded-full border bg-ivory transition-colors duration-500 ${
                open ? "border-ink" : "border-[var(--line-strong)]"
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full transition-colors duration-500 ${open ? "bg-champagne" : "bg-transparent"}`} />
            </span>
            <button
              type="button"
              aria-expanded={open}
              aria-controls={panel}
              onClick={() => setActive(open ? -1 : i)}
              className="flex w-full flex-col items-start gap-1 py-4 text-left"
            >
              <span className="label tabular-nums">
                {String(i + 1).padStart(2, "0")} · {item.phase}
                {item.period ? ` · ${item.period}` : ""}
              </span>
              <span className={`font-serif text-[1.55rem] leading-tight transition-colors ${open ? "text-ink" : "text-steel-ink"}`}>
                {item.title}
              </span>
            </button>
            <AnimatePresence initial={false}>
              {open && (
                <motion.div
                  id={panel}
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.5, ease: [0.25, 1, 0.5, 1] }}
                  className="overflow-hidden"
                >
                  <ul className="space-y-4 pb-6">
                    {item.entries.map((e) => (
                      <li key={e.title}>
                        <p className="font-medium">
                          {e.verify ? <Verify>{e.title}</Verify> : e.title}
                        </p>
                        <p className="mt-1 text-[0.95rem] text-steel-ink">{e.detail}</p>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              )}
            </AnimatePresence>
          </li>
        );
      })}
    </ol>
  );
}
