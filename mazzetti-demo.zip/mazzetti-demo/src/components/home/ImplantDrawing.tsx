/** Disegno tecnico statico dell'impianto: riserva per dispositivi senza WebGL o poco potenti. */
export function ImplantDrawing({ className = "" }: { className?: string }) {
  const threads = Array.from({ length: 12 }, (_, i) => 236 + i * 17);
  return (
    <svg viewBox="0 0 320 520" className={className} role="img" aria-label="Disegno di un impianto dentale con moncone e corona">
      <g fill="none" stroke="#192b35" strokeWidth="1.2" strokeLinejoin="round">
        {/* osso */}
        <rect x="40" y="214" width="240" height="280" rx="26" stroke="#79949e" strokeDasharray="2 5" />
        {/* corona */}
        <path d="M92 150c-6-40 6-74 26-82 14-6 26 6 42 6s28-12 42-6c20 8 32 42 26 82-4 28-20 42-30 46H122c-10-4-26-18-30-46Z" fill="#f7f5f0" />
        <path d="M118 84c10 10 22 12 42 12s32-2 42-12" />
        {/* moncone */}
        <path d="M130 196h60l-6 22h-48z" fill="#e9e1cf" stroke="#9a8664" />
        {/* impianto */}
        <path d="M134 218h52l-2 18-1 160c-2 22-10 40-23 46-13-6-21-24-23-46l-1-160z" fill="#eef0f2" />
        {threads.map((y, i) => (
          <path key={y} d={`M${134 + (i > 8 ? (i - 8) * 3 : 0)} ${y}l${52 - (i > 8 ? (i - 8) * 6 : 0)} 9`} stroke="#79949e" />
        ))}
        {/* asse */}
        <path d="M160 40v470" stroke="#b6a17e" strokeDasharray="6 5" />
      </g>
      <g fill="#4c626b" fontFamily="var(--font-sans)" fontSize="11">
        <text x="232" y="122">Corona</text>
        <text x="232" y="212">Moncone</text>
        <text x="232" y="320">Impianto</text>
        <text x="48" y="482">Osso</text>
      </g>
    </svg>
  );
}
