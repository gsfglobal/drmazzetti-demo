import { ArrowRight } from "lucide-react";
import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { Portrait } from "./Portrait";
import { Timeline } from "./Timeline";
import { doctorIntro } from "@/content/doctor";

export function DoctorPreview() {
  return (
    <section aria-labelledby="dottore-title" className="section border-t border-[var(--line)]">
      <div className="wrap grid gap-y-14 lg:grid-cols-12 lg:gap-x-10">
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <Portrait className="aspect-[4/5] w-full" />
          </div>
        </div>

        <div className="lg:col-span-6 lg:col-start-7">
          <p className="label">Il dottore</p>
          <RevealText
            as="h2"
            lines={["Vincenzo Mazzetti.", "La conoscenza al", "servizio della cura."]}
            className="display-lg mt-4"
            id="dottore-title"
          />
          <FadeIn>
            <p className="lead mt-8">{doctorIntro.lead}</p>
          </FadeIn>

          <div className="mt-12">
            <Timeline />
          </div>

          <FadeIn className="mt-10">
            <ButtonLink href="/il-dottore/" variant="outline" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
              Scopri il percorso professionale
            </ButtonLink>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
