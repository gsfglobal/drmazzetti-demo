"use client";

import { useId, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "motion/react";
import Link from "next/link";
import { site } from "@/content/site";

type Errors = Partial<Record<"name" | "phone" | "email" | "privacy", string>>;

/**
 * Modulo di richiesta informazioni. Nella versione dimostrativa NON invia
 * nulla e lo dice chiaramente. Non chiede dati sulla salute (art. 9 GDPR).
 */
export function ContactForm() {
  const id = useId();
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<"idle" | "demo">("idle");

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const next: Errors = {};
    const name = String(fd.get("name") ?? "").trim();
    const phone = String(fd.get("phone") ?? "").replace(/\s/g, "");
    const email = String(fd.get("email") ?? "").trim();
    if (name.length < 2) next.name = "Scrivi nome e cognome.";
    if (!/^\+?\d{6,15}$/.test(phone)) next.phone = "Scrivi un numero di telefono valido, solo cifre.";
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Controlla l'indirizzo email.";
    if (!fd.get("privacy")) next.privacy = "Per inviare la richiesta serve la presa visione dell'informativa.";
    setErrors(next);
    if (Object.keys(next).length) {
      const first = e.currentTarget.querySelector<HTMLElement>("[aria-invalid='true']");
      first?.focus();
      return;
    }
    // Modalità dimostrativa: nessun invio.
    setStatus("demo");
  };

  const field =
    "mt-2 w-full rounded-none border-0 border-b border-[var(--line-strong)] bg-transparent px-0 py-3 text-[1rem] text-ink placeholder:text-[rgb(76_98_107/0.7)] focus:border-ink focus:outline-none focus-visible:outline-none";

  return (
    <form noValidate onSubmit={onSubmit} className="text-ink" aria-describedby={`${id}-demo`}>
      {site.demo && (
        <p id={`${id}-demo`} className="mb-8 flex gap-3 rounded-lg bg-mist px-4 py-3 text-[0.82rem] leading-snug text-steel-ink">
          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-champagne" aria-hidden="true" />
          Modulo in modalità dimostrativa: puoi provarlo, ma le richieste non vengono inviate. Per contattare lo studio
          chiama il {site.phone.display}.
        </p>
      )}

      <div className="grid gap-x-8 gap-y-7 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label htmlFor={`${id}-name`} className="label">
            Nome e cognome <span aria-hidden="true">*</span>
          </label>
          <input
            id={`${id}-name`}
            name="name"
            autoComplete="name"
            required
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? `${id}-name-err` : undefined}
            className={field}
          />
          {errors.name && (
            <p id={`${id}-name-err`} className="mt-2 text-[0.82rem] text-[#9b2c2c]">
              {errors.name}
            </p>
          )}
        </div>
        <div>
          <label htmlFor={`${id}-phone`} className="label">
            Telefono <span aria-hidden="true">*</span>
          </label>
          <input
            id={`${id}-phone`}
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            required
            aria-invalid={!!errors.phone}
            aria-describedby={errors.phone ? `${id}-phone-err` : undefined}
            className={field}
          />
          {errors.phone && (
            <p id={`${id}-phone-err`} className="mt-2 text-[0.82rem] text-[#9b2c2c]">
              {errors.phone}
            </p>
          )}
        </div>
        <div>
          <label htmlFor={`${id}-email`} className="label">
            Email <span className="text-[0.75rem]">(facoltativa)</span>
          </label>
          <input
            id={`${id}-email`}
            name="email"
            type="email"
            autoComplete="email"
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? `${id}-email-err` : undefined}
            className={field}
          />
          {errors.email && (
            <p id={`${id}-email-err`} className="mt-2 text-[0.82rem] text-[#9b2c2c]">
              {errors.email}
            </p>
          )}
        </div>

        <fieldset className="sm:col-span-2">
          <legend className="label">Quando preferisci essere ricontattato?</legend>
          <div className="mt-3 flex flex-wrap gap-2">
            {["Mattina", "Pomeriggio", "Indifferente"].map((v, i) => (
              <label key={v} className="cursor-pointer">
                <input type="radio" name="slot" value={v} defaultChecked={i === 2} className="peer sr-only" />
                <span className="inline-flex min-h-11 items-center rounded-full border border-[var(--line-strong)] px-4 text-[0.92rem] transition-colors peer-checked:border-ink peer-checked:bg-ink peer-checked:text-ivory peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-ink">
                  {v}
                </span>
              </label>
            ))}
          </div>
        </fieldset>

        <div className="sm:col-span-2">
          <label htmlFor={`${id}-msg`} className="label">
            Messaggio <span className="text-[0.75rem]">(facoltativo)</span>
          </label>
          <textarea id={`${id}-msg`} name="message" rows={3} aria-describedby={`${id}-msg-hint`} className={`${field} resize-none`} />
          <p id={`${id}-msg-hint`} className="mt-2 text-[0.78rem] text-steel-ink">
            Non inserire informazioni sulla tua salute: ne parlerai direttamente con il dottore.
          </p>
        </div>

        <div className="sm:col-span-2">
          <label className="flex cursor-pointer items-start gap-3 text-[0.88rem] leading-snug">
            <input
              type="checkbox"
              name="privacy"
              aria-invalid={!!errors.privacy}
              aria-describedby={errors.privacy ? `${id}-privacy-err` : undefined}
              className="mt-0.5 h-5 w-5 shrink-0 accent-[#111c22]"
            />
            <span>
              Ho letto l&apos;
              <Link href="/privacy/" className="link-line">
                informativa privacy
              </Link>{" "}
              e chiedo di essere ricontattato per questa richiesta. <span aria-hidden="true">*</span>
            </span>
          </label>
          {errors.privacy && (
            <p id={`${id}-privacy-err`} className="mt-2 text-[0.82rem] text-[#9b2c2c]">
              {errors.privacy}
            </p>
          )}
        </div>
      </div>

      <div className="mt-9 flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
        <button
          type="submit"
          className="inline-flex min-h-12 items-center rounded-full bg-ink px-7 text-[0.95rem] font-medium text-ivory transition-colors hover:bg-midnight"
        >
          Richiedi informazioni
        </button>
        <p className="text-[0.75rem] text-steel-ink">* Campi obbligatori</p>
      </div>

      <div role="status" aria-live="polite">
        <AnimatePresence>
          {status === "demo" && (
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-6 border-l-2 border-champagne pl-4 text-[0.92rem]"
            >
              Modalità dimostrativa: la richiesta <strong>non è stata inviata</strong>. Nella versione definitiva arriverà
              allo studio, che ti ricontatterà. Intanto puoi chiamare il{" "}
              <a href={site.phone.href} className="link-line">
                {site.phone.display}
              </a>
              .
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </form>
  );
}
