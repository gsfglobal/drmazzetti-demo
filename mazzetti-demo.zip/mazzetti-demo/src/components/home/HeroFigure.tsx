"use client";

import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "motion/react";
import { asset } from "@/lib/paths";

/** Nuvola di punti dell'arcata (WebGL) con immagine statica di riserva. */
export function HeroFigure() {
  const host = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const [state, setState] = useState<"loading" | "ready" | "fallback">("loading");

  useEffect(() => {
    let disposed = false;
    let instance: { dispose: () => void } | null = null;
    const start = async () => {
      const mod = await import("@/components/three/scanCloud");
      if (disposed || !host.current) return;
      if (!mod.webglAvailable()) {
        setState("fallback");
        return;
      }
      const small = window.innerWidth < 768;
      const lowCpu = (navigator.hardwareConcurrency ?? 8) <= 4;
      instance = new mod.ScanCloud(host.current, {
        points: small || lowCpu ? 15000 : 30000,
        reducedMotion: !!reduce,
        onReady: () => setState("ready"),
      });
    };
    const ric = (window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number })
      .requestIdleCallback;
    const kick = () => start().catch(() => setState("fallback"));
    const handle = ric ? ric(kick, { timeout: 1200 }) : window.setTimeout(kick, 350);
    return () => {
      disposed = true;
      if (!ric) window.clearTimeout(handle);
      instance?.dispose();
    };
  }, [reduce]);

  return (
    <figure className="relative h-full w-full">
      <div
        ref={host}
        className={`absolute inset-0 transition-opacity duration-700 ${state === "ready" ? "opacity-100" : "opacity-0"}`}
      />
      {state === "fallback" && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={asset("/hero-scan.png")}
          alt=""
          className="absolute inset-0 h-full w-full object-contain"
          aria-hidden="true"
        />
      )}
      <figcaption className="absolute bottom-0 right-0 max-w-[16rem] text-right text-[0.75rem] leading-snug text-steel-ink">
        Fig. 1 — Un'arcata come la registra uno scanner intraorale. Visualizzazione generativa.
      </figcaption>
    </figure>
  );
}
