import { ArrowRight } from "lucide-react";
import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { PublicationEntry } from "./PublicationEntry";
import { thesis, publications } from "@/content/publications";

export function ResearchSection() {
  const featured = publications.filter((p) => p.featured);
  return (
    <section aria-labelledby="ricerca-title" className="on-dark grain relative overflow-hidden bg-ink text-ivory">
      <div className="wrap section relative">
        <div className="grid gap-y-10 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-8">
            <p className="label">Ricerca scientifica</p>
            <RevealText
              as="h2"
              id="ricerca-title"
              lines={["Oltre la pratica clinica.", "Il valore della ricerca."]}
              className="display-lg mt-4"
            />
          </div>
          <FadeIn className="lg:col-span-4 lg:self-end">
            <p className="lead">
              Studiare come migliorare la precisione di impronte, progetti e interventi aiuta a scegliere con più
              consapevolezza anche alla poltrona.
            </p>
          </FadeIn>
        </div>

        {/* Il dottorato */}
        <FadeIn className="mt-16 lg:mt-24">
          <div className="grid gap-8 border-y border-[var(--line-dark)] py-10 lg:grid-cols-12 lg:gap-10 lg:py-14">
            <div className="lg:col-span-4">
              <p className="label">Dottorato di ricerca · {thesis.year}</p>
              <p className="mt-4 font-serif text-[2rem] leading-tight">Università di Roma Tor Vergata</p>
              <p className="mt-3 text-[0.9rem] text-[rgb(247_245_240/0.62)]">{thesis.details}</p>
            </div>
            <div className="lg:col-span-8">
              <p className="font-serif text-[1.6rem] leading-snug italic sm:text-[2.1rem]" lang="en">
                {thesis.title}
              </p>
              <p className="mt-5 max-w-[46rem] text-[rgb(247_245_240/0.82)]">{thesis.summary}</p>
              <a
                href={thesis.links[0].href}
                target="_blank"
                rel="noopener noreferrer"
                className="link-line mt-5 inline-block text-[0.9rem]"
              >
                Scheda della tesi nell&apos;archivio IRIS<span className="sr-only"> (si apre in una nuova scheda)</span>
              </a>
            </div>
          </div>
        </FadeIn>

        <div className="mt-6">
          {featured.map((p) => (
            <FadeIn key={p.id}>
              <PublicationEntry p={p} dark />
            </FadeIn>
          ))}
        </div>

        <FadeIn className="mt-12 flex flex-col items-start justify-between gap-6 border-t border-[var(--line-dark)] pt-10 sm:flex-row sm:items-center">
          <p className="max-w-[32rem] text-[0.88rem] text-[rgb(247_245_240/0.6)]">
            Le sintesi sono scritte per i pazienti e non sostituiscono la lettura degli articoli originali.
          </p>
          <ButtonLink href="/ricerca/" variant="light" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
            Ricerca e pubblicazioni
          </ButtonLink>
        </FadeIn>
      </div>
    </section>
  );
}
