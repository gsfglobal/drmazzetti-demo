"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { ArrowRight } from "lucide-react";
import { IntroTitle } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { HeroFigure } from "./HeroFigure";
import { site } from "@/content/site";

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  // parallax leggerissimo: la figura scorre un po' più lenta del testo
  const figY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 70]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : -30]);
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, reduce ? 1 : 0.2]);

  const fadeUp = (delay: number) => ({ className: "anim-fade-up", style: { animationDelay: `${delay}s` } });

  return (
    <section ref={ref} aria-labelledby="hero-title" className="relative overflow-hidden pt-[calc(var(--header-h)+1.5rem)]">
      <div className="wrap grid min-h-[calc(100svh-var(--header-h)-1.5rem)] grid-cols-1 items-center gap-y-6 pb-10 lg:grid-cols-12 lg:gap-x-10 lg:pb-14">
        <motion.div style={{ y: textY, opacity: fade }} className="relative z-10 lg:col-span-6 xl:col-span-6">
          <p {...fadeUp(0.05)}>
            <span className="eyebrow">Odontoiatria · Ricerca · Innovazione</span>
          </p>

          <IntroTitle
            id="hero-title"
            delay={0.12}
            stagger={0.05}
            lines={["La precisione", "della scienza.", "Il valore", "di ogni sorriso."]}
            className="display-xl mt-6 text-ink"
          />

          <p {...fadeUp(0.35)}>
            <span className="lead mt-7 block max-w-[34rem]">
            Competenza clinica, ricerca scientifica e un approccio attento alla persona. Scopri la visione odontoiatrica
            del {site.doctor} a Pontecorvo.
            </span>
          </p>

          <div {...fadeUp(0.5)}>
            <div className="mt-9 flex flex-wrap items-center gap-3">
            <ButtonLink href="/contatti/#prenota" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
              Prenota una visita
            </ButtonLink>
            <ButtonLink href="/il-dottore/" variant="outline">
              Conosci il Dottore
            </ButtonLink>
            </div>
          </div>
        </motion.div>

        <motion.div
          style={{ y: figY }}
          className="relative h-[46svh] min-h-[300px] w-full lg:col-span-6 lg:h-[72svh] lg:min-h-[520px]"
        >
          <HeroFigure />
        </motion.div>
      </div>

      {/* Indicatore di scroll */}
      <div
        style={{ animationDelay: "1.6s" }}
        className="anim-fade-in wrap pointer-events-none absolute inset-x-0 bottom-6 hidden lg:block"
        aria-hidden="true"
      >
        <div className="flex items-center gap-4 text-[0.75rem] text-steel-ink">
          <span className="relative block h-10 w-px overflow-hidden bg-[var(--line)]">
            <span className="absolute inset-x-0 top-0 h-4 animate-[scrollcue_2.4s_var(--ease-in-out-quart)_infinite] bg-ink" />
          </span>
          Scorri
        </div>
      </div>
    </section>
  );
}
