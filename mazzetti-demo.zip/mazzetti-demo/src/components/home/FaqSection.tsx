import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { Accordion } from "@/components/ui/Accordion";

export function FaqSection({ items, title = ["Domande", "frequenti"] }: { items: { q: string; a: string }[]; title?: string[] }) {
  return (
    <section aria-labelledby="faq-title" className="section border-t border-[var(--line)]">
      <div className="wrap grid gap-y-10 lg:grid-cols-12 lg:gap-x-10">
        <div className="lg:col-span-4">
          <RevealText as="h2" id="faq-title" lines={title} className="display-lg" />
          <FadeIn>
            <p className="mt-6 max-w-[22rem] text-steel-ink">
              Risposte informative ai dubbi più comuni. Ogni situazione è diversa: le indicazioni personali si danno solo
              dopo la visita.
            </p>
          </FadeIn>
        </div>
        <div className="lg:col-span-7 lg:col-start-6">
          <Accordion items={items} />
        </div>
      </div>
    </section>
  );
}
