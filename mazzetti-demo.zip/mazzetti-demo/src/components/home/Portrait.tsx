import { Photo } from "@/components/ui/Photo";

/**
 * Ritratto del dottore. Provvisorio: scatto ricevuto via chat, a bassa
 * risoluzione; da sostituire con il file originale ad alta risoluzione.
 */
export function Portrait({ className = "" }: { className?: string }) {
  return (
    <Photo
      src="ritratto"
      alt="Il Dott. Vincenzo Mazzetti in studio, con le braccia incrociate"
      sizes="(min-width: 1024px) 40vw, 100vw"
      className={className}
      position="center 18%"
      priority
    />
  );
}
