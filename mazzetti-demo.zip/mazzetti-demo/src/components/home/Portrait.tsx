import { Mark } from "@/components/layout/Logo";

/**
 * Spazio per il ritratto ufficiale. Non usiamo foto di modelli al posto del
 * dottore: finché non arriva lo scatto autorizzato, una tavola tipografica.
 */
export function Portrait({ className = "" }: { className?: string }) {
  return (
    <figure className={`on-dark grain relative isolate overflow-hidden bg-midnight text-ivory ${className}`}>
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <radialGradient id="pg" cx="70%" cy="22%" r="80%">
            <stop offset="0" stopColor="#79949e" stopOpacity="0.32" />
            <stop offset="1" stopColor="#192b35" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="400" height="500" fill="url(#pg)" />
        {[60, 110, 160, 210].map((r) => (
          <circle key={r} cx="290" cy="150" r={r} fill="none" stroke="#f7f5f0" strokeOpacity="0.07" />
        ))}
        <line x1="0" y1="380" x2="400" y2="380" stroke="#f7f5f0" strokeOpacity="0.1" />
      </svg>
      <div className="relative flex h-full flex-col justify-between p-7 sm:p-9">
        <Mark className="h-10 w-auto self-start text-champagne" />
        <div>
          <p className="font-serif text-[clamp(4.5rem,11vw,8.5rem)] leading-[0.8] font-medium tracking-tight">V. M.</p>
          <figcaption className="mt-6 max-w-[17rem] text-[0.8rem] leading-snug text-[rgb(247_245_240/0.62)]">
            Spazio riservato al ritratto professionale del Dott. Mazzetti, da realizzare con uno scatto ufficiale.
          </figcaption>
        </div>
      </div>
    </figure>
  );
}
