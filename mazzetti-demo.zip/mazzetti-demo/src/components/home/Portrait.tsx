import { Photo } from "@/components/ui/Photo";

/**
 * Ritratto ufficiale del dottore (foto inviata dallo studio il 20/10/2026).
 */
export function Portrait({ className = "" }: { className?: string }) {
  return (
    <Photo
      src="ritratto"
      alt="Il Dott. Vincenzo Mazzetti in studio, con le braccia incrociate"
      sizes="(min-width: 1024px) 40vw, 100vw"
      className={className}
      position="center 20%"
      priority
    />
  );
}
