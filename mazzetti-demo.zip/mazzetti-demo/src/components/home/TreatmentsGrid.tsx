import { ArrowRight } from "lucide-react";
import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { TreatmentCard } from "./TreatmentCard";
import { treatments } from "@/content/treatments";

export function TreatmentsGrid({ withHeader = true }: { withHeader?: boolean }) {
  return (
    <section aria-labelledby={withHeader ? "trattamenti-title" : undefined} aria-label={withHeader ? undefined : "Elenco dei trattamenti"} className={withHeader ? "section border-t border-[var(--line)]" : "pb-[var(--section-y)]"}>
      <div className="wrap">
        {withHeader && (
          <div className="grid gap-y-8 lg:grid-cols-12 lg:gap-x-10">
            <div className="lg:col-span-7">
              <p className="label">Trattamenti</p>
              <RevealText as="h2" id="trattamenti-title" lines={["Sei aree di cura,", "un unico metodo."]} className="display-lg mt-4" />
            </div>
            <FadeIn className="lg:col-span-4 lg:col-start-9 lg:self-end">
              <p className="text-steel-ink">
                Dalla prevenzione alla riabilitazione delle arcate complete: ogni area parte dalla stessa domanda, cioè che
                cosa è davvero utile per quella persona.
              </p>
            </FadeIn>
          </div>
        )}

        <div className={`grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 ${withHeader ? "mt-16 lg:mt-20" : ""}`}>
          {treatments.map((t, i) => (
            <FadeIn key={t.slug} delay={(i % 3) * 0.08} className={i % 3 === 1 ? "lg:mt-24" : ""}>
              <TreatmentCard t={t} />
            </FadeIn>
          ))}
        </div>

        {withHeader && (
          <FadeIn className="mt-16 flex justify-center lg:mt-8 lg:justify-start">
            <ButtonLink href="/trattamenti/" variant="outline" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
              Tutti i trattamenti
            </ButtonLink>
          </FadeIn>
        )}
      </div>
    </section>
  );
}
