"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useMotionValueEvent, useReducedMotion, useScroll } from "motion/react";
import { ArrowRight } from "lucide-react";
import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { ImplantDrawing } from "./ImplantDrawing";

const steps = [
  {
    title: "Valutazione",
    text: "Visita, storia clinica ed esami radiografici quando necessari: si valutano quantità e qualità dell'osso, salute delle gengive e condizioni generali.",
  },
  {
    title: "Pianificazione",
    text: "Si parte dalla protesi da realizzare e si progetta di conseguenza la posizione dell'impianto, anche con strumenti digitali. Il piano indica passaggi, alternative e tempi indicativi.",
  },
  {
    title: "Trattamento",
    text: "L'impianto viene inserito nell'osso seguendo il progetto. Seguono i tempi di guarigione, diversi da persona a persona, e la realizzazione della protesi.",
  },
  {
    title: "Controlli",
    text: "Controlli periodici e igiene professionale aiutano a mantenere in salute l'impianto e i tessuti che lo circondano, nel tempo.",
  },
];

type SceneLike = { setProgress: (p: number) => void; dispose: () => void };

export function ImplantFocus() {
  const scroller = useRef<HTMLDivElement>(null);
  const host = useRef<HTMLDivElement>(null);
  const scene = useRef<SceneLike | null>(null);
  const reduce = useReducedMotion();
  const [active, setActive] = useState(0);
  const [mode, setMode] = useState<"3d" | "static" | "loading">("loading");

  const { scrollYProgress } = useScroll({ target: scroller, offset: ["start start", "end end"] });

  useMotionValueEvent(scrollYProgress, "change", (v) => {
    const p = Math.min(3, Math.max(0, (v * 1.1 - 0.03) * 3));
    scene.current?.setProgress(p);
    setActive(Math.min(3, Math.round(p)));
  });

  useEffect(() => {
    let disposed = false;
    let io: IntersectionObserver | null = null;
    const init = async () => {
      const lowPower =
        (navigator.hardwareConcurrency ?? 8) <= 2 ||
        // @ts-expect-error deviceMemory non è in tutti i browser
        (navigator.deviceMemory ?? 8) <= 2;
      const { webglAvailable } = await import("@/components/three/scanCloud");
      if (!webglAvailable() || lowPower) {
        setMode("static");
        return;
      }
      const { ImplantScene } = await import("@/components/three/implantScene");
      if (disposed || !host.current) return;
      scene.current = new ImplantScene(host.current, !!reduce, window.innerWidth < 768);
      const v = scrollYProgress.get();
      scene.current.setProgress(Math.min(3, Math.max(0, (v * 1.1 - 0.03) * 3)));
      setMode("3d");
    };
    // crea la scena solo quando la sezione si avvicina al viewport
    io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        io?.disconnect();
        init().catch(() => setMode("static"));
      },
      { rootMargin: "900px 0px" },
    );
    if (scroller.current) io.observe(scroller.current);
    return () => {
      disposed = true;
      io?.disconnect();
      scene.current?.dispose();
      scene.current = null;
    };
  }, [reduce, scrollYProgress]);

  return (
    <section id="implantologia" aria-labelledby="impl-title" className="blueprint relative border-y border-[var(--line)]">
      <div className="wrap pt-[var(--section-y)]">
        <div className="grid gap-y-8 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-7">
            <p className="label">Focus</p>
            <RevealText
              as="h2"
              id="impl-title"
              lines={["Implantologia.", "La precisione comincia", "dalla pianificazione."]}
              className="display-lg mt-4"
            />
          </div>
          <FadeIn className="lg:col-span-4 lg:col-start-9 lg:self-end">
            <p className="text-steel-ink">
              Un impianto ben riuscito si decide in gran parte prima dell&apos;intervento. Scorri per seguire un possibile
              percorso, descritto a titolo informativo.
            </p>
          </FadeIn>
        </div>
      </div>

      {/* Visore fisso durante lo scroll */}
      <div ref={scroller} className="relative h-[340svh] lg:h-[380svh]">
        <div className="sticky top-0 flex h-[100svh] items-stretch overflow-hidden pt-[var(--header-h)]">
          <div className="wrap grid h-full grid-rows-[1fr_auto] gap-x-10 pb-[5.75rem] lg:grid-cols-12 lg:grid-rows-1 lg:pb-10">
            <div className="relative min-h-0 lg:col-span-7">
              <div ref={host} className={`absolute inset-0 transition-opacity duration-700 ${mode === "3d" ? "opacity-100" : "opacity-0"}`} />
              {mode === "static" && <ImplantDrawing className="absolute inset-0 m-auto h-full max-h-[34rem] w-auto" />}
              <p className="absolute left-0 top-3 text-[0.72rem] text-steel-ink">Modello 3D illustrativo, non in scala clinica</p>
              <ol className="absolute bottom-2 left-0 flex gap-1.5" aria-hidden="true">
                {steps.map((s, i) => (
                  <li
                    key={s.title}
                    className={`h-[3px] rounded-full transition-all duration-500 ${i === active ? "w-10 bg-ink" : "w-4 bg-[var(--line-strong)]"}`}
                  />
                ))}
              </ol>
            </div>

            <div className="relative flex flex-col justify-center lg:col-span-5">
              <ol className="relative">
                {steps.map((s, i) => {
                  const on = i === active;
                  return (
                    <li key={s.title} className="border-t border-[var(--line)] py-3 lg:py-6" aria-current={on ? "step" : undefined}>
                      <div className="flex items-baseline gap-4">
                        <span className={`label tabular-nums transition-colors ${on ? "text-ink" : ""}`}>0{i + 1}</span>
                        <h3
                          className={`font-serif text-[1.5rem] leading-tight transition-colors duration-500 lg:text-[2rem] ${
                            on ? "text-ink" : "text-[rgb(17_28_34/0.38)]"
                          }`}
                        >
                          {s.title}
                        </h3>
                      </div>
                      <motion.div
                        initial={false}
                        animate={{ height: on ? "auto" : 0, opacity: on ? 1 : 0 }}
                        transition={{ duration: reduce ? 0 : 0.5, ease: [0.25, 1, 0.5, 1] }}
                        className="overflow-hidden"
                      >
                        <p className="max-w-[30rem] pt-2 pl-10 text-[0.92rem] leading-relaxed text-steel-ink lg:pt-3 lg:text-[0.98rem]">{s.text}</p>
                      </motion.div>
                    </li>
                  );
                })}
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="wrap pb-[var(--section-y)]">
        <div className="flex flex-col items-start gap-6 border-t border-[var(--line)] pt-10 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-[34rem] text-[0.92rem] text-steel-ink">
            Le fasi e i tempi si definiscono per ogni paziente dopo la visita. L&apos;indicazione all&apos;impianto è sempre una
            valutazione clinica.
          </p>
          <ButtonLink href="/contatti/#prenota" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
            Richiedi una valutazione implantologica
          </ButtonLink>
        </div>
      </div>
    </section>
  );
}
