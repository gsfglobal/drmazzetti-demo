import { ArrowRight } from "lucide-react";
import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { Photo } from "@/components/ui/Photo";
import { studioPhotos, studioPhotoNote } from "@/content/studio";
import { fullAddress } from "@/content/site";

export function StudioSection() {
  const [a, b, c] = studioPhotos;
  return (
    <section aria-labelledby="studio-title" className="section">
      <div className="wrap">
        <div className="grid gap-y-8 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-7">
            <p className="label">Lo studio</p>
            <RevealText
              as="h2"
              id="studio-title"
              lines={["Uno spazio dedicato", "alla tua salute orale."]}
              className="display-lg mt-4"
            />
          </div>
          <FadeIn className="lg:col-span-4 lg:col-start-9 lg:self-end">
            <p className="text-steel-ink">
              Lo studio si trova in {fullAddress}. Ambienti luminosi e ordinati, pensati per accogliere con calma ogni
              appuntamento.
            </p>
          </FadeIn>
        </div>

        <div className="mt-14 grid grid-cols-2 gap-4 sm:gap-6 lg:mt-20 lg:grid-cols-12">
          <Photo src={a.src} alt={a.alt} sizes="(min-width: 1024px) 58vw, 100vw" className="col-span-2 aspect-[4/3] lg:col-span-7 lg:aspect-auto lg:min-h-full" />
          <div className="col-span-2 grid grid-cols-2 gap-4 sm:gap-6 lg:col-span-5 lg:grid-cols-1">
            <Photo src={b.src} alt={b.alt} sizes="(min-width: 1024px) 40vw, 50vw" className="aspect-[4/3]" />
            <Photo src={c.src} alt={c.alt} sizes="(min-width: 1024px) 40vw, 50vw" className="aspect-[4/3]" />
          </div>
        </div>
        <FadeIn className="mt-10 flex flex-col items-start justify-between gap-6 border-t border-[var(--line)] pt-8 sm:flex-row sm:items-center">
          <p className="max-w-[34rem] text-[0.8rem] leading-snug text-steel-ink">{studioPhotoNote}</p>
          <ButtonLink href="/lo-studio/" variant="outline" icon={<ArrowRight size={16} strokeWidth={1.6} aria-hidden="true" />}>
            Scopri lo studio
          </ButtonLink>
        </FadeIn>
      </div>
    </section>
  );
}
