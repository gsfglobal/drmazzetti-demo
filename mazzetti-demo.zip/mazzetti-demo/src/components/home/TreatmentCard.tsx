import Link from "next/link";
import { Photo } from "@/components/ui/Photo";
import type { Treatment } from "@/content/treatments";

export function TreatmentCard({ t, className = "" }: { t: Treatment; className?: string }) {
  return (
    <article className={`group relative ${className}`}>
      <div className="overflow-hidden">
        <div className="transition-transform duration-[1.2s] ease-[var(--ease-out-quart)] group-hover:scale-[1.035]">
          <Photo
            src={t.image}
            alt={t.imageAlt}
            sizes="(min-width: 1024px) 30vw, (min-width: 640px) 45vw, 100vw"
            className="aspect-[4/5] w-full"
            position={t.imagePosition}
          />
        </div>
      </div>
      <div className="mt-6 flex items-start justify-between gap-6">
        <h3 className="font-serif text-[1.75rem] leading-[1.1] font-medium">
          <Link href={`/trattamenti/${t.slug}/`} className="after:absolute after:inset-0 after:content-['']">
            {t.title}
          </Link>
        </h3>
        <span
          aria-hidden="true"
          className="mt-2 grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--line-strong)] transition-colors duration-500 group-hover:border-ink group-hover:bg-ink group-hover:text-ivory"
        >
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M3 11 11 3M5 3h6v6" stroke="currentColor" strokeWidth="1.3" />
          </svg>
        </span>
      </div>
      <p className="mt-3 text-[0.98rem] text-steel-ink">{t.short}</p>
    </article>
  );
}
