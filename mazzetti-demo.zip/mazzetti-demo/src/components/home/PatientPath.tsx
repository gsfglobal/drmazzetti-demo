"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { RevealText } from "@/components/ui/Reveal";

const steps = [
  {
    title: "Ascolto e valutazione",
    text: "La prima visita parte dalle tue domande e dalla tua storia clinica. Segue l'esame della bocca e, se servono, gli esami radiografici.",
  },
  {
    title: "Pianificazione personalizzata",
    text: "Ti viene spiegato cosa è emerso e quali sono le possibilità, con le alternative, i passaggi previsti e i tempi indicativi. Decidi con tutte le informazioni.",
  },
  {
    title: "Trattamento e monitoraggio",
    text: "Le cure seguono il piano condiviso. Al termine, i controlli periodici aiutano a mantenere nel tempo la salute della bocca.",
  },
];

export function PatientPath() {
  const ref = useRef<HTMLOListElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 75%", "end 55%"] });
  const scaleY = useTransform(scrollYProgress, [0, 1], [reduce ? 1 : 0, 1]);

  return (
    <section aria-labelledby="percorso-title" className="section border-t border-[var(--line)] bg-paper">
      <div className="wrap grid gap-y-14 lg:grid-cols-12 lg:gap-x-10">
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-32">
            <p className="label">Il percorso del paziente</p>
            <RevealText
              as="h2"
              id="percorso-title"
              lines={["Dalla prima visita", "a un percorso costruito", "intorno a te."]}
              className="display-lg mt-4"
            />
          </div>
        </div>

        <ol ref={ref} className="relative lg:col-span-6 lg:col-start-7">
          <span className="absolute bottom-0 left-[1.4rem] top-0 w-px bg-[var(--line)]" aria-hidden="true" />
          <motion.span
            style={{ scaleY }}
            className="absolute bottom-0 left-[1.4rem] top-0 w-px origin-top bg-ink"
            aria-hidden="true"
          />
          {steps.map((s, i) => (
            <Step key={s.title} index={i} title={s.title} text={s.text} progress={scrollYProgress} />
          ))}
        </ol>
      </div>
    </section>
  );
}

function Step({
  index,
  title,
  text,
  progress,
}: {
  index: number;
  title: string;
  text: string;
  progress: ReturnType<typeof useScroll>["scrollYProgress"];
}) {
  const at = index / 3 + 0.04;
  const on = useTransform(progress, [at - 0.04, at + 0.02], [0, 1]);
  const bg = useTransform(on, (v) => (v > 0.5 ? "var(--color-ink)" : "var(--color-paper)"));
  const fg = useTransform(on, (v) => (v > 0.5 ? "var(--color-ivory)" : "var(--color-ink)"));

  return (
    <li className="relative grid grid-cols-[2.8rem_1fr] gap-6 pb-16 last:pb-0">
      <motion.span
        style={{ backgroundColor: bg, color: fg }}
        className="relative z-10 grid h-[2.8rem] w-[2.8rem] place-items-center rounded-full border border-ink font-serif text-[1.25rem] tabular-nums"
        aria-hidden="true"
      >
        {index + 1}
      </motion.span>
      <div className="pt-1.5">
        <h3 className="font-serif text-[1.85rem] leading-tight font-medium sm:text-[2.2rem]">{title}</h3>
        <p className="mt-3 max-w-[32rem] text-steel-ink">{text}</p>
      </div>
    </li>
  );
}
