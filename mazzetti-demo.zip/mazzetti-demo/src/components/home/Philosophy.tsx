import { RevealText, FadeIn } from "@/components/ui/Reveal";
import { Photo } from "@/components/ui/Photo";

const principles = [
  {
    title: "Diagnosi",
    text: "Raccogliere la storia clinica, osservare con attenzione, richiedere solo gli esami davvero utili. Ogni scelta successiva parte da qui.",
  },
  {
    title: "Pianificazione",
    text: "Prima di intervenire si definisce dove si vuole arrivare, con quali passaggi e con quali alternative, e lo si spiega con parole semplici.",
  },
  {
    title: "Valutazione individuale",
    text: "Età, salute generale, abitudini e aspettative contano quanto i denti. Per questo non esistono soluzioni uguali per tutti.",
  },
  {
    title: "Attenzione alla persona",
    text: "Tempo per le domande, rispetto dei dubbi e dei ritmi di ciascuno: la fiducia si costruisce anche così.",
  },
];

export function Philosophy() {
  return (
    <section aria-labelledby="filosofia-title" className="section">
      <div className="wrap">
        <div className="grid gap-y-10 lg:grid-cols-12 lg:gap-x-10">
          <RevealText
            lines={["Ogni dettaglio conta.", "Soprattutto quando", "si parla di salute."]}
            className="display-lg lg:col-span-8"
            as="h2"
            id="filosofia-title"
          />
          <FadeIn className="lg:col-span-4 lg:self-end">
            <p className="lead">
              Una cura efficace nasce prima della poltrona: da una diagnosi accurata, da un progetto chiaro e dal tempo
              dedicato all&apos;ascolto.
            </p>
          </FadeIn>
        </div>

        <div className="mt-16 grid gap-y-12 lg:mt-24 lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-5">
            <Photo
              src="filosofia"
              alt="Strumenti odontoiatrici ordinati sul piano di lavoro di un riunito"
              sizes="(min-width: 1024px) 40vw, 100vw"
              className="aspect-[4/5] w-full"
              tag="Immagine illustrativa"
            />
          </div>

          <dl className="self-center lg:col-span-6 lg:col-start-7">
            {principles.map((p, i) => (
              <FadeIn key={p.title} delay={i * 0.06} className="grid gap-2 border-t border-[var(--line)] py-7 sm:grid-cols-[12rem_1fr] sm:gap-8">
                <dt className="font-serif text-[1.55rem] leading-tight font-medium">{p.title}</dt>
                <dd className="text-steel-ink">{p.text}</dd>
              </FadeIn>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}
