import type { Publication } from "@/content/publications";

/** Voce editoriale di una pubblicazione (fondo scuro o chiaro). */
export function PublicationEntry({ p, dark = false, compact = false }: { p: Publication; dark?: boolean; compact?: boolean }) {
  const muted = dark ? "text-[rgb(247_245_240/0.62)]" : "text-steel-ink";
  return (
    <article className={`group grid gap-4 border-t py-8 sm:grid-cols-[6.5rem_1fr] sm:gap-8 ${dark ? "border-[var(--line-dark)]" : "border-[var(--line)]"}`}>
      <p className={`font-serif text-[2.4rem] leading-none tabular-nums ${dark ? "text-champagne" : "text-ink"}`}>{p.year}</p>
      <div>
        <p className={`label ${dark ? "!text-steel" : ""}`}>
          {p.type} · <span className="italic">{p.venue}</span>
        </p>
        <h3 className={`mt-3 font-serif font-medium leading-snug ${compact ? "text-[1.3rem]" : "text-[1.45rem] sm:text-[1.6rem]"}`} lang="en">
          {p.title}
        </h3>
        {!compact && <p className={`mt-2 text-[0.82rem] ${muted}`}>{p.authors}</p>}
        <p className={`mt-4 max-w-[44rem] ${dark ? "text-[rgb(247_245_240/0.82)]" : "text-ink"}`}>{p.summary}</p>
        <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-[0.85rem]">
          {p.details && <span className={`tabular-nums ${muted}`}>{p.details}</span>}
          {p.links.map((l) => (
            <a key={l.href} href={l.href} target="_blank" rel="noopener noreferrer" className="link-line">
              {l.label}
              <span className="sr-only"> (si apre in una nuova scheda)</span>
            </a>
          ))}
        </div>
      </div>
    </article>
  );
}
