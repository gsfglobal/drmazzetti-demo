"use client";

import Image from "next/image";
import { motion, useReducedMotion } from "motion/react";
import manifest from "@/content/image-manifest.json";

type Name = keyof typeof manifest;

type Props = {
  src: string;
  alt: string;
  sizes: string;
  className?: string;
  imgClassName?: string;
  priority?: boolean;
  /** Rivela l'immagine con una maschera dal basso all'ingresso nel viewport. */
  reveal?: boolean;
  /** Didascalia piccola sovrapposta (es. «Immagine illustrativa»). */
  tag?: string;
  position?: string;
};

/**
 * Immagine responsive da public/img. Il contenitore deve avere un'altezza o
 * un rapporto d'aspetto (es. aspect-[4/5]).
 */
export function Photo({ src, alt, sizes, className = "", imgClassName = "", priority, reveal = true, tag, position = "center" }: Props) {
  const reduce = useReducedMotion();
  const meta = manifest[src as Name];
  const animate = reveal && !reduce;

  return (
    <motion.div
      className={`relative overflow-hidden bg-mist ${className}`}
      initial={animate ? { clipPath: "inset(100% 0% 0% 0%)" } : false}
      whileInView={animate ? { clipPath: "inset(0% 0% 0% 0%)" } : undefined}
      viewport={{ once: true, margin: "0px 0px -8% 0px" }}
      transition={{ duration: 1.2, ease: [0.76, 0, 0.24, 1] }}
    >
      <motion.div
        className="absolute inset-0"
        initial={animate ? { scale: 1.12 } : false}
        whileInView={animate ? { scale: 1 } : undefined}
        viewport={{ once: true, margin: "0px 0px -8% 0px" }}
        transition={{ duration: 1.6, ease: [0.25, 1, 0.5, 1] }}
      >
        <Image
          src={src}
          alt={alt}
          fill
          sizes={sizes}
          priority={priority}
          placeholder={meta ? "blur" : "empty"}
          blurDataURL={meta?.blur}
          className={`object-cover ${imgClassName}`}
          style={{ objectPosition: position }}
        />
      </motion.div>
      {tag && (
        <span className="absolute bottom-3 left-3 rounded-full bg-[rgb(17_28_34/0.55)] px-2.5 py-1 text-[0.68rem] tracking-wide text-ivory backdrop-blur-sm">
          {tag}
        </span>
      )}
    </motion.div>
  );
}
