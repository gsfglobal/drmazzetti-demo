"use client";

import { motion, useReducedMotion } from "motion/react";
import type { ElementType, ReactNode } from "react";

const EASE = [0.25, 1, 0.5, 1] as const;

type TextProps = {
  /** Righe del titolo: ogni riga va a capo e si rivela parola per parola. */
  lines: string[];
  as?: ElementType;
  className?: string;
  delay?: number;
  /** Rivela al caricamento invece che all'ingresso nel viewport. */
  onLoad?: boolean;
  stagger?: number;
  id?: string;
};

/** Titolo che compare parola per parola, da dietro una maschera. */
export function RevealText({ lines, as: Tag = "h2", className = "", delay = 0, onLoad = false, stagger = 0.045, id }: TextProps) {
  const reduce = useReducedMotion();
  let i = 0;
  const viewProps = onLoad
    ? { initial: "hidden", animate: "show" }
    : { initial: "hidden", whileInView: "show", viewport: { once: true, margin: "0px 0px -12% 0px" } };

  return (
    <Tag className={className} id={id}>
      <motion.span className="block" {...viewProps}>
        {lines.map((line, li) => (
          <span key={li} className="block">
            {line.split(" ").map((word, wi) => {
              const idx = i++;
              return (
                <span key={wi} className="inline-block overflow-hidden pb-[0.12em] -mb-[0.12em] align-bottom">
                  <motion.span
                    className="inline-block will-change-transform"
                    variants={{
                      hidden: reduce ? { opacity: 0 } : { y: "105%" },
                      show: reduce
                        ? { opacity: 1, transition: { duration: 0.4, delay } }
                        : { y: "0%", transition: { duration: 0.9, ease: EASE, delay: delay + idx * stagger } },
                    }}
                  >
                    {word}
                  </motion.span>
                  {wi < line.split(" ").length - 1 && " "}
                </span>
              );
            })}
          </span>
        ))}
      </motion.span>
    </Tag>
  );
}

/**
 * Titolo d'apertura animato solo in CSS: le parole salgono dalla maschera
 * subito al primo paint, senza attendere l'idratazione di React.
 */
export function IntroTitle({
  lines,
  as: Tag = "h1",
  className = "",
  delay = 0.1,
  stagger = 0.06,
  id,
}: {
  lines: string[];
  as?: ElementType;
  className?: string;
  delay?: number;
  stagger?: number;
  id?: string;
}) {
  let i = 0;
  return (
    <Tag className={className} id={id}>
      {lines.map((line, li) => (
        <span key={li} className="block">
          {line.split(" ").map((word, wi, arr) => {
            const idx = i++;
            return (
              <span key={wi} className="inline-block overflow-hidden pb-[0.12em] -mb-[0.12em] align-bottom">
                <span className="anim-word" style={{ animationDelay: `${delay + idx * stagger}s` }}>
                  {word}
                </span>
                {wi < arr.length - 1 && "\u00a0"}
              </span>
            );
          })}
        </span>
      ))}
    </Tag>
  );
}

/** Comparsa discreta (opacità + 14px) all'ingresso nel viewport. */
export function FadeIn({
  children,
  className = "",
  delay = 0,
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "li" | "section" | "p" | "article";
}) {
  const reduce = useReducedMotion();
  const Comp = motion[as];
  return (
    <Comp
      className={className}
      initial={{ opacity: 0, y: reduce ? 0 : 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "0px 0px -10% 0px" }}
      transition={{ duration: 0.8, ease: EASE, delay }}
    >
      {children}
    </Comp>
  );
}
