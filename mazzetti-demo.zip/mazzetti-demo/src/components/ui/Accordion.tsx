"use client";

import { AnimatePresence, motion } from "motion/react";
import { Plus } from "lucide-react";
import { useId, useState } from "react";

type Item = { q: string; a: string };

export function Accordion({ items, dark = false }: { items: Item[]; dark?: boolean }) {
  const [open, setOpen] = useState<number | null>(0);
  const base = useId();

  return (
    <ul className={`border-t ${dark ? "border-[var(--line-dark)]" : "border-[var(--line)]"}`}>
      {items.map((it, i) => {
        const isOpen = open === i;
        const btnId = `${base}-b${i}`;
        const panelId = `${base}-p${i}`;
        return (
          <li key={it.q} className={`border-b ${dark ? "border-[var(--line-dark)]" : "border-[var(--line)]"}`}>
            <h3>
              <button
                id={btnId}
                type="button"
                aria-expanded={isOpen}
                aria-controls={panelId}
                onClick={() => setOpen(isOpen ? null : i)}
                className="group flex w-full items-start justify-between gap-6 py-6 text-left"
              >
                <span className="font-serif text-[1.35rem] leading-snug font-medium sm:text-[1.6rem]">{it.q}</span>
                <span
                  className={`mt-1.5 grid h-8 w-8 shrink-0 place-items-center rounded-full border transition-[transform,background-color,border-color] duration-500 ease-[var(--ease-out-quart)] ${
                    dark ? "border-[var(--line-dark)]" : "border-[var(--line-strong)]"
                  } ${isOpen ? "rotate-45 bg-ink text-ivory border-ink" : ""}`}
                  aria-hidden="true"
                >
                  <Plus size={16} strokeWidth={1.5} />
                </span>
              </button>
            </h3>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  id={panelId}
                  role="region"
                  aria-labelledby={btnId}
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.45, ease: [0.25, 1, 0.5, 1] }}
                  className="overflow-hidden"
                >
                  <p className={`max-w-[42rem] pb-7 pr-12 ${dark ? "text-[rgb(247_245_240/0.75)]" : "text-steel-ink"}`}>{it.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </li>
        );
      })}
    </ul>
  );
}
