import { site } from "@/content/site";
import type { ReactNode } from "react";

/**
 * Segna un dato da confermare con lo studio. Visibile solo nella versione
 * dimostrativa (site.demo = true): un punto color champagne con spiegazione.
 */
export function Verify({ children, note = "Dato da confermare con lo studio" }: { children?: ReactNode; note?: string }) {
  if (!site.demo) return <>{children}</>;
  return (
    <span className="group/verify relative inline-flex items-baseline gap-1.5">
      {children}
      <span
        aria-hidden="true"
        className="relative top-[-0.1em] inline-block h-1.5 w-1.5 shrink-0 cursor-help rounded-full bg-champagne"
      />
      <span className="sr-only">({note})</span>
      <span
        aria-hidden="true"
        className="pointer-events-none invisible absolute bottom-full left-0 z-20 mb-2 w-max max-w-[15rem] rounded-md bg-ink px-2.5 py-1.5 text-[0.72rem] font-normal leading-snug tracking-normal text-ivory opacity-0 shadow-lg transition-opacity duration-200 group-hover/verify:visible group-hover/verify:opacity-100"
      >
        {note}
      </span>
    </span>
  );
}
