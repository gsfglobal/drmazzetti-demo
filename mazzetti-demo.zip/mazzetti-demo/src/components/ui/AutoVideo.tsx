"use client";

import { useEffect, useRef, useState } from "react";
import { Pause, Play } from "lucide-react";
import { asset } from "@/lib/paths";

type Props = {
  /** Percorso in /public senza estensione, es. "/video/sala-chirurgica" (servono .mp4 e .webm) */
  src: string;
  poster: string;
  /** Descrizione del contenuto per chi usa un lettore di schermo */
  label: string;
  className?: string;
  /** Rapporto d'aspetto del riquadro video (classe Tailwind) */
  ratio?: string;
  caption?: string;
};

/**
 * Video muto in riproduzione automatica e continua. Parte solo quando è
 * visibile, si ferma fuori schermo e ha un pulsante pausa (WCAG 2.2.2).
 * Con «riduci movimento» attivo non parte da solo: resta il fotogramma.
 */
export function AutoVideo({ src, poster, label, className = "", ratio = "aspect-[9/16]", caption }: Props) {
  const ref = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [userPaused, setUserPaused] = useState(false);

  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setUserPaused(true);
      return;
    }
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting && !v.dataset.userPaused) v.play().catch(() => {});
        else v.pause();
      },
      { threshold: 0.25 },
    );
    io.observe(v);
    return () => io.disconnect();
  }, []);

  const toggle = () => {
    const v = ref.current;
    if (!v) return;
    if (v.paused) {
      delete v.dataset.userPaused;
      setUserPaused(false);
      v.play().catch(() => {});
    } else {
      v.dataset.userPaused = "1";
      setUserPaused(true);
      v.pause();
    }
  };

  return (
    <figure className={className}>
      <div className={`relative w-full overflow-hidden bg-mist ${ratio}`}>
        <video
          ref={ref}
          className="absolute inset-0 h-full w-full object-cover"
          poster={asset(poster)}
          muted
          loop
          playsInline
          preload="metadata"
          aria-label={label}
          onPlay={() => setPlaying(true)}
          onPause={() => setPlaying(false)}
        >
          <source src={asset(`${src}.mp4`)} type="video/mp4" />
          <source src={asset(`${src}.webm`)} type="video/webm" />
        </video>
        <button
          type="button"
          onClick={toggle}
          className="absolute right-3 bottom-3 grid h-10 w-10 place-items-center rounded-full bg-[rgb(17_28_34/0.55)] text-ivory backdrop-blur-sm transition-colors hover:bg-[rgb(17_28_34/0.75)]"
          aria-label={playing && !userPaused ? "Metti in pausa il video" : "Riproduci il video"}
        >
          {playing && !userPaused ? (
            <Pause size={16} strokeWidth={1.6} aria-hidden="true" />
          ) : (
            <Play size={16} strokeWidth={1.6} aria-hidden="true" />
          )}
        </button>
      </div>
      {caption && <figcaption className="label mt-3">{caption}</figcaption>}
    </figure>
  );
}
