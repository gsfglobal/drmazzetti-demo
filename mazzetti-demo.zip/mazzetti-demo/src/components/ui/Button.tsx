"use client";

import Link from "next/link";
import { motion, useMotionValue, useSpring, useReducedMotion } from "motion/react";
import { useRef, type ReactNode, type PointerEvent } from "react";

type Variant = "solid" | "outline" | "light" | "outline-light";

const styles: Record<Variant, string> = {
  solid: "bg-ink text-ivory hover:bg-midnight",
  outline: "border border-[var(--line-strong)] text-ink hover:border-ink",
  light: "bg-ivory text-ink hover:bg-paper",
  "outline-light": "border border-[rgb(247_245_240/0.35)] text-ivory hover:border-ivory",
};

type Props = {
  href: string;
  children: ReactNode;
  variant?: Variant;
  icon?: ReactNode;
  className?: string;
  external?: boolean;
  magnetic?: boolean;
  ariaLabel?: string;
};

/**
 * Pulsante-link. L'effetto «magnetico» è molto leggero (max ~5px), solo con
 * puntatore fine e senza riduzione del movimento.
 */
export function ButtonLink({
  href,
  children,
  variant = "solid",
  icon,
  className = "",
  external,
  magnetic = true,
  ariaLabel,
}: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const reduce = useReducedMotion();
  const x = useSpring(useMotionValue(0), { stiffness: 220, damping: 18, mass: 0.4 });
  const y = useSpring(useMotionValue(0), { stiffness: 220, damping: 18, mass: 0.4 });

  const onMove = (e: PointerEvent) => {
    if (!magnetic || reduce || e.pointerType !== "mouse" || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    x.set(((e.clientX - r.left) / r.width - 0.5) * 10);
    y.set(((e.clientY - r.top) / r.height - 0.5) * 8);
  };
  const onLeave = () => {
    x.set(0);
    y.set(0);
  };

  const cls = `group/btn inline-flex min-h-12 items-center justify-center gap-3 rounded-full px-6 text-[0.95rem] font-medium tracking-[0.005em] transition-colors duration-300 ${styles[variant]} ${className}`;
  const inner = (
    <>
      <span>{children}</span>
      {icon && (
        <span className="transition-transform duration-300 ease-[var(--ease-out-quart)] group-hover/btn:translate-x-0.5">
          {icon}
        </span>
      )}
    </>
  );

  const isInternal = href.startsWith("/") && !external;

  return (
    <motion.span ref={ref} style={{ x, y }} onPointerMove={onMove} onPointerLeave={onLeave} className="inline-flex">
      {isInternal ? (
        <Link href={href} className={cls} aria-label={ariaLabel}>
          {inner}
        </Link>
      ) : (
        <a
          href={href}
          className={cls}
          aria-label={ariaLabel}
          {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
        >
          {inner}
        </a>
      )}
    </motion.span>
  );
}
