// Arcata dentale procedurale campionata come nuvola di punti, come
// un'impronta acquisita da uno scanner intraorale. Nessun file 3D esterno.

type ToothSpec = { w: number; b: number; h: number; kind: "incisor" | "lateral" | "canine" | "premolar" | "molar" };

// Dal centro verso il fondo: dimensioni indicative in millimetri.
const HALF_ARCH: ToothSpec[] = [
  { w: 5.6, b: 5.9, h: 9.0, kind: "incisor" }, // incisivo centrale inferiore
  { w: 6.0, b: 6.2, h: 9.3, kind: "lateral" },
  { w: 7.0, b: 7.6, h: 10.6, kind: "canine" },
  { w: 7.1, b: 7.9, h: 8.4, kind: "premolar" },
  { w: 7.3, b: 8.4, h: 8.0, kind: "premolar" },
  { w: 11.1, b: 10.3, h: 7.6, kind: "molar" },
  { w: 10.4, b: 10.0, h: 7.2, kind: "molar" },
];

const GAP = 0.3;

// Generatore pseudo-casuale deterministico (stessa forma a ogni caricamento)
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Curva dell'arcata nel piano xz: incisivi davanti (z positivo), molari dietro.
function curve(t: number, W: number, D: number) {
  const x = W * t;
  const z = D * (1 - Math.pow(Math.abs(t), 2.15));
  return { x, z };
}

function buildArcTable(W: number, D: number, n = 2000) {
  const ts: number[] = [];
  const ss: number[] = [];
  let s = 0;
  let prev = curve(0, W, D);
  ts.push(0);
  ss.push(0);
  for (let i = 1; i <= n; i++) {
    const t = i / n;
    const p = curve(t, W, D);
    s += Math.hypot(p.x - prev.x, p.z - prev.z);
    ts.push(t);
    ss.push(s);
    prev = p;
  }
  return { ts, ss, total: s };
}

function tAtS(table: ReturnType<typeof buildArcTable>, s: number) {
  const { ts, ss } = table;
  let lo = 0;
  let hi = ss.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (ss[mid] < s) lo = mid;
    else hi = mid;
  }
  const f = (s - ss[lo]) / Math.max(1e-6, ss[hi] - ss[lo]);
  return ts[lo] + (ts[hi] - ts[lo]) * f;
}

function frameAt(t: number, W: number, D: number, side: 1 | -1) {
  const e = 1e-3;
  const p = curve(t, W, D);
  const q = curve(Math.min(1, t + e), W, D);
  let tx = q.x - p.x;
  let tz = q.z - p.z;
  const l = Math.hypot(tx, tz) || 1;
  tx /= l;
  tz /= l;
  // normale verso l'esterno (lato vestibolare)
  let nx = tz;
  let nz = -tx;
  if (nx * p.x + nz * (p.z - D * 0.35) < 0) {
    nx = -nx;
    nz = -nz;
  }
  return { x: p.x * side, z: p.z, tx: tx * side, tz, nx: nx * side, nz };
}

// Rilievo occlusale (cuspidi) in coordinate normalizzate u,v ∈ [-1,1]
function occlusal(kind: ToothSpec["kind"], u: number, v: number) {
  const g = (cu: number, cv: number, r: number, hgt: number) =>
    hgt * Math.exp(-((u - cu) ** 2 + (v - cv) ** 2) / (2 * r * r));
  switch (kind) {
    case "molar":
      return (
        g(-0.45, 0.42, 0.32, 1.25) + g(0.42, 0.45, 0.32, 1.15) + g(-0.42, -0.45, 0.32, 1.1) +
        g(0.45, -0.42, 0.32, 1.05) + g(0.05, 0.62, 0.22, 0.6) - 0.55 * Math.exp(-(v * v) / 0.06)
      );
    case "premolar":
      return g(0, 0.48, 0.34, 1.25) + g(0, -0.5, 0.34, 0.85) - 0.35 * Math.exp(-(v * v) / 0.05);
    case "canine":
      return 2.6 * Math.exp(-(u * u + v * v) / 0.12);
    default:
      return 0.15 * (1 - u * u);
  }
}

export type ArchCloud = {
  positions: Float32Array;
  scatter: Float32Array;
  scanX: Float32Array;
  kind: Float32Array;
  count: number;
};

export function buildArchCloud(total: number, seed = 7): ArchCloud {
  const rand = rng(seed);
  const halfLen = HALF_ARCH.reduce((a, t) => a + t.w + GAP, 0);
  // scala la curva perché la mezza arcata misuri esattamente halfLen
  let W = 24;
  let D = 36;
  let table = buildArcTable(W, D);
  const k = halfLen / table.total;
  W *= k;
  D *= k;
  table = buildArcTable(W, D);

  const toothShare = 0.9;
  const nTeeth = Math.floor(total * toothShare);
  const nGum = total - nTeeth;
  const sizes = HALF_ARCH.map((t) => t.w * t.b + t.h * (t.w + t.b));
  const sizeSum = sizes.reduce((a, b) => a + b, 0) * 2;

  const pos: number[] = [];
  const kinds: number[] = [];

  const sides: (1 | -1)[] = [1, -1];
  for (const side of sides) {
    let sCursor = GAP / 2;
    HALF_ARCH.forEach((spec, idx) => {
      const sMid = sCursor + spec.w / 2;
      sCursor += spec.w + GAP;
      const t = tAtS(table, sMid);
      const f = frameAt(t, W, D, side);
      const nPts = Math.floor((nTeeth * sizes[idx]) / sizeSum);
      const a = spec.w / 2;
      const b = spec.b / 2;
      const isAnterior = spec.kind === "incisor" || spec.kind === "lateral";
      const sideH = spec.kind === "canine" ? spec.h * 0.72 : isAnterior ? spec.h * 0.88 : spec.h * 0.78;
      const n = 2.7;

      for (let i = 0; i < nPts; i++) {
        let lu: number, lv: number, ly: number;
        const onTop = rand() < (isAnterior ? 0.12 : 0.36);
        if (!onTop) {
          const th = rand() * Math.PI * 2;
          const y = Math.pow(rand(), 0.85) * sideH;
          const yn = y / sideH;
          // profilo: colletto più stretto, massimo convesso a ~60%
          const bulge = 0.82 + 0.22 * Math.sin(Math.min(1, yn * 1.25) * Math.PI * 0.85);
          const bTaper = isAnterior ? 1 - 0.72 * Math.pow(yn, 1.3) : spec.kind === "canine" ? 1 - 0.35 * yn : 1;
          const c = Math.cos(th);
          const s = Math.sin(th);
          const r = 1 / Math.pow(Math.pow(Math.abs(c) / a, n) + Math.pow(Math.abs(s) / (b * bTaper), n), 1 / n);
          lu = c * r * bulge;
          lv = s * r * bulge;
          ly = y;
        } else {
          // superficie occlusale / margine incisale
          const th = rand() * Math.PI * 2;
          const rr = Math.sqrt(rand());
          const c = Math.cos(th);
          const s = Math.sin(th);
          const bTop = isAnterior ? 0.24 : spec.kind === "canine" ? 0.62 : 0.94;
          const aTop = spec.kind === "canine" ? 0.8 : 0.94;
          const r = 1 / Math.pow(Math.pow(Math.abs(c) / (a * aTop), n) + Math.pow(Math.abs(s) / (b * bTop), n), 1 / n);
          lu = c * r * rr * 0.98;
          lv = s * r * rr * 0.98;
          const un = lu / a;
          const vn = lv / b;
          ly = sideH + occlusal(spec.kind, un, vn) + (1 - rr) * (isAnterior ? 0.25 : 0.35);
        }
        // micro-rumore della scansione
        lu += (rand() - 0.5) * 0.06;
        lv += (rand() - 0.5) * 0.06;
        ly += (rand() - 0.5) * 0.06;

        const x = f.x + f.tx * lu + f.nx * lv;
        const z = f.z + f.tz * lu + f.nz * lv;
        pos.push(x, ly, z);
        kinds.push(0);
      }
    });
  }

  // Gengiva: due fasce (vestibolare e linguale) con festoni tra i denti
  const gumLen = halfLen;
  for (let i = 0; i < nGum; i++) {
    const side: 1 | -1 = rand() < 0.5 ? 1 : -1;
    const s = rand() * gumLen;
    const t = tAtS(table, s);
    const f = frameAt(t, W, D, side);
    // posizione del dente più vicino per i festoni
    let acc = GAP / 2;
    let local = 0;
    let bHalf = 4;
    for (const spec of HALF_ARCH) {
      if (s <= acc + spec.w + GAP) {
        local = (s - acc - spec.w / 2) / (spec.w / 2);
        bHalf = spec.b / 2;
        break;
      }
      acc += spec.w + GAP;
    }
    const scallop = 1.6 * (1 - Math.min(1, local * local)) - 0.2;
    const buccal = rand() < 0.62 ? 1 : -1;
    const across = rand(); // 0 = margine gengivale, 1 = fondo
    const off = (bHalf * 0.95 + across * 3.2) * buccal;
    const y = scallop * (1 - across) - across * 4.5 - 0.5;
    const x = f.x + f.nx * off + (rand() - 0.5) * 0.08;
    const z = f.z + f.nz * off + (rand() - 0.5) * 0.08;
    pos.push(x, y, z);
    kinds.push(1);
  }

  const count = kinds.length;
  const positions = new Float32Array(pos);
  // centra il modello
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (let i = 0; i < count; i++) {
    minX = Math.min(minX, positions[i * 3]);
    maxX = Math.max(maxX, positions[i * 3]);
    minZ = Math.min(minZ, positions[i * 3 + 2]);
    maxZ = Math.max(maxZ, positions[i * 3 + 2]);
  }
  const cx = (minX + maxX) / 2;
  const cz = (minZ + maxZ) / 2;
  const scanX = new Float32Array(count);
  const scatter = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    positions[i * 3] -= cx;
    positions[i * 3 + 2] -= cz;
    scanX[i] = (positions[i * 3] - (minX - cx)) / (maxX - minX);
    // direzione di «dispersione» prima dell'acquisizione
    scatter[i * 3] = (rand() - 0.5) * 10;
    scatter[i * 3 + 1] = 6 + rand() * 14;
    scatter[i * 3 + 2] = (rand() - 0.5) * 10;
  }
  return { positions, scatter, scanX, kind: new Float32Array(kinds), count };
}
