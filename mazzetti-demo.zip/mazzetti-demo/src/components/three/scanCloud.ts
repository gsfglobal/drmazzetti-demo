import * as THREE from "three";
import { buildArchCloud } from "./archGeometry";

const VERT = /* glsl */ `
  attribute vec3 aScatter;
  attribute float aScanX;
  attribute float aKind;
  uniform float uScan;
  uniform float uSize;
  uniform float uPixelRatio;
  varying float vAcquired;
  varying float vFront;
  varying float vKind;
  varying float vDepth;

  void main() {
    // 0 = ancora da acquisire, 1 = acquisito
    float acquired = 1.0 - smoothstep(uScan - 0.05, uScan + 0.01, aScanX);
    float e = 1.0 - acquired;
    vec3 p = position + aScatter * e * e;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    gl_Position = projectionMatrix * mv;
    float front = 1.0 - clamp(abs(aScanX - uScan) / 0.035, 0.0, 1.0);
    vFront = front;
    vAcquired = acquired;
    vKind = aKind;
    vDepth = clamp((-mv.z - 105.0) / 60.0, 0.0, 1.0);
    gl_PointSize = uSize * uPixelRatio * (110.0 / -mv.z) * (1.0 + front * 1.4) * (aKind > 0.5 ? 0.85 : 1.0);
  }
`;

const FRAG = /* glsl */ `
  precision mediump float;
  uniform vec3 uInk;
  uniform vec3 uGum;
  uniform vec3 uGlow;
  varying float vAcquired;
  varying float vFront;
  varying float vKind;
  varying float vDepth;

  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    if (d > 0.5) discard;
    float soft = smoothstep(0.5, 0.18, d);
    vec3 base = mix(uInk, uGum, step(0.5, vKind));
    vec3 col = mix(base, uGlow, vFront);
    float a = (vKind > 0.5 ? 0.3 : 0.9) * mix(1.0, 0.5, vDepth);
    a = a * max(vAcquired, vFront * 0.9) * soft;
    gl_FragColor = vec4(col, a);
  }
`;

export type ScanCloudOptions = {
  points: number;
  reducedMotion: boolean;
  onReady?: () => void;
};

/** Scena dell'hero: un'arcata che compare come acquisita da uno scanner. */
export class ScanCloud {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private group = new THREE.Group();
  private material: THREE.ShaderMaterial;
  private raf = 0;
  private start = 0;
  private visible = true;
  private pointer = { x: 0, y: 0, tx: 0, ty: 0 };
  private ro: ResizeObserver;
  private io: IntersectionObserver;
  private disposed = false;
  private scanDone = false;

  constructor(private host: HTMLElement, private opts: ScanCloudOptions) {
    this.renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setClearColor(0x000000, 0);
    host.appendChild(this.renderer.domElement);
    this.renderer.domElement.setAttribute("aria-hidden", "true");

    this.camera = new THREE.PerspectiveCamera(30, 1, 1, 400);
    this.camera.position.set(0, 104, 64);
    this.camera.lookAt(0, -2, 4);

    const cloud = buildArchCloud(opts.points);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(cloud.positions, 3));
    geo.setAttribute("aScatter", new THREE.BufferAttribute(cloud.scatter, 3));
    geo.setAttribute("aScanX", new THREE.BufferAttribute(cloud.scanX, 1));
    geo.setAttribute("aKind", new THREE.BufferAttribute(cloud.kind, 1));

    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: true,
      depthWrite: false,
      uniforms: {
        uScan: { value: opts.reducedMotion ? 1.2 : -0.08 },
        uSize: { value: 1.9 },
        uPixelRatio: { value: this.renderer.getPixelRatio() },
        uInk: { value: new THREE.Color("#111c22") },
        uGum: { value: new THREE.Color("#79949e") },
        uGlow: { value: new THREE.Color("#b6a17e") },
      },
    });

    const points = new THREE.Points(geo, this.material);
    this.group.add(points);
    this.group.rotation.y = -0.22;
    this.scene.add(this.group);

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(host);
    this.resize();

    this.io = new IntersectionObserver(([e]) => {
      this.visible = e.isIntersecting;
      if (this.visible && !this.raf) this.loop();
    });
    this.io.observe(host);

    window.addEventListener("pointermove", this.onPointer, { passive: true });
    this.start = performance.now();
    this.renderer.render(this.scene, this.camera);
    opts.onReady?.();
    this.loop();
  }

  private onPointer = (e: PointerEvent) => {
    if (e.pointerType !== "mouse") return;
    this.pointer.tx = (e.clientX / window.innerWidth - 0.5) * 2;
    this.pointer.ty = (e.clientY / window.innerHeight - 0.5) * 2;
  };

  private resize() {
    const w = this.host.clientWidth;
    const h = this.host.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = "100%";
    this.renderer.domElement.style.height = "100%";
    this.camera.aspect = w / h;
    // su schermi stretti allontana la camera per far entrare l'arcata
    const r = w / h;
    const fit = r < 0.8 ? 1.75 : r < 1.05 ? 1.45 : r < 1.25 ? 1.18 : 1;
    this.camera.position.set(0, 104 * fit, 64 * fit);
    this.camera.lookAt(0, -2, 4);
    this.camera.updateProjectionMatrix();
    if (!this.raf) this.renderer.render(this.scene, this.camera);
  }

  private loop = () => {
    if (this.disposed || !this.visible) {
      this.raf = 0;
      return;
    }
    const t = (performance.now() - this.start) / 1000;
    const u = this.material.uniforms;

    if (!this.opts.reducedMotion) {
      // scansione: parte dopo il titolo e dura ~3,2 s
      const k = Math.min(1, Math.max(0, (t - 0.7) / 3.2));
      const eased = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
      u.uScan.value = -0.08 + eased * 1.3;
      if (k >= 1) this.scanDone = true;

      this.pointer.x += (this.pointer.tx - this.pointer.x) * 0.04;
      this.pointer.y += (this.pointer.ty - this.pointer.y) * 0.04;
      const idle = this.scanDone ? Math.sin((t - 3.9) * 0.22) * 0.16 : 0;
      this.group.rotation.y = -0.22 + idle + this.pointer.x * 0.08;
      this.group.rotation.x = this.pointer.y * 0.04;
    }

    this.renderer.render(this.scene, this.camera);
    if (this.opts.reducedMotion) {
      this.raf = 0;
      return;
    }
    this.raf = requestAnimationFrame(this.loop);
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.io.disconnect();
    window.removeEventListener("pointermove", this.onPointer);
    this.scene.traverse((o) => {
      if (o instanceof THREE.Points) o.geometry.dispose();
    });
    this.material.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}

export function webglAvailable() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}
