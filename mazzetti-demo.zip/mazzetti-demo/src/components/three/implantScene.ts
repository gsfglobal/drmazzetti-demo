import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";

/*
 * Impianto, moncone e corona procedurali. Le quattro fasi (valutazione,
 * pianificazione, trattamento, controlli) sono una rappresentazione
 * concettuale e informativa, non un protocollo dello studio.
 */

const L = 11.5; // lunghezza impianto
const R_CORE = 1.62;
const DEPTH = 0.42;
const PITCH = 0.85;
const COLLAR = 0.9;

function fixtureGeometry(radial = 96, axial = 240) {
  const pos: number[] = [];
  const idx: number[] = [];
  for (let j = 0; j <= axial; j++) {
    const z = -(j / axial) * L; // 0 = piattaforma, -L = apice
    const depthFromTop = -z;
    // rastremazione apicale
    const apexT = Math.max(0, (depthFromTop - (L - 3.2)) / 3.2);
    const core = R_CORE * (1 - 0.32 * apexT * apexT) - 0.05 * Math.sin(Math.min(1, depthFromTop / COLLAR) * Math.PI * 0.5) * 0;
    for (let i = 0; i <= radial; i++) {
      const th = (i / radial) * Math.PI * 2;
      let r = core + DEPTH;
      if (depthFromTop > COLLAR) {
        // profilo del filetto elicoidale (trapezoidale)
        const f = (((depthFromTop - COLLAR) / PITCH + th / (Math.PI * 2)) % 1 + 1) % 1;
        const tri = f < 0.15 ? f / 0.15 : f < 0.35 ? 1 : f < 0.55 ? 1 - (f - 0.35) / 0.2 : 0;
        const fade = Math.min(1, (depthFromTop - COLLAR) / 0.6) * (1 - 0.5 * apexT);
        r = core + DEPTH * tri * fade;
      } else {
        r = core + DEPTH * 0.92;
      }
      // apice arrotondato
      if (depthFromTop > L - 0.6) {
        const k = (depthFromTop - (L - 0.6)) / 0.6;
        r *= Math.sqrt(Math.max(0, 1 - k * k)) * 0.9 + 0.1;
      }
      pos.push(Math.cos(th) * r, z, Math.sin(th) * r);
    }
  }
  const row = radial + 1;
  for (let j = 0; j < axial; j++) {
    for (let i = 0; i < radial; i++) {
      const a = j * row + i;
      const b = a + row;
      idx.push(a, b, a + 1, b, b + 1, a + 1);
    }
  }
  // tappo superiore (piattaforma) con esagono interno
  const centerTop = pos.length / 3;
  pos.push(0, 0, 0);
  for (let i = 0; i < radial; i++) idx.push(centerTop, i + 1, i);
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function abutmentGeometry() {
  const p: THREE.Vector2[] = [];
  const pts: [number, number][] = [
    [0, -1.1],
    [1.25, -1.1],
    [1.3, 0],
    [1.75, 0.15],
    [2.25, 1.0],
    [2.25, 1.3],
    [1.85, 1.45],
    [1.6, 4.8],
    [1.35, 5.5],
    [0.6, 5.75],
    [0, 5.78],
  ];
  pts.forEach(([x, y]) => p.push(new THREE.Vector2(x, y)));
  return new THREE.LatheGeometry(p, 72);
}

function crownGeometry(radial = 120, rows = 70) {
  // Corona di un molare: pareti con convessità naturale, piano occlusale con
  // quattro cuspidi e solchi. Sezione a superellisse.
  const A = 4.6;
  const B = 4.3;
  const N = 2.6;
  const yMargin = -2.7;
  const yEdge = 2.0;
  const sideRows = Math.round(rows * 0.55);
  const pos: number[] = [];
  const idx: number[] = [];
  const outline = (th: number) => {
    const c = Math.cos(th);
    const s = Math.sin(th);
    return 1 / Math.pow(Math.pow(Math.abs(c) / A, N) + Math.pow(Math.abs(s) / B, N), 1 / N);
  };
  const relief = (u: number, v: number) => {
    const g = (cu: number, cv: number, r: number, h: number) => h * Math.exp(-((u - cu) ** 2 + (v - cv) ** 2) / (2 * r * r));
    return (
      g(-0.42, 0.42, 0.24, 1.05) + g(0.44, 0.44, 0.24, 0.95) + g(-0.4, -0.44, 0.24, 0.9) + g(0.44, -0.4, 0.24, 0.85) -
      0.55 * Math.exp(-(v * v) / 0.018) * (1 - 0.6 * u * u) - 0.35 * Math.exp(-(u * u) / 0.02) * (1 - v * v)
    );
  };
  for (let j = 0; j <= rows; j++) {
    const t = j / rows;
    for (let i = 0; i <= radial; i++) {
      const th = (i / radial) * Math.PI * 2;
      const R = outline(th);
      let r: number;
      let y: number;
      if (j <= sideRows) {
        const k = j / sideRows; // 0 margine → 1 bordo occlusale
        y = yMargin + (yEdge - yMargin) * k;
        const conv = 0.62 + 0.4 * Math.sin(Math.min(1, k * 1.15) * Math.PI * 0.62) - 0.06 * Math.pow(k, 4);
        r = R * conv;
      } else {
        const k = (j - sideRows) / (rows - sideRows); // 0 bordo → 1 centro
        const rr = 1 - k;
        const edgeR = 0.96 - 0.06;
        r = R * edgeR * rr;
        const u = (Math.cos(th) * r) / A;
        const v = (Math.sin(th) * r) / B;
        // arrotonda il bordo e solleva le cuspidi
        y = yEdge + 0.55 * Math.sin(Math.min(1, k * 3) * Math.PI * 0.5) + relief(u, v) * Math.min(1, k * 2.2);
      }
      pos.push(Math.cos(th) * r, y, Math.sin(th) * r);
    }
  }
  const row = radial + 1;
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < radial; i++) {
      const a = j * row + i;
      const b = a + row;
      idx.push(a, b, a + 1, b, b + 1, a + 1);
    }
  }
  // fondo chiuso
  const c = pos.length / 3;
  pos.push(0, yMargin + 0.4, 0);
  for (let i = 0; i < radial; i++) idx.push(c, i, i + 1);
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

type Mats = {
  titanium: THREE.MeshPhysicalMaterial;
  abut: THREE.MeshPhysicalMaterial;
  crown: THREE.MeshPhysicalMaterial;
  bone: THREE.MeshPhysicalMaterial;
  ghost: THREE.MeshBasicMaterial;
  line: THREE.LineDashedMaterial;
  ring: THREE.MeshBasicMaterial;
  trab: THREE.PointsMaterial;
  edges: THREE.LineBasicMaterial;
};

const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const ease = (x: number) => {
  const k = clamp01(x);
  return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
};

export class ImplantScene {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(32, 1, 0.5, 300);
  private root = new THREE.Group();
  private fixture: THREE.Mesh;
  private ghost: THREE.Mesh;
  private abutment: THREE.Mesh;
  private crown: THREE.Mesh;
  private bone: THREE.Mesh;
  private boneEdges: THREE.LineSegments;
  private last = performance.now();
  private trab: THREE.Points;
  private axis: THREE.Line;
  private rings: THREE.Mesh[] = [];
  private checkRing: THREE.Mesh;
  private mats: Mats;
  private progress = 0;
  private shown = 0;
  private raf = 0;
  private visible = false;
  private t0 = performance.now();
  private ro: ResizeObserver;
  private io: IntersectionObserver;
  private disposed = false;

  constructor(private host: HTMLElement, private reducedMotion: boolean, lowPower: boolean) {
    this.renderer = new THREE.WebGLRenderer({ antialias: !lowPower, alpha: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowPower ? 1.5 : 2));
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    host.appendChild(this.renderer.domElement);
    this.renderer.domElement.setAttribute("aria-hidden", "true");

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const key = new THREE.DirectionalLight("#fff4e6", 1.6);
    key.position.set(10, 18, 14);
    this.scene.add(key, new THREE.AmbientLight("#9fb3bb", 0.25));

    this.mats = {
      titanium: new THREE.MeshPhysicalMaterial({ color: "#c9cdd1", metalness: 1, roughness: 0.3, envMapIntensity: 1.2, transparent: true }),
      abut: new THREE.MeshPhysicalMaterial({ color: "#c8b48e", metalness: 1, roughness: 0.28, envMapIntensity: 1.1, transparent: true }),
      crown: new THREE.MeshPhysicalMaterial({
        color: "#ebe5d9",
        roughness: 0.38,
        metalness: 0,
        clearcoat: 0.55,
        clearcoatRoughness: 0.3,
        transparent: true,
      }),
      edges: new THREE.LineBasicMaterial({ color: "#79949e", transparent: true, opacity: 0.7 }),
      bone: new THREE.MeshPhysicalMaterial({
        color: "#c9bfab",
        roughness: 0.9,
        transparent: true,
        opacity: 0.12,
        depthWrite: false,
        side: THREE.DoubleSide,
      }),
      ghost: new THREE.MeshBasicMaterial({ color: "#9a8664", wireframe: true, transparent: true, opacity: 0 }),
      line: new THREE.LineDashedMaterial({ color: "#192b35", dashSize: 0.6, gapSize: 0.45, transparent: true, opacity: 0 }),
      ring: new THREE.MeshBasicMaterial({ color: "#192b35", transparent: true, opacity: 0 }),
      trab: new THREE.PointsMaterial({ color: "#6f8189", size: 0.2, transparent: true, opacity: 0.55, depthWrite: false }),
    };

    // Blocco osseo (sezione) con trabecole
    const boneGeo = new THREE.BoxGeometry(13, 15, 9);
    this.bone = new THREE.Mesh(boneGeo, this.mats.bone);
    this.bone.position.set(0, -6.9, 0);
    this.boneEdges = new THREE.LineSegments(new THREE.EdgesGeometry(boneGeo), this.mats.edges);
    this.boneEdges.position.copy(this.bone.position);
    const tp: number[] = [];
    for (let i = 0; i < (lowPower ? 1800 : 4200); i++) {
      const x = (Math.random() - 0.5) * 11.5;
      const y = -0.8 - Math.random() * 13;
      const z = (Math.random() - 0.5) * 7.5;
      // densità maggiore vicino alla corticale
      if (Math.random() > 0.35 + 0.65 * Math.min(1, (Math.abs(x) / 5.75) ** 2 + (y > -2 ? 1 : 0))) continue;
      tp.push(x, y, z);
    }
    const tg = new THREE.BufferGeometry();
    tg.setAttribute("position", new THREE.Float32BufferAttribute(tp, 3));
    this.trab = new THREE.Points(tg, this.mats.trab);

    const fg = fixtureGeometry(lowPower ? 64 : 96, lowPower ? 160 : 240);
    this.fixture = new THREE.Mesh(fg, this.mats.titanium);
    this.ghost = new THREE.Mesh(fixtureGeometry(24, 60), this.mats.ghost);

    this.abutment = new THREE.Mesh(abutmentGeometry(), this.mats.abut);
    this.crown = new THREE.Mesh(crownGeometry(), this.mats.crown);

    // asse di progetto e anelli di misura
    const axisGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 12, 0), new THREE.Vector3(0, -15, 0)]);
    this.axis = new THREE.Line(axisGeo, this.mats.line);
    this.axis.computeLineDistances();
    for (const y of [0, -L]) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(y === 0 ? 3.2 : 2.4, 0.025, 8, 96), this.mats.ring);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = y;
      this.rings.push(ring);
    }
    this.checkRing = new THREE.Mesh(new THREE.TorusGeometry(2.9, 0.03, 8, 96), this.mats.ring.clone());
    this.checkRing.rotation.x = Math.PI / 2;

    this.root.add(this.bone, this.boneEdges, this.trab, this.ghost, this.fixture, this.abutment, this.crown, this.axis, ...this.rings, this.checkRing);
    this.root.position.y = 1.5;
    this.scene.add(this.root);

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(host);
    this.io = new IntersectionObserver(([e]) => {
      this.visible = e.isIntersecting;
      if (this.visible && !this.raf) {
        this.last = performance.now();
        this.loop();
      }
    });
    this.io.observe(host);
    this.resize();
    this.apply(0, 0);
    this.renderer.render(this.scene, this.camera);
  }

  /** Avanzamento continuo da 0 (valutazione) a 3 (controlli). */
  setProgress(p: number) {
    this.progress = Math.min(3, Math.max(0, p));
    if (this.visible && !this.raf) {
      this.last = performance.now();
      this.loop();
    }
  }

  private resize() {
    const w = this.host.clientWidth;
    const h = this.host.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = "100%";
    this.renderer.domElement.style.height = "100%";
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.render(this.scene, this.camera);
  }

  private apply(p: number, time: number) {
    const s1 = ease(p - 0.15); // pianificazione
    const s2 = ease((p - 1.3) / 0.75); // trattamento
    const s3 = ease((p - 2.05) / 0.9); // controlli

    // osso: più presente in valutazione, poi trasparente
    this.mats.bone.opacity = 0.16 - 0.06 * s1;
    this.mats.trab.opacity = 0.8 - 0.4 * s1;
    this.mats.edges.opacity = 0.75 - 0.35 * s1;

    // progetto: asse, anelli e sagoma fantasma
    const plan = s1 * (1 - s2 * 0.85);
    this.mats.line.opacity = plan;
    this.mats.ring.opacity = plan * 0.9;
    this.mats.ghost.opacity = 0.55 * s1 * (1 - s2);

    // impianto: scende ruotando come durante l'inserimento
    this.fixture.visible = s2 > 0.001;
    this.fixture.position.y = (1 - s2) * 16;
    this.fixture.rotation.y = (1 - s2) * Math.PI * 4;
    this.mats.titanium.opacity = clamp01(s2 * 2.5);

    // moncone e corona
    this.abutment.visible = s3 > 0.001;
    this.crown.visible = s3 > 0.001;
    this.abutment.position.y = 0.25 + (1 - ease(s3 * 1.25)) * 10;
    this.mats.abut.opacity = clamp01(s3 * 3);
    this.crown.position.y = 4.15 + (1 - ease((s3 - 0.2) * 1.25)) * 14;
    this.mats.crown.opacity = clamp01((s3 - 0.15) * 3);

    // controllo: un anello percorre l'impianto
    const ck = this.checkRing.material as THREE.MeshBasicMaterial;
    const sweep = (time * 0.35) % 1;
    ck.opacity = s3 > 0.85 ? (1 - Math.abs(sweep - 0.5) * 2) * 0.8 * ease((s3 - 0.85) / 0.15) : 0;
    this.checkRing.position.y = 2 - sweep * (L + 2);

    // camera
    const target = new THREE.Vector3(0, -2.5 + s3 * 4.2, 0);
    const radius = 46 - s1 * 4 + s3 * 6;
    const ang = -0.55 + p * 0.22 + (this.reducedMotion ? 0 : Math.sin(time * 0.15) * 0.06);
    this.camera.position.set(Math.sin(ang) * radius, 10 + s3 * 6, Math.cos(ang) * radius);
    this.camera.lookAt(target);
    this.root.rotation.y = this.reducedMotion ? 0 : time * 0.05 * s3;
  }

  private loop = () => {
    if (this.disposed || !this.visible) {
      this.raf = 0;
      return;
    }
    const now = performance.now();
    const dt = Math.min(0.25, (now - this.last) / 1000);
    this.last = now;
    const time = (now - this.t0) / 1000;
    // inseguimento morbido dello scroll, indipendente dal frame rate
    const k = this.reducedMotion ? 1 : 1 - Math.exp(-dt * 5);
    this.shown += (this.progress - this.shown) * k;
    this.apply(this.shown, time);
    this.renderer.render(this.scene, this.camera);
    const settled = Math.abs(this.progress - this.shown) < 0.0005;
    // in fase «controlli» l'animazione continua, altrimenti si ferma quando è ferma
    if (settled && (this.reducedMotion || this.shown < 2.6)) {
      this.raf = 0;
      return;
    }
    this.raf = requestAnimationFrame(this.loop);
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.io.disconnect();
    this.scene.traverse((o) => {
      if (o instanceof THREE.Mesh || o instanceof THREE.Points || o instanceof THREE.Line) o.geometry.dispose();
    });
    Object.values(this.mats).forEach((m) => m.dispose());
    this.scene.environment?.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
