import { PageIntro } from "./PageIntro";
import { site } from "@/content/site";

export function LegalPage({
  title,
  path,
  sections,
}: {
  title: string;
  path: string;
  sections: { heading: string; body: string[] }[];
}) {
  return (
    <>
      <PageIntro crumbs={[{ name: title, path }]} title={[title]} />
      <section className="pb-[var(--section-y)]">
        <div className="wrap grid lg:grid-cols-12 lg:gap-x-10">
          <div className="lg:col-span-8 lg:col-start-3">
            {site.demo && (
              <p className="mb-12 rounded-lg border border-champagne/60 bg-paper px-5 py-4 text-[0.92rem]">
                Bozza da completare e far validare prima della pubblicazione definitiva. I testi tra parentesi quadre
                vanno sostituiti con i dati dello studio.
              </p>
            )}
            {sections.map((s) => (
              <div key={s.heading} className="border-t border-[var(--line)] py-8">
                <h2 className="display-sm">{s.heading}</h2>
                <div className="prose-body mt-4 text-[1rem] leading-[1.75]">
                  {s.body.map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
