import Link from "next/link";
import { Logo } from "./Logo";
import { nav, site, fullAddress } from "@/content/site";
import { treatments } from "@/content/treatments";
import { illustrativeNote } from "@/content/studio";
import { Verify } from "@/components/ui/Verify";

export function Footer() {
  const year = 2026;
  return (
    <footer className="on-dark relative bg-ink pb-28 pt-20 text-ivory lg:pb-12">
      <div className="wrap">
        <div className="grid gap-14 border-b border-[var(--line-dark)] pb-14 md:grid-cols-12">
          <div className="md:col-span-5">
            <Logo />
            <p className="mt-6 max-w-sm text-[0.95rem] leading-relaxed text-[rgb(247_245_240/0.7)]">
              {site.doctor}, odontoiatra. Lo studio riceve su appuntamento a Pontecorvo, in provincia di Frosinone.
            </p>
          </div>

          <div className="md:col-span-3">
            <h2 className="label mb-4">Lo studio</h2>
            <address className="space-y-2 text-[0.95rem] not-italic">
              <p>{fullAddress}</p>
              <p>
                <a className="link-draw" href={site.phone.href}>
                  Tel. {site.phone.display}
                </a>
              </p>
              <p>
                <a className="link-draw break-all" href={`mailto:${site.email}`}>
                  {site.email}
                </a>
              </p>
              <p>
                <a className="link-draw" href={site.social.instagram} target="_blank" rel="noopener noreferrer">
                  Instagram
                </a>
              </p>
            </address>
          </div>

          <nav aria-label="Pagine del sito" className="grid grid-cols-2 gap-8 md:col-span-4">
            <div>
              <h2 className="label mb-4">Pagine</h2>
              <ul className="space-y-2 text-[0.95rem]">
                {nav.map((n) => (
                  <li key={n.href}>
                    <Link className="link-draw" href={n.href}>
                      {n.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h2 className="label mb-4">Trattamenti</h2>
              <ul className="space-y-2 text-[0.95rem]">
                {treatments.map((t) => (
                  <li key={t.slug}>
                    <Link className="link-draw" href={`/trattamenti/${t.slug}/`}>
                      {t.title.replace(" dentale", "").replace(" e odontoiatriche", "")}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </nav>
        </div>

        <div className="grid gap-6 pt-8 text-[0.8rem] leading-relaxed text-[rgb(247_245_240/0.6)] md:grid-cols-12">
          <div className="space-y-1 md:col-span-7">
            <p>
              {site.name} · Titolare e direttore sanitario: <Verify>{site.legal.director}</Verify>
            </p>
            <p>
              {site.legal.register} · {site.legal.vat}
            </p>
            <p>
              PEC: {site.legal.pec}
            </p>
            <p>
              Le informazioni di questo sito hanno carattere informativo e non sostituiscono la visita odontoiatrica.{" "}
              {illustrativeNote}
            </p>
          </div>
          <div className="flex flex-wrap items-start gap-x-6 gap-y-2 md:col-span-5 md:justify-end">
            <Link className="link-draw" href="/privacy/">
              Privacy
            </Link>
            <Link className="link-draw" href="/cookie/">
              Cookie
            </Link>
            <span>© {year} {site.shortName}</span>
          </div>
        </div>

        {site.demo && (
          <p className="mt-10 border-t border-[var(--line-dark)] pt-6 text-[0.78rem] text-[rgb(247_245_240/0.5)]">
            Concept dimostrativo realizzato da{" "}
            <a className="link-draw text-[rgb(247_245_240/0.75)]" href={site.agency.url} target="_blank" rel="noopener noreferrer">
              {site.agency.name}
            </a>{" "}
            come proposta per il {site.doctor}. Non è il sito ufficiale dello studio: alcuni dati sono da confermare.
          </p>
        )}
      </div>
    </footer>
  );
}
