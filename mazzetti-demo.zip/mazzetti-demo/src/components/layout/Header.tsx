"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Phone } from "lucide-react";
import { Logo } from "./Logo";
import { MobileMenu } from "./MobileMenu";
import { nav, site } from "@/content/site";

export function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  const isActive = (href: string) => pathname?.startsWith(href.replace(/\/$/, "")) ?? false;

  return (
    <>
      <a
        href="#contenuto"
        className="fixed left-4 top-3 z-[70] -translate-y-24 rounded-full bg-ink px-4 py-2 text-sm text-ivory transition-transform focus:translate-y-0"
      >
        Vai al contenuto
      </a>
      <header className="anim-fade-in fixed inset-x-0 top-0 z-50">
        <div
          className={`mx-auto flex items-center justify-between transition-all duration-500 ease-[var(--ease-out-quart)] ${
            scrolled
              ? "mt-2.5 h-[3.75rem] w-[calc(100%-1.25rem)] max-w-[84rem] rounded-full border border-[var(--line)] bg-[rgb(247_245_240/0.82)] px-4 shadow-[0_8px_30px_-18px_rgb(17_28_34/0.35)] backdrop-blur-xl sm:px-6"
              : "mt-0 h-[var(--header-h)] w-full max-w-[88rem] border border-transparent px-[var(--gutter)]"
          }`}
        >
          <Link href="/" className="text-ink">
            <Logo compact={scrolled} />
            <span className="sr-only">, torna alla home</span>
          </Link>

          <nav aria-label="Principale" className="hidden lg:block">
            <ul className="flex items-center gap-8 text-[0.92rem]">
              {nav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={isActive(item.href) ? "page" : undefined}
                    className={`relative py-2 transition-colors hover:text-ink ${isActive(item.href) ? "text-ink" : "text-steel-ink"}`}
                  >
                    {item.label}
                    <span
                      className={`absolute inset-x-0 -bottom-0.5 h-px origin-left bg-current transition-transform duration-500 ease-[var(--ease-out-quart)] ${
                        isActive(item.href) ? "scale-x-100" : "scale-x-0"
                      }`}
                    />
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={site.phone.href}
              className="hidden items-center gap-2 rounded-full px-3 py-2 text-[0.9rem] text-steel-ink transition-colors hover:text-ink xl:inline-flex"
            >
              <Phone size={15} strokeWidth={1.6} aria-hidden="true" />
              {site.phone.display}
            </a>
            <Link
              href="/contatti/#prenota"
              className="hidden min-h-11 items-center rounded-full bg-ink px-5 text-[0.9rem] font-medium text-ivory transition-colors hover:bg-midnight sm:inline-flex"
            >
              Prenota una visita
            </Link>
            <a
              href={site.phone.href}
              aria-label={`Chiama lo studio, ${site.phone.display}`}
              className="grid h-11 w-11 place-items-center rounded-full border border-[var(--line-strong)] text-ink sm:hidden"
            >
              <Phone size={17} strokeWidth={1.6} aria-hidden="true" />
            </a>
            <button
              type="button"
              onClick={() => setOpen(true)}
              aria-label="Apri il menu"
              aria-expanded={open}
              aria-controls="menu-mobile"
              className="grid h-11 w-11 place-items-center rounded-full border border-[var(--line-strong)] lg:hidden"
            >
              <span className="flex w-[18px] flex-col gap-[5px]" aria-hidden="true">
                <span className="h-px w-full bg-ink" />
                <span className="h-px w-2/3 bg-ink" />
              </span>
            </button>
          </div>
        </div>
      </header>
      <MobileMenu open={open} onClose={() => setOpen(false)} pathname={pathname ?? "/"} />
    </>
  );
}
