import { MARK_PATH, MARK_VIEWBOX } from "./mark-path";

type Props = { className?: string; compact?: boolean };

/** Marchio + nome. Il colore segue `currentColor`. */
export function Logo({ className = "", compact = false }: Props) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <Mark className="h-7 w-auto shrink-0 sm:h-8" />
      <span className="flex flex-col leading-none">
        <span className="font-serif text-[1.35rem] font-semibold tracking-[0.14em] sm:text-[1.5rem]">MAZZETTI</span>{" "}
        {!compact && (
          <span className="mt-1 text-[0.6rem] font-medium tracking-[0.34em] opacity-75">STUDIO DENTISTICO</span>
        )}
      </span>
    </span>
  );
}

export function Mark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox={MARK_VIEWBOX} className={className} aria-hidden="true" focusable="false">
      <path d={MARK_PATH} fill="currentColor" fillRule="evenodd" />
    </svg>
  );
}
