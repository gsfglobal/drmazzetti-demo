"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef } from "react";
import { X, Phone, Mail, MapPin } from "lucide-react";
import { nav, site, fullAddress } from "@/content/site";
import { Logo } from "./Logo";

const EASE = [0.76, 0, 0.24, 1] as const;

export function MobileMenu({ open, onClose, pathname }: { open: boolean; onClose: () => void; pathname: string }) {
  const panel = useRef<HTMLDivElement>(null);
  const closeBtn = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const t = setTimeout(() => closeBtn.current?.focus(), 50);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab" && panel.current) {
        const f = panel.current.querySelectorAll<HTMLElement>("a, button");
        if (!f.length) return;
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      clearTimeout(t);
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          id="menu-mobile"
          ref={panel}
          role="dialog"
          aria-modal="true"
          aria-label="Menu"
          className="on-dark fixed inset-0 z-[60] flex flex-col bg-midnight text-ivory lg:hidden"
          initial={{ clipPath: "inset(0% 0% 100% 0%)" }}
          animate={{ clipPath: "inset(0% 0% 0% 0%)" }}
          exit={{ clipPath: "inset(0% 0% 100% 0%)" }}
          transition={{ duration: 0.7, ease: EASE }}
        >
          <div className="flex h-[var(--header-h)] items-center justify-between px-[var(--gutter)]">
            <Link href="/" onClick={onClose}>
              <Logo />
              <span className="sr-only">, torna alla home</span>
            </Link>
            <button
              ref={closeBtn}
              type="button"
              onClick={onClose}
              aria-label="Chiudi il menu"
              className="grid h-11 w-11 place-items-center rounded-full border border-[var(--line-dark)]"
            >
              <X size={18} strokeWidth={1.5} aria-hidden="true" />
            </button>
          </div>

          <nav aria-label="Menu principale" className="flex flex-1 flex-col justify-center px-[var(--gutter)]">
            <ul className="space-y-1">
              {[{ href: "/", label: "Home" }, ...nav].map((item, i) => {
                const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href.replace(/\/$/, ""));
                return (
                  <li key={item.href} className="overflow-hidden">
                    <motion.div
                      initial={{ y: "110%" }}
                      animate={{ y: "0%" }}
                      transition={{ duration: 0.8, ease: [0.25, 1, 0.5, 1], delay: 0.25 + i * 0.05 }}
                    >
                      <Link
                        href={item.href}
                        onClick={onClose}
                        aria-current={active ? "page" : undefined}
                        className={`flex items-baseline gap-4 py-1.5 font-serif text-[2.6rem] leading-tight ${active ? "text-ivory" : "text-[rgb(247_245_240/0.7)]"}`}
                      >
                        {item.label}
                        {active && <span className="h-1.5 w-1.5 rounded-full bg-champagne" aria-hidden="true" />}
                      </Link>
                    </motion.div>
                  </li>
                );
              })}
            </ul>
          </nav>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.55 }}
            className="space-y-3 border-t border-[var(--line-dark)] px-[var(--gutter)] py-6 text-[0.95rem]"
          >
            <a href={site.phone.href} className="flex items-center gap-3">
              <Phone size={16} strokeWidth={1.5} aria-hidden="true" className="text-champagne" />
              {site.phone.display}
            </a>
            <a href={`mailto:${site.email}`} className="flex items-center gap-3 break-all">
              <Mail size={16} strokeWidth={1.5} aria-hidden="true" className="shrink-0 text-champagne" />
              {site.email}
            </a>
            <p className="flex items-center gap-3 text-[rgb(247_245_240/0.7)]">
              <MapPin size={16} strokeWidth={1.5} aria-hidden="true" className="shrink-0 text-champagne" />
              {fullAddress}
            </p>
            <Link
              href="/contatti/#prenota"
              onClick={onClose}
              className="mt-3 flex min-h-12 items-center justify-center rounded-full bg-ivory font-medium text-ink"
            >
              Prenota una visita
            </Link>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
