"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useState } from "react";
import { Phone } from "lucide-react";
import { site } from "@/content/site";

/**
 * Barra fissa su smartphone: telefono sempre a portata di pollice.
 * Compare dopo il primo scroll; l'etichetta «Concept dimostrativo» le sta sopra.
 */
export function StickyActions() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > window.innerHeight * 0.6);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <AnimatePresence>
        {show && (
          <motion.div
            initial={{ y: "110%" }}
            animate={{ y: 0 }}
            exit={{ y: "110%" }}
            transition={{ duration: 0.5, ease: [0.25, 1, 0.5, 1] }}
            className="fixed inset-x-0 bottom-0 z-40 border-t border-[var(--line)] bg-[rgb(247_245_240/0.92)] px-3 pt-2.5 pb-[calc(0.625rem+env(safe-area-inset-bottom))] backdrop-blur-xl lg:hidden"
          >
            <div className="flex gap-2">
              <a
                href={site.phone.href}
                className="flex min-h-12 flex-1 items-center justify-center gap-2 rounded-full border border-[var(--line-strong)] text-[0.95rem] font-medium"
              >
                <Phone size={16} strokeWidth={1.6} aria-hidden="true" />
                Chiama lo studio
              </a>
              <Link
                href="/contatti/#prenota"
                className="flex min-h-12 flex-1 items-center justify-center rounded-full bg-ink text-[0.95rem] font-medium text-ivory"
              >
                Prenota una visita
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {site.demo && (
        <div
          className={`pointer-events-none fixed bottom-3 left-3 z-40 transition-opacity duration-500 lg:bottom-4 lg:left-auto lg:right-4 lg:opacity-100 ${
            show ? "opacity-0" : "opacity-100"
          }`}
        >
          <span className="pointer-events-auto inline-flex items-center gap-2 rounded-full border border-[var(--line)] bg-[rgb(247_245_240/0.9)] px-3 py-1.5 text-[0.7rem] tracking-wide text-steel-ink shadow-sm backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-champagne" aria-hidden="true" />
            Concept dimostrativo · Dental Go
          </span>
        </div>
      )}
    </>
  );
}
