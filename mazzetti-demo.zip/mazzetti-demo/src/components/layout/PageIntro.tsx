import Link from "next/link";
import { IntroTitle } from "@/components/ui/Reveal";
import { JsonLd, breadcrumbJsonLd } from "@/lib/seo";
import type { ReactNode } from "react";

type Crumb = { name: string; path: string };

export function PageIntro({
  crumbs,
  title,
  lead,
  aside,
}: {
  crumbs: Crumb[];
  title: string[];
  lead?: string;
  aside?: ReactNode;
}) {
  return (
    <header className="pt-[calc(var(--header-h)+3.5rem)] pb-14 lg:pt-[calc(var(--header-h)+5.5rem)] lg:pb-20">
      <div className="wrap">
        <nav aria-label="Percorso di navigazione">
          <ol className="flex flex-wrap items-center gap-2 text-[0.8rem] text-steel-ink">
            <li>
              <Link href="/" className="link-draw">
                Home
              </Link>
            </li>
            {crumbs.map((c, i) => (
              <li key={c.path} className="flex items-center gap-2">
                <span aria-hidden="true">/</span>
                {i === crumbs.length - 1 ? (
                  <span aria-current="page" className="text-ink">
                    {c.name}
                  </span>
                ) : (
                  <Link href={c.path} className="link-draw">
                    {c.name}
                  </Link>
                )}
              </li>
            ))}
          </ol>
        </nav>
        <div className="mt-10 grid gap-y-8 lg:grid-cols-12 lg:gap-x-10">
          <IntroTitle lines={title} className="display-xl lg:col-span-8" />
          {(lead || aside) && (
            <div className="anim-fade-up lg:col-span-4 lg:self-end" style={{ animationDelay: "0.3s" }}>
              {lead && <p className="lead">{lead}</p>}
              {aside}
            </div>
          )}
        </div>
      </div>
      <JsonLd data={breadcrumbJsonLd(crumbs)} />
    </header>
  );
}
